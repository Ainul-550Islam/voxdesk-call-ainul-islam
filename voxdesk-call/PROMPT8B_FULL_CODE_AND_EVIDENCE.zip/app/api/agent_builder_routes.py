"""Enterprise Agent Builder & Version Management API Routes (`/api/v1/agents`).

Backed by durable PostgreSQL ``Agent`` and immutable ``AgentVersion`` tables via
``app.services.agent_service``. Supports:
- Creating and listing agents
- Loading and saving builder draft configurations with ETag (`If-Match`) optimistic concurrency control (`409 Conflict`)
- Validating agent configurations (`identity`, `voice`, `model`, `knowledge_bases`, `tools`, `call_handling`, `security`)
- Publishing immutable versions with `SELECT ... FOR UPDATE` concurrency safety and `Tenant` runtime projection
- Listing version history, fetching individual version snapshots, and rolling back to prior versions
"""

from __future__ import annotations

from app.core.value_types import dictionary_value, list_value

from datetime import datetime, timezone
from typing import Any, Dict, List, Literal, Optional

from fastapi import APIRouter, Depends, Header, HTTPException, Query, Request, Response, status
from pydantic import BaseModel, ConfigDict, Field
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.auth.dependencies import TenantContext, require_permission
from app.auth.permissions import Permission
from app.core.errors import BadRequestError, ConflictError, NotFoundError
from app.db.models import Agent, AgentLifecycleStatus
from app.db.session import get_session as get_db
from app.services import agent_service

router = APIRouter(prefix="/api/v1", tags=["agent-builder"])


class _Strict(BaseModel):
    model_config = ConfigDict(extra="forbid", protected_namespaces=())


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


# ---------------------------------------------------------------------------
# Request & Response Schemas
# ---------------------------------------------------------------------------


class AgentIdentityConfig(_Strict):
    name: str = Field(..., min_length=1, max_length=120)
    description: str = Field(default="", max_length=500)
    persona: str = Field(default="You are a helpful AI assistant.", max_length=2000)
    greeting: str = Field(default="Hello, how can I help you today?", max_length=500)
    end_call_message: str = Field(default="Thank you for calling. Goodbye!", max_length=500)
    fallback_message: str = Field(
        default="I'm sorry, I didn't catch that. Could you repeat?", max_length=500
    )


class AgentVoiceConfig(_Strict):
    provider: Literal["elevenlabs", "openai", "deepgram", "cartesia", "playht", "azure", "polly", "google"] = "elevenlabs"
    voice_id: str = Field(..., min_length=1, max_length=120)
    language: str = Field(default="en-US", max_length=16)
    speed: float = Field(default=1.0, ge=0.5, le=2.0)
    pitch: float = Field(default=1.0, ge=0.5, le=2.0)
    stability: float = Field(default=0.75, ge=0.0, le=1.0)
    similarity_boost: float = Field(default=0.75, ge=0.0, le=1.0)
    fallback_voice_id: Optional[str] = Field(default=None, max_length=120)


class AgentModelConfig(_Strict):
    provider: Literal["openai", "anthropic", "google", "groq", "azure_openai", "bedrock", "custom"] = "openai"
    model_name: str = Field(default="gpt-4o", min_length=1, max_length=120)
    temperature: float = Field(default=0.3, ge=0.0, le=2.0)
    max_tokens: int = Field(default=512, ge=32, le=4096)
    system_prompt: str = Field(default="You are a helpful AI assistant.", max_length=16000)
    context_window_turns: int = Field(default=20, ge=1, le=100)
    response_style: Literal["concise", "balanced", "detailed", "conversational"] = "conversational"


class AgentKnowledgeBaseItem(_Strict):
    kb_id: str = Field(..., min_length=1, max_length=80)
    name: str = Field(..., min_length=1, max_length=120)
    priority: int = Field(default=1, ge=1, le=10)
    top_k: int = Field(default=3, ge=1, le=20)
    similarity_threshold: float = Field(default=0.7, ge=0.0, le=1.0)


class AgentToolParameter(_Strict):
    name: str
    type: Literal["string", "number", "boolean", "object", "array"] = "string"
    description: str = ""
    required: bool = False


class AgentToolConfig(_Strict):
    tool_id: str = Field(..., min_length=1, max_length=80)
    name: str = Field(..., min_length=1, max_length=80)
    description: str = Field(default="", max_length=500)
    endpoint_url: Optional[str] = Field(default=None, max_length=500)
    http_method: Literal["GET", "POST", "PUT", "PATCH", "DELETE"] = "POST"
    timeout_ms: int = Field(default=5000, ge=500, le=30000)
    retry_count: int = Field(default=1, ge=0, le=3)
    parameters: List[AgentToolParameter] = Field(default_factory=list)
    enabled: bool = True


class AgentCallHandlingConfig(_Strict):
    silence_timeout_seconds: int = Field(default=5, ge=2, le=30)
    max_call_duration_seconds: int = Field(default=1800, ge=60, le=7200)
    interruption_sensitivity: float = Field(default=0.5, ge=0.0, le=1.0)
    voicemail_detection: bool = True
    dtmf_enabled: bool = True
    transfer_phone_number: Optional[str] = Field(default=None, max_length=32)


class AgentSecurityConfig(_Strict):
    redact_pii: bool = True
    retention_days: int = Field(default=90, ge=1, le=3650)
    allowed_domains: List[str] = Field(default_factory=list)
    webhook_signing_enabled: bool = True
    custom_headers: Dict[str, str] = Field(default_factory=dict)


class AgentBuilderUpdateIn(_Strict):
    identity: Optional[AgentIdentityConfig] = None
    voice: Optional[AgentVoiceConfig] = None
    model: Optional[AgentModelConfig] = None
    knowledge_bases: Optional[List[AgentKnowledgeBaseItem]] = None
    tools: Optional[List[AgentToolConfig]] = None
    call_handling: Optional[AgentCallHandlingConfig] = None
    security: Optional[AgentSecurityConfig] = None
    expected_etag: Optional[str] = None


class AgentBuilderOut(_Strict):
    agent_id: str
    id: str
    external_key: str
    tenant_id: str
    environment_id: Optional[str] = None
    status: Literal["draft", "published", "archived", "retired"]
    version: int
    published_version: Optional[int] = None
    published_version_id: Optional[str] = None
    etag: str
    draft_etag: str
    lock_version: int = 1
    validation_status: str = "unvalidated"
    updated_at: str
    created_at: Optional[str] = None
    identity: AgentIdentityConfig
    voice: AgentVoiceConfig
    model: AgentModelConfig
    knowledge_bases: List[AgentKnowledgeBaseItem]
    tools: List[AgentToolConfig]
    call_handling: AgentCallHandlingConfig
    security: AgentSecurityConfig


class ValidationIssue(_Strict):
    field: str
    code: str
    message: str


class ValidationResultOut(_Strict):
    valid: bool
    errors: List[ValidationIssue] = Field(default_factory=list)
    warnings: List[ValidationIssue] = Field(default_factory=list)
    checked_at: str


class PublishIn(_Strict):
    release_notes: str = Field(default="", max_length=500)
    changelog: str = Field(default="", max_length=500)
    environment: Literal["development", "staging", "production"] = "production"
    environment_id: Optional[str] = None


class PublishResultOut(_Strict):
    agent_id: str
    version: int
    version_id: str
    status: str
    published_at: str
    release_notes: str
    changelog: str
    environment: str = "production"
    config_hash: str = ""


class AgentVersionOut(_Strict):
    id: str = ""
    agent_id: str
    version: int
    version_number: int = 1
    version_label: str = ""
    status: str
    published_at: str
    published_by: str
    release_notes: str
    changelog: str = ""
    config_hash: str = ""
    published_environment: str = "production"
    published_environment_id: Optional[str] = None
    source_version_id: Optional[str] = None
    is_rollback: bool = False
    is_active: bool = True
    config_snapshot: Dict[str, Any]


class RollbackIn(_Strict):
    version: int = Field(..., ge=1)
    reason: str = Field(default="", max_length=500)


class CreateAgentIn(_Strict):
    name: str = Field(..., min_length=1, max_length=120)
    description: str = Field(default="", max_length=500)
    agent_type: str = Field(default="voice", max_length=32)
    environment_id: Optional[str] = None


# ---------------------------------------------------------------------------
# Serialization Helpers
# ---------------------------------------------------------------------------


def _row_to_builder_out(row: Agent) -> AgentBuilderOut:
    snap = (
        row.current_draft_config
        if isinstance(row.current_draft_config, dict) and row.current_draft_config
        else agent_service.default_builder_config(name=row.name, description=row.description)
    )
    identity_raw = dictionary_value(snap.get("identity"))
    voice_raw = dictionary_value(snap.get("voice"))
    model_raw = dictionary_value(snap.get("model"))
    ch_raw = dictionary_value(snap.get("call_handling"))
    sec_raw = dictionary_value(snap.get("security"))
    kb_raw = list_value(snap.get("knowledge_bases"))
    tools_raw = list_value(snap.get("tools"))

    voice_provider = str(voice_raw.get("provider") or "elevenlabs")
    if voice_provider not in {
        "elevenlabs",
        "openai",
        "deepgram",
        "cartesia",
        "playht",
        "azure",
        "polly",
        "google",
    }:
        voice_provider = "elevenlabs"

    model_provider = str(model_raw.get("provider") or "openai")
    if model_provider not in {
        "openai",
        "anthropic",
        "google",
        "groq",
        "azure_openai",
        "bedrock",
        "custom",
    }:
        model_provider = "openai"

    resp_style = str(model_raw.get("response_style") or "conversational")
    if resp_style not in {"concise", "balanced", "detailed", "conversational"}:
        resp_style = "conversational"

    identity = AgentIdentityConfig(
        name=str(identity_raw.get("name") or snap.get("name") or row.name or "Agent")[:120],
        description=str(identity_raw.get("description") or row.description or "")[:500],
        persona=str(
            identity_raw.get("persona")
            or snap.get("persona")
            or "You are a helpful AI assistant."
        )[:2000],
        greeting=str(
            identity_raw.get("greeting")
            or snap.get("greeting")
            or "Hello, how can I help you today?"
        )[:500],
        end_call_message=str(
            identity_raw.get("end_call_message") or "Thank you for calling. Goodbye!"
        )[:500],
        fallback_message=str(
            identity_raw.get("fallback_message")
            or "I'm sorry, I didn't catch that. Could you repeat?"
        )[:500],
    )

    voice = AgentVoiceConfig(
        provider=voice_provider,  # type: ignore[arg-type]
        voice_id=str(voice_raw.get("voice_id") or "rachel")[:120],
        language=str(
            voice_raw.get("language")
            or (snap.get("language") or {}).get("primary")
            or "en-US"
        )[:16],
        speed=min(2.0, max(0.5, float(voice_raw.get("speed", voice_raw.get("speech_speed", 1.0))))),
        pitch=min(2.0, max(0.5, float(voice_raw.get("pitch", 1.0)))),
        stability=min(1.0, max(0.0, float(voice_raw.get("stability", 0.75)))),
        similarity_boost=min(1.0, max(0.0, float(voice_raw.get("similarity_boost", 0.75)))),
        fallback_voice_id=voice_raw.get("fallback_voice_id"),
    )

    model = AgentModelConfig(
        provider=model_provider,  # type: ignore[arg-type]
        model_name=str(
            model_raw.get("model_name") or model_raw.get("model") or "gpt-4o"
        )[:120],
        temperature=min(2.0, max(0.0, float(model_raw.get("temperature", 0.3)))),
        max_tokens=min(4096, max(32, int(model_raw.get("max_tokens", 512)))),
        system_prompt=str(
            model_raw.get("system_prompt")
            or snap.get("system_prompt")
            or "You are a helpful AI assistant."
        )[:16000],
        context_window_turns=min(100, max(1, int(model_raw.get("context_window_turns", 20)))),
        response_style=resp_style,  # type: ignore[arg-type]
    )

    kbs: List[AgentKnowledgeBaseItem] = []
    for item in kb_raw:
        if isinstance(item, dict) and item.get("kb_id") and item.get("name"):
            kbs.append(
                AgentKnowledgeBaseItem(
                    kb_id=str(item["kb_id"]),
                    name=str(item["name"]),
                    priority=int(item.get("priority", 1)),
                    top_k=int(item.get("top_k", 3)),
                    similarity_threshold=float(item.get("similarity_threshold", 0.7)),
                )
            )

    tools: List[AgentToolConfig] = []
    for item in tools_raw:
        if isinstance(item, dict) and item.get("tool_id") and item.get("name"):
            params = [
                AgentToolParameter(**p)
                for p in (item.get("parameters") or [])
                if isinstance(p, dict) and p.get("name")
            ]
            tools.append(
                AgentToolConfig(
                    tool_id=str(item["tool_id"]),
                    name=str(item["name"]),
                    description=str(item.get("description", "")),
                    endpoint_url=item.get("endpoint_url"),
                    http_method=item.get("http_method", "POST"),
                    timeout_ms=int(item.get("timeout_ms", 5000)),
                    retry_count=int(item.get("retry_count", 1)),
                    parameters=params,
                    enabled=bool(item.get("enabled", True)),
                )
            )

    call_handling = AgentCallHandlingConfig(
        silence_timeout_seconds=min(
            30, max(2, int(ch_raw.get("silence_timeout_seconds", 5)))
        ),
        max_call_duration_seconds=min(
            7200, max(60, int(ch_raw.get("max_call_duration_seconds", 1800)))
        ),
        interruption_sensitivity=min(
            1.0, max(0.0, float(ch_raw.get("interruption_sensitivity", 0.5)))
        ),
        voicemail_detection=bool(ch_raw.get("voicemail_detection", True)),
        dtmf_enabled=bool(ch_raw.get("dtmf_enabled", True)),
        transfer_phone_number=ch_raw.get("transfer_phone_number")
        or (
            (snap.get("handoff") or {}).get("destination")
            if (snap.get("handoff") or {}).get("mode") in {"warm", "cold", "number"}
            else None
        ),
    )

    security = AgentSecurityConfig(
        redact_pii=bool(
            sec_raw.get("redact_pii", (snap.get("safety") or {}).get("pii_redaction", True))
        ),
        retention_days=min(3650, max(1, int(sec_raw.get("retention_days", 90)))),
        allowed_domains=[str(d) for d in (sec_raw.get("allowed_domains") or [])],
        webhook_signing_enabled=bool(sec_raw.get("webhook_signing_enabled", True)),
        custom_headers={
            str(k): str(v) for k, v in (sec_raw.get("custom_headers") or {}).items()
        },
    )

    status_val = row.status if row.status in {"draft", "published", "archived", "retired"} else "draft"
    etag_val = row.draft_etag or ""
    active_ver = int(row.published_version_number or row.lock_version or 1)

    return AgentBuilderOut(
        agent_id=str(row.id),
        id=str(row.id),
        external_key=row.external_key,
        tenant_id=str(row.tenant_id),
        environment_id=str(row.environment_id) if row.environment_id else None,
        status=status_val,  # type: ignore[arg-type]
        version=active_ver,
        published_version=row.published_version_number,
        published_version_id=str(row.published_version_id) if row.published_version_id else None,
        etag=etag_val,
        draft_etag=etag_val,
        lock_version=int(row.lock_version or 1),
        validation_status=row.validation_status or "unvalidated",
        updated_at=row.updated_at.isoformat() if row.updated_at else _now_iso(),
        created_at=row.created_at.isoformat() if row.created_at else _now_iso(),
        identity=identity,
        voice=voice,
        model=model,
        knowledge_bases=kbs,
        tools=tools,
        call_handling=call_handling,
        security=security,
    )


def _version_to_out(ver: Any) -> AgentVersionOut:
    published_iso = (
        ver.published_at.isoformat()
        if hasattr(ver.published_at, "isoformat")
        else str(ver.published_at)
    )
    notes = ver.changelog or ""
    return AgentVersionOut(
        id=str(getattr(ver, "id", "")),
        agent_id=str(ver.agent_id),
        version=int(ver.version),
        version_number=int(ver.version),
        version_label=getattr(ver, "version_label", "") or f"v{ver.version}",
        status=ver.status.value if hasattr(ver.status, "value") else str(ver.status),
        published_at=published_iso,
        published_by=str(ver.published_by),
        release_notes=notes,
        changelog=notes,
        config_hash=str(getattr(ver, "config_hash", "")),
        published_environment=str(getattr(ver, "published_environment", "production")),
        published_environment_id=getattr(ver, "published_environment_id", None),
        source_version_id=getattr(ver, "source_version_id", None),
        is_rollback=bool(getattr(ver, "is_rollback", False)),
        is_active=bool(getattr(ver, "is_active", True)),
        config_snapshot=(
            ver.config_snapshot
            if getattr(ver, "config_snapshot", None)
            else ver.config.to_snapshot_dict()
        ),
    )


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------


@router.post("/agents", response_model=AgentBuilderOut, status_code=status.HTTP_201_CREATED)
async def create_agent(
    payload: CreateAgentIn,
    response: Response,
    ctx: TenantContext = Depends(require_permission(Permission.TENANT_UPDATE)),
    session: AsyncSession = Depends(get_db),
) -> AgentBuilderOut:
    try:
        row = await agent_service.create_agent_from_builder_async(
            session,
            ctx.tenant_id,
            name=payload.name,
            description=payload.description,
            agent_type=payload.agent_type,
            environment_id=payload.environment_id,
            actor=ctx.user_id,
        )
        await session.commit()
    except BadRequestError as exc:
        await session.rollback()
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    response.headers["ETag"] = row.draft_etag
    return _row_to_builder_out(row)


@router.get("/agents", response_model=List[AgentBuilderOut])
async def list_agents(
    include_archived: bool = Query(default=False),
    environment_id: Optional[str] = Query(default=None),
    ctx: TenantContext = Depends(require_permission(Permission.TENANT_READ)),
    session: AsyncSession = Depends(get_db),
) -> List[AgentBuilderOut]:
    conditions = [Agent.tenant_id == ctx.tenant_id, Agent.deleted_at.is_(None)]
    if not include_archived:
        conditions.append(Agent.status != AgentLifecycleStatus.ARCHIVED.value)
    if environment_id:
        env_uuid = agent_service._parse_optional_uuid(environment_id)
        if env_uuid is not None:
            conditions.append(Agent.environment_id == env_uuid)
    stmt = (
        select(Agent)
        .where(*conditions)
        .order_by(Agent.updated_at.desc(), Agent.created_at.desc())
    )
    res = await session.execute(stmt)
    rows = res.scalars().all()
    return [_row_to_builder_out(r) for r in rows]


@router.get("/agents/{agent_id}", response_model=AgentBuilderOut)
async def get_agent_detail(
    agent_id: str,
    response: Response,
    ctx: TenantContext = Depends(require_permission(Permission.TENANT_READ)),
    session: AsyncSession = Depends(get_db),
) -> AgentBuilderOut:
    row = await agent_service.get_agent_row(session, ctx.tenant_id, agent_id)
    if row is None:
        raise HTTPException(status_code=404, detail="Agent not found")
    response.headers["ETag"] = row.draft_etag
    return _row_to_builder_out(row)


@router.get("/agents/{agent_id}/builder", response_model=AgentBuilderOut)
async def get_agent_builder(
    agent_id: str,
    response: Response,
    ctx: TenantContext = Depends(require_permission(Permission.TENANT_READ)),
    session: AsyncSession = Depends(get_db),
) -> AgentBuilderOut:
    row = await agent_service.get_agent_row(session, ctx.tenant_id, agent_id)
    if row is None:
        raise HTTPException(status_code=404, detail="Agent not found")
    response.headers["ETag"] = row.draft_etag
    return _row_to_builder_out(row)


@router.patch("/agents/{agent_id}/builder", response_model=AgentBuilderOut)
async def update_agent_builder(
    agent_id: str,
    payload: AgentBuilderUpdateIn,
    request: Request,
    response: Response,
    if_match: Optional[str] = Header(default=None, alias="If-Match"),
    ctx: TenantContext = Depends(require_permission(Permission.TENANT_UPDATE)),
    session: AsyncSession = Depends(get_db),
) -> AgentBuilderOut:
    expected_etag = payload.expected_etag or if_match
    updates = payload.model_dump(exclude_unset=True)
    updates.pop("expected_etag", None)

    try:
        row = await agent_service.save_builder_draft_async(
            session,
            ctx.tenant_id,
            agent_id,
            updates,
            expected_etag=expected_etag,
            actor=ctx.user_id,
        )
        await session.commit()
    except NotFoundError as exc:
        await session.rollback()
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except ConflictError as exc:
        await session.rollback()
        raise HTTPException(status_code=409, detail=str(exc)) from exc
    except BadRequestError as exc:
        await session.rollback()
        raise HTTPException(status_code=422, detail=str(exc)) from exc

    response.headers["ETag"] = row.draft_etag
    return _row_to_builder_out(row)


@router.post("/agents/{agent_id}/validate", response_model=ValidationResultOut)
async def validate_agent(
    agent_id: str,
    ctx: TenantContext = Depends(require_permission(Permission.TENANT_READ)),
    session: AsyncSession = Depends(get_db),
) -> ValidationResultOut:
    try:
        result = await agent_service.validate_agent_async(
            session, ctx.tenant_id, agent_id, actor=ctx.user_id
        )
        await session.commit()
    except NotFoundError as exc:
        await session.rollback()
        raise HTTPException(status_code=404, detail=str(exc)) from exc

    return ValidationResultOut(
        valid=result["valid"],
        errors=[ValidationIssue(**e) for e in result["errors"]],
        warnings=[ValidationIssue(**w) for w in result["warnings"]],
        checked_at=result["checked_at"],
    )


@router.post("/agents/{agent_id}/publish", response_model=PublishResultOut)
async def publish_agent(
    agent_id: str,
    payload: PublishIn,
    ctx: TenantContext = Depends(require_permission(Permission.TENANT_UPDATE)),
    session: AsyncSession = Depends(get_db),
) -> PublishResultOut:
    notes = payload.release_notes or payload.changelog or ""
    try:
        version = await agent_service.publish_async(
            session,
            ctx.tenant,
            None,
            agent_identifier=agent_id,
            actor=ctx.user_id,
            changelog=notes,
            environment=payload.environment,
            environment_id=payload.environment_id,
        )
        await session.commit()
    except LookupError as exc:
        await session.rollback()
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except ValueError as exc:
        await session.rollback()
        raise HTTPException(status_code=422, detail=str(exc)) from exc

    pub_iso = (
        version.published_at.isoformat()
        if hasattr(version.published_at, "isoformat")
        else str(version.published_at)
    )
    return PublishResultOut(
        agent_id=str(agent_id),
        version=version.version,
        version_id=version.id,
        status="published",
        published_at=pub_iso,
        release_notes=version.changelog,
        changelog=version.changelog,
        environment=version.published_environment,
        config_hash=version.config_hash,
    )


@router.get("/agents/{agent_id}/versions", response_model=List[AgentVersionOut])
async def list_agent_versions(
    agent_id: str,
    ctx: TenantContext = Depends(require_permission(Permission.TENANT_READ)),
    session: AsyncSession = Depends(get_db),
) -> List[AgentVersionOut]:
    row = await agent_service.get_agent_row(session, ctx.tenant_id, agent_id, include_deleted=True)
    if row is None:
        raise HTTPException(status_code=404, detail="Agent not found")
    versions = await agent_service.version_history_async(session, ctx.tenant_id, agent_id)
    return [_version_to_out(v) for v in versions]


@router.get("/agents/{agent_id}/versions/{version_number:int}", response_model=AgentVersionOut)
async def get_agent_version(
    agent_id: str,
    version_number: int,
    ctx: TenantContext = Depends(require_permission(Permission.TENANT_READ)),
    session: AsyncSession = Depends(get_db),
) -> AgentVersionOut:
    row = await agent_service.get_agent_row(session, ctx.tenant_id, agent_id, include_deleted=True)
    if row is None:
        raise HTTPException(status_code=404, detail="Agent not found")
    ver = await agent_service.get_version_async(
        session, ctx.tenant_id, agent_id, version_number
    )
    if ver is None:
        raise HTTPException(status_code=404, detail="Version not found")
    return _version_to_out(ver)


@router.post("/agents/{agent_id}/rollback", response_model=AgentVersionOut)
async def rollback_agent(
    agent_id: str,
    payload: RollbackIn,
    ctx: TenantContext = Depends(require_permission(Permission.TENANT_UPDATE)),
    session: AsyncSession = Depends(get_db),
) -> AgentVersionOut:
    try:
        version = await agent_service.rollback_async(
            session,
            ctx.tenant,
            agent_id,
            payload.version,
            actor=ctx.user_id,
            reason=payload.reason,
        )
        await session.commit()
    except LookupError as exc:
        await session.rollback()
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except ValueError as exc:
        await session.rollback()
        raise HTTPException(status_code=422, detail=str(exc)) from exc

    return _version_to_out(version)


@router.get("/agents/{agent_id}/health", response_model=dict)
async def health_check() -> dict[str, str]:
    return {"status": "healthy", "service": "agent-builder", "at": _now_iso()}
