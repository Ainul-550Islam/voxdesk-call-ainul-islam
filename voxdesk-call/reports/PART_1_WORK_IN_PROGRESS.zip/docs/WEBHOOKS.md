# Customer webhooks — PART 1 implementation in progress

## Verified scope

The Twilio inbound-call creation, status callback, media-error finalization and
transfer-result callback now publish customer facts through the existing outbox.
Publication is awaited before commit. It does not perform HTTP in the callback.
The existing dispatcher delivers to enabled subscriptions matching the tenant,
optional environment and event filter. An empty filter matches all event types.

Automated tests exercise a status callback, a real loopback HTTP receiver reached
through an explicitly test-only transport relay, signature verification, duplicate
suppression, transaction rollback, filter isolation, SSRF rejection and HTTP 503
retry-budget exhaustion. This is not a public-network or live-provider certificate.
The relay substitutes only the test network destination; it does not disable the
production URL validator. The loopback receiver itself uses HTTP, not TLS.

## Event catalog

`app/webhooks/call_event_catalog.py::schema_for` is the source of version-one JSON
Schemas. Payloads are reference-only: call ID, status, direction and duration.
Phone numbers, transcripts, raw DTMF digits and recording URLs are not included.
Unknown fields fail validation. The generic outbox envelope carries tenant ID,
event UUID, event type/version, aggregate identity and occurrence time.

| Event | Current runtime wiring |
| --- | --- |
| call_started | Inbound creation and applied Twilio answer transition |
| call_ended | Applied Twilio terminal transition and media-error finalization |
| transfer_completed | Changed Twilio transfer-result callback |
| transfer_failed | Changed Twilio failed transfer-result callback |
| call_analyzed | Schema only; post-call pipeline pending |
| transfer_started | Handler accepts initiated/ringing callbacks for a recorded transfer; default provider callback configuration and redirect-path wiring still pending |
| voicemail_detected | Recognized machine verdict on outbound-answer, for an existing Call |
| dtmf_received | Nonempty validated IVR DTMF for a Call owned by the destination tenant |
| recording_ready | Schema only; recording callback wiring pending |
| batch_started / batch_completed | Schema only; batch integration pending |
| agent_published | Schema only; publication integration pending |

The event publication key is `call:{call_id}:{event}:v1`, unique per tenant.
Version one represents at most one fact of each type per call. It is not a
per-digit or per-transfer-attempt stream. Consumers deduplicate the envelope UUID
in `X-VoxDesk-Event`; this is distinct from the internal publication key.

## Signature verification

The request includes `X-VoxDesk-Event`, `X-VoxDesk-Signature` and
`X-VoxDesk-Timestamp`. The timestamp matches `t` inside the signature header.
The HMAC input is the ASCII timestamp, a period and the exact raw request body.
Parse JSON only after verifying the raw bytes. Reject stale timestamps, and store
processed event IDs durably. A repeated delivery must not repeat side effects.

Python, using the application verifier:

```python
from app.webhooks.signing import verify


def authenticate(secret: str, raw_body: bytes, headers: dict) -> bool:
    signature = headers.get("x-voxdesk-signature", "")
    return verify(secret, raw_body, signature, tolerance_seconds=300)
```

Node.js, using a Buffer containing the unmodified request body:

```javascript
const crypto = require('node:crypto');

function authenticate(secret, rawBody, signature) {
  const fields = Object.fromEntries(signature.split(',').map(x => x.trim().split('=')));
  if (!/^\d+$/.test(fields.t || '') || !/^[0-9a-f]{64}$/.test(fields.v1 || '')) return false;
  if (Math.abs(Math.floor(Date.now() / 1000) - Number(fields.t)) > 300) return false;
  const expected = crypto.createHmac('sha256', secret)
    .update(fields.t + '.').update(rawBody).digest();
  return crypto.timingSafeEqual(expected, Buffer.from(fields.v1, 'hex'));
}
```

## Delivery, retries and remaining limitations

The existing worker provides at-least-once delivery. Only an actual successful
HTTP response produces a succeeded per-subscription delivery row. HTTP 408, 429,
5xx and transport failures are retryable; other 4xx, redirects and invalid URLs
are permanent failures. The default event budget is eight rounds; the existing
bounded exponential backoff starts at 30 seconds, caps at 3,600 seconds and
applies deterministic jitter. An exhausted event enters `dead_letter`.

The legacy lifecycle API and duplicate endpoint/attempt tables have not yet been
unified. Do not treat legacy API responses as proof of this runtime path. New
subscription API CRUD, migration, API secret rotation, delivery inspection/redrive
and full API isolation acceptance remain unfinished. Repository CRUD and secret
rotation are implemented and tested, but are not yet exposed by the legacy API. The existing static SSRF check
rejects literal private/metadata destinations but is not proof against public
DNS names resolving to private addresses or DNS rebinding. Per-subscription
headers/timeouts and richer response diagnostics are supported by the transport;
persistence and dispatcher/API wiring of these settings remain pending. The
transport refuses protected header overrides and control-character injection,
forces redirects off even with an injected client, and reports status, measured
latency and a response snippet bounded to the first 4096 source bytes. Response
snippets are untrusted and may contain sensitive content; callers must not log
them or render them as HTML. Only 2xx responses count as successful delivery.

Callback reconciliation, transfer initiation and other provider/runtime paths
still need review/wiring before 1A can be accepted. No facade allowlist entry has
been removed, no live-provider verification is claimed, and PART 1 is not PASS.


## Repository scope and transactions

`list_subscriptions`, `update_subscription`, `rotate_secret` and
`delete_subscription` require an explicit environment (None denotes tenant-wide).
`get_subscription` preserves a tenant-wide internal lookup when the environment
argument is omitted; authenticated environment-aware routes must pass it.
Queries filter ownership in SQL. Cross-boundary mutations raise the same 404
domain exception as missing rows. Delivery creation verifies subscription and
environment ownership before insertion, including on duplicate recovery.

Repository mutations flush without committing. PostgreSQL row locks serialize
updates/rotations, with existing identity-map state refreshed when the lock is
acquired. SQLite tests prove durability/rollback and ownership behavior; they do
not prove PostgreSQL concurrent-rotation behavior. Existing secret sealing and
production fail-closed behavior are retained. No new fallback key was added.
Description/configuration schema migration, API RBAC/audit integration and
PostgreSQL concurrency tests are still required before sub-part acceptance.


## Additional callback contracts

Voicemail publication recognizes `machine_start`, `machine_end_beep`,
`machine_end_silence` and `machine_end_other`. Unknown call SIDs or unknown
verdicts do not manufacture events. Unknown machine-prefixed verdicts retain the
legacy hangup behavior, but the log now describes that hangup rather than
asserting detection. A callback that arrives before its Call row exists is not
queued for later matching by this route; that reconciliation gap remains.

DTMF version one records only that input was received, once per call. Empty
input produces no event; non-DTMF or more than 64 characters is rejected. Raw
keys are neither included in the event nor written by the IVR-step log. IVR and
inbound duplicate-SID requests cannot mint stream access using another tenant's
destination number; mismatches return 404. The inbound duplicate-creation race
refreshes its tenant after rollback before accessing expired ORM attributes.

`CallStatus.TRANSFERRED` proves provider acceptance, not human connection. The
publication adapter now maps it to `transfer_started`, correcting the earlier
latent `transfer_completed` mapping. Confirmed pickup remains a transfer-result
fact. A rejected late `answered` callback cannot emit CRM completion. A real
failure verdict replaces a prior inferred failure reason, so a later answer
cannot treat the confirmed failure as a correctable guess. Inferred failures
alone are not published as confirmed customer transfer-failure events.

Status and transfer-result queries now acquire PostgreSQL row locks and refresh
identity-map state before applying transitions. SQLite callback tests pass;
this is not a PostgreSQL concurrent-callback certification. The transfer-result
handler accepts initiated/ringing callbacks, but configuring the provider to
send those callbacks is not established by these HTTP contract tests. Direct
transfer initiation, reconciliation and recording producers still need wiring.
