"""Repository boundary and transactional CRUD contracts, not HTTP API coverage."""
import pytest
from sqlalchemy import select

from app.db.models import Environment, WebhookDelivery
from app.tenancy.isolation import BoundaryDenied
from app.webhooks import repository as repo


async def production(db, tenant):
    return await db.scalar(select(Environment.id).where(
        Environment.tenant_id == tenant.id, Environment.kind == "production",
    ))


async def subscribe(db, tenant, environment=None):
    return await repo.create_subscription(
        db, tenant_id=tenant.id, environment_id=environment,
        endpoint="https://example.com/hooks", secret="test-only-secret",
        event_types=["call_ended"],
    )


@pytest.mark.asyncio
async def test_crud_and_rotation_are_durable_and_rollback_safe(db, tenant_a):
    row = await subscribe(db, tenant_a)
    row_id = row.id
    scope = dict(tenant_id=tenant_a.id, environment_id=None, subscription_id=row_id)
    await db.commit()
    await repo.update_subscription(db, **scope, enabled=False, event_types=["call_started"])
    await repo.rotate_secret(db, **scope, secret="new-test-secret")
    assert row.secret_version == 2
    assert repo.open_secret(tenant_a.id, row.secret_envelope) == "new-test-secret"
    await db.rollback()
    await db.refresh(row)
    assert row.enabled is True
    assert row.secret_version == 1
    assert row.event_types == ["call_ended"]
    await repo.rotate_secret(db, **scope, secret="committed-test-secret")
    await db.commit()
    db.expire_all()
    stored = await repo.get_subscription(db, **scope)
    assert stored.secret_version == 2
    assert repo.open_secret(scope["tenant_id"], stored.secret_envelope) == "committed-test-secret"
    await repo.delete_subscription(db, **scope)
    await db.commit()
    assert await repo.get_subscription(db, **scope) is None


@pytest.mark.asyncio
@pytest.mark.parametrize("action", ["update", "rotate", "delete"])
async def test_mutation_conceals_cross_tenant_and_environment(db, tenant_a, tenant_b, action):
    env = await production(db, tenant_a)
    row = await subscribe(db, tenant_a, env)
    fn, args = {
        "update": (repo.update_subscription, {"enabled": False}),
        "rotate": (repo.rotate_secret, {"secret": "replacement-test-secret"}),
        "delete": (repo.delete_subscription, {}),
    }[action]
    for tenant_id, environment_id in [(tenant_b.id, env), (tenant_a.id, None)]:
        with pytest.raises(BoundaryDenied) as caught:
            await fn(db, tenant_id=tenant_id, environment_id=environment_id,
                     subscription_id=row.id, **args)
        assert caught.value.status_code == 404
    assert row.enabled
    assert row.secret_version == 1


@pytest.mark.asyncio
async def test_get_and_list_require_exact_supplied_scope(db, tenant_a, tenant_b):
    env = await production(db, tenant_a)
    row = await subscribe(db, tenant_a, env)
    assert await repo.get_subscription(db, tenant_id=tenant_b.id, subscription_id=row.id) is None
    assert await repo.get_subscription(db, tenant_id=tenant_a.id, environment_id=None,
                                       subscription_id=row.id) is None
    assert await repo.list_subscriptions(db, tenant_id=tenant_a.id, environment_id=None) == []
    assert await repo.list_subscriptions(db, tenant_id=tenant_b.id, environment_id=env) == []
    assert await repo.list_subscriptions(db, tenant_id=tenant_a.id, environment_id=env) == [row]


@pytest.mark.asyncio
async def test_cross_tenant_environment_cannot_be_attached(db, tenant_a, tenant_b):
    other = await production(db, tenant_b)
    with pytest.raises(BoundaryDenied):
        await subscribe(db, tenant_a, other)


@pytest.mark.asyncio
async def test_delivery_cannot_claim_another_subscription_or_environment(db, tenant_a, tenant_b):
    env = await production(db, tenant_a)
    row = await subscribe(db, tenant_a, env)
    for tenant_id, environment in [(tenant_b.id, env), (tenant_a.id, None)]:
        with pytest.raises(BoundaryDenied):
            await repo.create_delivery(db, tenant_id=tenant_id, environment_id=environment,
                                       subscription_id=row.id, event_id="evt-1")
    assert list((await db.scalars(select(WebhookDelivery))).all()) == []


@pytest.mark.asyncio
async def test_tenantwide_subscription_accepts_owned_environment_delivery(db, tenant_a, tenant_b):
    row = await subscribe(db, tenant_a)
    env = await production(db, tenant_a)
    args = dict(tenant_id=tenant_a.id, environment_id=env,
                subscription_id=row.id, event_id="event-1")
    delivery, created = await repo.create_delivery(db, **args)
    duplicate, repeated = await repo.create_delivery(db, **args)
    assert created and not repeated and delivery.id == duplicate.id
    with pytest.raises(BoundaryDenied):
        await repo.create_delivery(db, tenant_id=tenant_a.id,
                                   environment_id=await production(db, tenant_b),
                                   subscription_id=row.id, event_id="event-2")


@pytest.mark.asyncio
async def test_validation_does_not_partially_change_subscription(db, tenant_a):
    row = await subscribe(db, tenant_a)
    with pytest.raises(ValueError):
        await repo.update_subscription(db, tenant_id=tenant_a.id, environment_id=None,
                                       subscription_id=row.id, enabled=False, event_types=[""])
    assert row.enabled
    assert row.event_types == ["call_ended"]
