"""Rebuild the complete-source PART 1 work-in-progress delivery."""
from pathlib import Path
import hashlib
import json
import zipfile

root = Path(__file__).resolve().parents[2]
files = [
    'app/webhooks/call_event_catalog.py',
    'app/webhooks/call_event_bridge.py',
    'app/webhooks/delivery.py',
    'app/webhooks/repository.py',
    'app/telephony/call_state.py',
    'app/telephony/twilio_handler.py',
    'tests/webhooks/__init__.py',
    'tests/webhooks/test_call_event_bridge.py',
    'tests/webhooks/test_webhook_lifecycle_real.py',
    'tests/webhooks/test_webhook_isolation.py',
    'docs/WEBHOOKS.md',
    'reports/part1/build_report.py',
]
summary = '''# PART 1 — implementation started; acceptance NOT COMPLETE

## Status

This is a complete-source delivery of the implemented slices of **1A**,
not a completed PART 1 report or a sub-part acceptance certificate.
No PART 2 work was started. No facade allowlist entry was removed.
No completion commit was made: the required single 1A commit remains pending
until the whole sub-part is complete. The pre-existing staged A/B additions
remain untouched.

| Sub-part | Status |
| --- | --- |
| 1A | PARTIAL: catalog, transactional bridge, selected Twilio hooks, wire-receipt tests |
| 1C | NOT STARTED: durable post-call pipeline and analysis service |
| 1D | NOT STARTED: unified PII, retention enforcement, recording policy |
| 1E | NOT STARTED: enterprise durable request state and audit |
| 1B | NOT STARTED: batch/campaign engine integration and shared DNC/limits |
| 1F | NOT STARTED: Salesforce provider and generic CRM writeback |
| 1G | NOT STARTED: runtime experiment assignment and real promotion |

## Implemented behavior

- Version-one schemas for twelve customer event names, with strict reference-only
  payloads. Defining a schema does not mean every event is wired at runtime.
- Existing transactional outbox publication with key `call:{id}:{event}:v1`.
  Existing dispatcher, delivery ledger, signing and retry mechanisms are reused.
- Inbound creation, Twilio status transition, media-error finalization and transfer
  result callbacks publish before commit. Failures propagate; no background-task
  publication or process-local authoritative queue was introduced.
- Pure transition rules remain unchanged; async publication is an explicit adapter.
- HTTP delivery now also emits the timestamp present in its signature header.
- Added tests for duplicate suppression, rollback, publication failure, strict
  payloads, real status callback, subscription tenant/environment/event filtering,
  local socket receipt/signature, SSRF rejection and 503 retry exhaustion.

## Latest continuation: additional callback producers and transfer truth

- Recognized voicemail verdicts publish one owned, replay-safe event. Unknown
  calls/verdicts do not fabricate events; hangup behavior is preserved.
- IVR publishes reference-only DTMF occurrence events, without raw digits.
  Invalid/oversized input is rejected; empty input is not a DTMF event.
- IVR/inbound duplicate SID cannot mint stream access under another tenant's To.
  The inbound creation-race rollback now refreshes expired tenant state.
- Corrected a latent mapping from TRANSFERRED to transfer_completed: provider
  acceptance only means transfer_started. Human pickup requires evidence.
- A rejected late answered callback no longer invokes the CRM completion hook.
  A confirmed failure supersedes a local inference and cannot be undone as a
  guess by a subsequent answer. Ringing support is tested at the HTTP handler;
  provider configuration to emit those callbacks is NOT claimed verified.
- Status/transfer-result lookups lock rows and refresh loaded state. Tests use
  SQLite; PostgreSQL concurrency proof remains outstanding.

Command:
`OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 .venv/bin/python -m pytest tests/webhooks tests/outbox tests/operations/test_notification_webhook_email.py tests/test_call_state.py tests/test_call_callbacks.py tests/test_transfer.py tests/telephony/test_lead_lifecycle_callbacks.py -q --junitxml=reports/part1/producers.xml`

**180 passed, 849 warnings; no failures/errors/skips.** Latest truth gate:
**41 passed, 59 warnings**. Latest selected Ruff: **All checks passed**.
These are separate runs. Earlier 114/87-pass runs below are historical, not
additional unique passes. No tests were disabled, removed or weakened.

No new migration, router or completion commit was made. The legacy lifecycle
API, unification migration and remaining producer paths still block 1A acceptance.

## Earlier continuation: repository and transport

Repository CRUD/rotation and stricter delivery ownership checks are now implemented.
Mutation queries use explicit tenant/environment scope and PostgreSQL row locks.
Existing identity-map state is refreshed when acquiring the lock. No new tables,
parallel repository, encryption fallback or process-local authoritative state.

Transport supports configurable headers/timeouts and real status/latency/body
snippet diagnostics. Protected headers and CRLF injection are rejected, redirects
are disabled per request even for an injected redirect-following client, and
informational HTTP responses are no longer classified as delivery success.
These options still need persistence and API/dispatcher wiring.

Latest command:
`OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 .venv/bin/python -m pytest tests/webhooks tests/outbox tests/operations/test_notification_webhook_email.py tests/test_call_state.py tests/telephony/test_lead_lifecycle_callbacks.py -q --junitxml=reports/part1/repository.xml`

**114 passed, 356 warnings; no failures/errors/skips.** Current `make verify-truth`:
**41 passed, 59 warnings**. Current selected Ruff: **All checks passed**.
These are separate runs, not an additive unique-test total. The old 87-pass run
below is retained historical evidence, superseded by the broader 114-pass run.

`test_webhook_isolation.py` currently proves repository-level domain 404s, not
HTTP API RBAC/isolation. PostgreSQL multi-worker behavior has not been exercised.
Description/model migration, full lifecycle API replacement and audited API
rotation remain pending. No 1A completion commit or allowlist removal yet.

## Earlier verification (first slice)

Commands were run from the repository root with the restored Python 3.12 venv.

1. `OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 .venv/bin/python -m pytest tests/webhooks tests/outbox tests/test_call_state.py tests/telephony/test_lead_lifecycle_callbacks.py -q --junitxml=reports/part1/webhooks.xml`
   **87 passed, 253 warnings; no failures/errors/skips.**
2. `PATH=$PWD/.venv/bin:$PATH OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 make verify-truth`
   **41 passed, 59 warnings.** Report these as separate runs, not a deduplicated suite count.
3. Configured Ruff on the five changed production modules and tests/webhooks:
   **All checks passed.**
4. Runtime route enumeration: **1156 routes**; no new router added.
5. `alembic heads`: **0049_runtime_schema_alignment (head)**, one head.
6. `make contracts-check`: initially failed because protoc was absent in the
   restored environment. Installed protobuf-compiler, reran, **PASS: five proto
   files compile; enum vocabulary and tenant scoping checks pass**. Both logs retained.

The local receiver is an actual loopback HTTP server. A test-only transport
relays the signed request to it after production URL validation. This verifies
actual bytes and signature receipt, not public HTTPS/TLS or hosted egress.
Retry exhaustion uses real HTTP-result classification through a recording fake;
round numbers are set explicitly to test the existing delivery budget, not to
claim a multi-worker scheduler concurrency test.

## Remaining acceptance gaps — do not mark 1A or PART 1 PASS

- Legacy WebhookEndpoint/DeliveryAttempt and lifecycle API are unchanged. No new
  migration, canonical-model fields, API CRUD/rotation, test-send diagnostics,
  delivery API, replay/redrive or API-level two-tenant 404 acceptance yet.
- Callback reconciliation, direct transfer initiation, recording, batch and
  agent-publication producer paths are not fully wired. IVR DTMF and recognized
  voicemail callbacks are now wired; unmatched early callbacks remain a gap.
- Subscription settings persistence and API/dispatcher wiring remain unfinished;
  transport support and request/response contracts are now implemented.
- The existing delivery URL check is static: DNS resolution/rebinding protection
  is not proven. No SSRF protection was weakened by these tests.
- Outbox events without matched subscriptions close under the existing
  `no_subscriptions` classification; this is not proof of customer HTTP receipt.
- Secrets still use the existing repository implementation; no new encryption
  or fallback was added. Full requested secret-handling review remains pending.
- Migration upgrade/downgrade acceptance was NOT RUN: no migration was created,
  and no isolated PostgreSQL validation database was provisioned in this slice.
- Remaining named PART 1 acceptance modules and live CRM/Salesforce commands
  were NOT RUN. They are not reported as passing or as credential skips.
- PART 1's strict file tree omits canonical `app/db/models.py` and the existing
  outbox dispatcher. Extending these may require a scope decision for later
  work. Correction to the earlier scope note: webhook repository.py IS listed
  in the uploaded tree; its inclusion was initially overlooked.
- No external-provider live test was executed; no LIVE/production-ready claim.

## Complete final files

All created/changed implementation, test and documentation files in this slice
are reproduced below, without shortened file bodies. The report itself is not
recursively embedded. The companion ZIP also contains these exact files, this
report and the actual command logs/XML.

'''
parts = [summary]
manifest = []
for name in files:
    body = (root / name).read_text()
    assert '\x00' not in body, name
    digest = hashlib.sha256((root / name).read_bytes()).hexdigest()
    manifest.append({'path': name, 'sha256': digest})
    fence = '`' * 8
    parts.append(f'\n## `{name}`\n\nSHA-256: `{digest}`\n\n{fence}\n{body}\n{fence}\n')
logs = ['webhooks.log', 'truth-after.log', 'ruff.log', 'routes.log',
        'heads-current.log', 'contracts.log', 'contracts-after-install.log',
        'repository.log', 'truth-repository.log', 'ruff-repository.log',
        'producers.log', 'truth-producers.log', 'ruff-producers.log']
parts.append('\n# Actual command output\n')
for name in logs:
    parts.append(f'\n## {name}\n\n````````text\n{(root / "reports/part1" / name).read_text()}\n````````\n')
report = root / 'reports/PART_1_REPORT.md'
report.write_text(''.join(parts))
(root / 'reports/part1/source-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
archive = root / 'reports/PART_1_WORK_IN_PROGRESS.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as bundle:
    for name in files + ['reports/PART_1_REPORT.md', 'reports/part1/source-manifest.json',
                         'reports/part1/webhooks.xml', 'reports/part1/repository.xml',
                         'reports/part1/producers.xml']:
        bundle.write(root / name, name)
    for name in logs:
        bundle.write(root / 'reports/part1' / name, 'reports/part1/' + name)
print(f'{report}: {report.stat().st_size} bytes')
print(f'{archive}: {archive.stat().st_size} bytes')
