# PART 1 — implementation started; acceptance NOT COMPLETE

## Status

This is a complete-source delivery of the implemented slices of **1A**,
not a completed PART 1 report or a sub-part acceptance certificate.
No PART 2 work was started. No facade allowlist entry was removed.
No completion commit was made: the required single 1A commit remains pending
until the whole sub-part is complete. The pre-existing staged A/B additions
remain untouched.

| Sub-part | Status |
| --- | --- |
| 1A | PARTIAL: catalog, transactional bridge, selected Twilio hooks, wire-receipt tests |
| 1C | NOT STARTED: durable post-call pipeline and analysis service |
| 1D | NOT STARTED: unified PII, retention enforcement, recording policy |
| 1E | NOT STARTED: enterprise durable request state and audit |
| 1B | NOT STARTED: batch/campaign engine integration and shared DNC/limits |
| 1F | NOT STARTED: Salesforce provider and generic CRM writeback |
| 1G | NOT STARTED: runtime experiment assignment and real promotion |

## Implemented behavior

- Version-one schemas for twelve customer event names, with strict reference-only
  payloads. Defining a schema does not mean every event is wired at runtime.
- Existing transactional outbox publication with key `call:{id}:{event}:v1`.
  Existing dispatcher, delivery ledger, signing and retry mechanisms are reused.
- Inbound creation, Twilio status transition, media-error finalization and transfer
  result callbacks publish before commit. Failures propagate; no background-task
  publication or process-local authoritative queue was introduced.
- Pure transition rules remain unchanged; async publication is an explicit adapter.
- HTTP delivery now also emits the timestamp present in its signature header.
- Added tests for duplicate suppression, rollback, publication failure, strict
  payloads, real status callback, subscription tenant/environment/event filtering,
  local socket receipt/signature, SSRF rejection and 503 retry exhaustion.

## Latest continuation: additional callback producers and transfer truth

- Recognized voicemail verdicts publish one owned, replay-safe event. Unknown
  calls/verdicts do not fabricate events; hangup behavior is preserved.
- IVR publishes reference-only DTMF occurrence events, without raw digits.
  Invalid/oversized input is rejected; empty input is not a DTMF event.
- IVR/inbound duplicate SID cannot mint stream access under another tenant's To.
  The inbound creation-race rollback now refreshes expired tenant state.
- Corrected a latent mapping from TRANSFERRED to transfer_completed: provider
  acceptance only means transfer_started. Human pickup requires evidence.
- A rejected late answered callback no longer invokes the CRM completion hook.
  A confirmed failure supersedes a local inference and cannot be undone as a
  guess by a subsequent answer. Ringing support is tested at the HTTP handler;
  provider configuration to emit those callbacks is NOT claimed verified.
- Status/transfer-result lookups lock rows and refresh loaded state. Tests use
  SQLite; PostgreSQL concurrency proof remains outstanding.

Command:
`OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 .venv/bin/python -m pytest tests/webhooks tests/outbox tests/operations/test_notification_webhook_email.py tests/test_call_state.py tests/test_call_callbacks.py tests/test_transfer.py tests/telephony/test_lead_lifecycle_callbacks.py -q --junitxml=reports/part1/producers.xml`

**180 passed, 849 warnings; no failures/errors/skips.** Latest truth gate:
**41 passed, 59 warnings**. Latest selected Ruff: **All checks passed**.
These are separate runs. Earlier 114/87-pass runs below are historical, not
additional unique passes. No tests were disabled, removed or weakened.

No new migration, router or completion commit was made. The legacy lifecycle
API, unification migration and remaining producer paths still block 1A acceptance.

## Earlier continuation: repository and transport

Repository CRUD/rotation and stricter delivery ownership checks are now implemented.
Mutation queries use explicit tenant/environment scope and PostgreSQL row locks.
Existing identity-map state is refreshed when acquiring the lock. No new tables,
parallel repository, encryption fallback or process-local authoritative state.

Transport supports configurable headers/timeouts and real status/latency/body
snippet diagnostics. Protected headers and CRLF injection are rejected, redirects
are disabled per request even for an injected redirect-following client, and
informational HTTP responses are no longer classified as delivery success.
These options still need persistence and API/dispatcher wiring.

Latest command:
`OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 .venv/bin/python -m pytest tests/webhooks tests/outbox tests/operations/test_notification_webhook_email.py tests/test_call_state.py tests/telephony/test_lead_lifecycle_callbacks.py -q --junitxml=reports/part1/repository.xml`

**114 passed, 356 warnings; no failures/errors/skips.** Current `make verify-truth`:
**41 passed, 59 warnings**. Current selected Ruff: **All checks passed**.
These are separate runs, not an additive unique-test total. The old 87-pass run
below is retained historical evidence, superseded by the broader 114-pass run.

`test_webhook_isolation.py` currently proves repository-level domain 404s, not
HTTP API RBAC/isolation. PostgreSQL multi-worker behavior has not been exercised.
Description/model migration, full lifecycle API replacement and audited API
rotation remain pending. No 1A completion commit or allowlist removal yet.

## Earlier verification (first slice)

Commands were run from the repository root with the restored Python 3.12 venv.

1. `OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 .venv/bin/python -m pytest tests/webhooks tests/outbox tests/test_call_state.py tests/telephony/test_lead_lifecycle_callbacks.py -q --junitxml=reports/part1/webhooks.xml`
   **87 passed, 253 warnings; no failures/errors/skips.**
2. `PATH=$PWD/.venv/bin:$PATH OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 make verify-truth`
   **41 passed, 59 warnings.** Report these as separate runs, not a deduplicated suite count.
3. Configured Ruff on the five changed production modules and tests/webhooks:
   **All checks passed.**
4. Runtime route enumeration: **1156 routes**; no new router added.
5. `alembic heads`: **0049_runtime_schema_alignment (head)**, one head.
6. `make contracts-check`: initially failed because protoc was absent in the
   restored environment. Installed protobuf-compiler, reran, **PASS: five proto
   files compile; enum vocabulary and tenant scoping checks pass**. Both logs retained.

The local receiver is an actual loopback HTTP server. A test-only transport
relays the signed request to it after production URL validation. This verifies
actual bytes and signature receipt, not public HTTPS/TLS or hosted egress.
Retry exhaustion uses real HTTP-result classification through a recording fake;
round numbers are set explicitly to test the existing delivery budget, not to
claim a multi-worker scheduler concurrency test.

## Remaining acceptance gaps — do not mark 1A or PART 1 PASS

- Legacy WebhookEndpoint/DeliveryAttempt and lifecycle API are unchanged. No new
  migration, canonical-model fields, API CRUD/rotation, test-send diagnostics,
  delivery API, replay/redrive or API-level two-tenant 404 acceptance yet.
- Callback reconciliation, direct transfer initiation, recording, batch and
  agent-publication producer paths are not fully wired. IVR DTMF and recognized
  voicemail callbacks are now wired; unmatched early callbacks remain a gap.
- Subscription settings persistence and API/dispatcher wiring remain unfinished;
  transport support and request/response contracts are now implemented.
- The existing delivery URL check is static: DNS resolution/rebinding protection
  is not proven. No SSRF protection was weakened by these tests.
- Outbox events without matched subscriptions close under the existing
  `no_subscriptions` classification; this is not proof of customer HTTP receipt.
- Secrets still use the existing repository implementation; no new encryption
  or fallback was added. Full requested secret-handling review remains pending.
- Migration upgrade/downgrade acceptance was NOT RUN: no migration was created,
  and no isolated PostgreSQL validation database was provisioned in this slice.
- Remaining named PART 1 acceptance modules and live CRM/Salesforce commands
  were NOT RUN. They are not reported as passing or as credential skips.
- PART 1's strict file tree omits canonical `app/db/models.py` and the existing
  outbox dispatcher. Extending these may require a scope decision for later
  work. Correction to the earlier scope note: webhook repository.py IS listed
  in the uploaded tree; its inclusion was initially overlooked.
- No external-provider live test was executed; no LIVE/production-ready claim.

## Complete final files

All created/changed implementation, test and documentation files in this slice
are reproduced below, without shortened file bodies. The report itself is not
recursively embedded. The companion ZIP also contains these exact files, this
report and the actual command logs/XML.


## `app/webhooks/call_event_catalog.py`

SHA-256: `301db3ee960ab7b4f8041bae58bb3d5a2dab0e6c074428a54176a1a18f52bbdd`

````````
"""Version-one customer event payload contracts; reference-only by default.

The outbox envelope carries tenant, environment scope, event identity and time.
Payloads deliberately exclude transcripts, phone numbers and recording URLs.
Adding a payload field requires an explicit schema change, not arbitrary extras.
"""
from __future__ import annotations

from copy import deepcopy

from jsonschema import Draft202012Validator, FormatChecker

VERSION = 1
CALL_EVENTS = frozenset({
    "call_started", "call_ended", "call_analyzed", "transfer_started",
    "transfer_completed", "transfer_failed", "voicemail_detected",
    "dtmf_received", "recording_ready",
})
EVENT_NAMES = CALL_EVENTS | {"batch_started", "batch_completed", "agent_published"}


def schema_for(event: str) -> dict:
    """Return a fresh schema so callers cannot mutate the canonical contract."""
    if event not in EVENT_NAMES:
        raise ValueError("Unknown customer webhook event")
    identity = "call_id" if event in CALL_EVENTS else (
        "batch_id" if event.startswith("batch_") else "agent_id"
    )
    properties = {identity: {"type": "string", "format": "uuid"}}
    required = [identity]
    if event in CALL_EVENTS:
        properties.update({
            "status": {"enum": ["ringing", "in_progress", "completed", "failed",
                                "no_answer", "cancelled", "transferred"]},
            "direction": {"enum": ["inbound", "outbound"]},
            "duration_seconds": {"type": "number", "minimum": 0},
        })
        required.extend(["status", "direction", "duration_seconds"])
    if event == "call_analyzed":
        properties["analysis_result_ids"] = {
            "type": "array", "maxItems": 100,
            "items": {"type": "string", "format": "uuid"},
        }
        required.append("analysis_result_ids")
    if event == "recording_ready":
        properties["recording_id"] = {"type": "string", "format": "uuid"}
        required.append("recording_id")
    if event == "agent_published":
        properties["version_id"] = {"type": "string", "format": "uuid"}
        required.append("version_id")
    return deepcopy({
        "$schema": "https://json-schema.org/draft/2020-12/schema",
        "$id": f"urn:voxdesk:webhooks:{event}:v{VERSION}",
        "type": "object", "additionalProperties": False,
        "required": required, "properties": properties,
    })


def validate_payload(event: str, payload: dict) -> None:
    """Raise on an unknown event, invalid identity or undocumented/PII field."""
    Draft202012Validator(schema_for(event), format_checker=FormatChecker()).validate(payload)

````````

## `app/webhooks/call_event_bridge.py`

SHA-256: `0eb0b83484c49472af1356f6954e352260b3cd26d6d7fc13b4d82ecb31ae2f70`

````````
"""Call facts published through the existing transactional outbox.

No new queue or delivery engine. The ordinary outbox dispatcher applies tenant,
optional environment, enabled and event-type subscription filters, then uses
signed HTTP delivery and its durable per-subscription delivery ledger.
"""
from __future__ import annotations

from sqlalchemy.ext.asyncio import AsyncSession

from app.db.models import Call
from app.outbox.publisher import publish
from app.webhooks.call_event_catalog import CALL_EVENTS, VERSION, validate_payload


async def publish_call_event(
    session: AsyncSession, call: Call, event: str, extra: dict | None = None,
):
    """Flush a logical fact, without committing the caller's transaction.

    Scope comes exclusively from the persisted call, never from extra fields.
    A repeated logical event uses the existing database unique constraint.
    This version defines one fact of each type per call (including DTMF and
    transfers); occurrence-by-occurrence streams need a separate versioned key.
    """
    if event not in CALL_EVENTS:
        raise ValueError("This publisher accepts only call events")
    if call.id is None or call.tenant_id is None:
        raise ValueError("Call must be flushed before event publication")
    payload = {
        "call_id": str(call.id),
        "status": call.status.value,
        "direction": call.direction.value,
        "duration_seconds": float(call.duration_seconds or 0),
    }
    if extra:
        if payload.keys() & extra.keys():
            raise ValueError("Extra fields cannot override call identity or state")
        payload.update(extra)
    validate_payload(event, payload)
    return await publish(
        session,
        tenant_id=call.tenant_id,
        environment_id=call.environment_id,
        event_type=event,
        event_version=VERSION,
        aggregate_type="call",
        aggregate_id=str(call.id),
        idempotency_key=f"call:{call.id}:{event}:v{VERSION}",
        payload=payload,
    )

````````

## `app/webhooks/delivery.py`

SHA-256: `4ffe4a74f0ef4100e83e9c7dbaf0e52c5f4dae1620ac14fe95f2570bb7fd7e71`

````````
"""Outbound webhook HTTP delivery.

Redirects are not followed. The URL is checked with the existing SSRF guard
before any socket is opened. Logs contain status and ids, never the secret or
the customer body.
"""

from __future__ import annotations

from dataclasses import dataclass
import math
import re
from time import perf_counter

import httpx

from app.core.logging import log
from app.core.ssrf import OutboundUrlError, validate_outbound_url
from app.webhooks.signing import sign

_MAX_BODY = 4096


@dataclass(frozen=True)
class HttpResult:
    kind: str
    status: int = 0
    category: str = ""
    latency_ms: float | None = None
    response_snippet: str = ""


async def deliver(
    *,
    url: str,
    body: bytes,
    secret: str,
    event_id: str,
    timeout_seconds: float = 5.0,
    headers: dict[str, str] | None = None,
    client: httpx.AsyncClient | None = None,
) -> HttpResult:
    try:
        validate_outbound_url(url, require_https=True)
    except OutboundUrlError:
        return HttpResult("permanent", category="invalid_endpoint")
    if not math.isfinite(timeout_seconds) or not 0 < timeout_seconds <= 60:
        return HttpResult("permanent", category="invalid_timeout")
    protected = {
        "host", "content-length", "content-type", "connection", "transfer-encoding",
        "proxy-authorization", "proxy-connection", "te", "trailer", "upgrade",
        "x-voxdesk-signature", "x-voxdesk-timestamp", "x-voxdesk-event",
    }
    custom = headers or {}
    if len(custom) > 32 or any(
        not isinstance(key, str) or not isinstance(value, str)
        or not re.fullmatch(r"[!#$%&'*+.^_`|~0-9A-Za-z-]{1,128}", key)
        or key.lower() in protected or len(value) > 4096
        or any(ord(char) < 32 or ord(char) > 126 for char in value)
        for key, value in custom.items()
    ):
        return HttpResult("permanent", category="invalid_headers")
    header = sign(secret, body)
    owns = client is None
    http = client or httpx.AsyncClient(timeout=timeout_seconds, follow_redirects=False)
    started = perf_counter()
    try:
        response = await http.post(
            url,
            content=body,
            timeout=timeout_seconds,
            follow_redirects=False,
            headers={
                **custom,
                "Content-Type": "application/json",
                "X-VoxDesk-Signature": header,
                "X-VoxDesk-Timestamp": header.split(",", 1)[0].split("=", 1)[1],
                "X-VoxDesk-Event": event_id,
            },
        )
    except httpx.TimeoutException:
        log.info("webhook.delivery_timeout", event_id=event_id)
        return HttpResult("retryable", category="timeout", latency_ms=(perf_counter() - started) * 1000)
    except httpx.TransportError:
        log.info("webhook.delivery_network", event_id=event_id)
        return HttpResult("retryable", category="network", latency_ms=(perf_counter() - started) * 1000)
    finally:
        if owns:
            await http.aclose()
    diagnostics = {
        "latency_ms": (perf_counter() - started) * 1000,
        "response_snippet": response.content[:_MAX_BODY].decode("utf-8", errors="replace"),
    }
    if response.status_code < 200:
        return HttpResult("permanent", response.status_code, "unexpected_status", **diagnostics)
    if 300 <= response.status_code < 400:
        log.info("webhook.redirect_rejected", event_id=event_id, status=response.status_code)
        return HttpResult("permanent", response.status_code, "redirect_rejected", **diagnostics)
    if response.status_code >= 500 or response.status_code in {408, 429}:
        return HttpResult("retryable", response.status_code, f"http_{response.status_code}", **diagnostics)
    if response.status_code >= 400:
        return HttpResult("permanent", response.status_code, "provider_4xx", **diagnostics)
    if len(response.content) > _MAX_BODY:
        log.info("webhook.response_truncated", event_id=event_id, status=response.status_code)
    log.info("webhook.delivered", event_id=event_id, status=response.status_code)
    return HttpResult("success", response.status_code, "ok", **diagnostics)

````````

## `app/webhooks/repository.py`

SHA-256: `644716dc761dc81e2ae67006d1da7866a52216c5f7e36e273df5d54d0fad00b4`

````````
"""Durable webhook subscriptions and deliveries.

The signing secret is sealed when encryption is available. It is never written
to logs. Duplicate ``subscription_id + event_id`` cannot insert two deliveries.
"""

from __future__ import annotations

import uuid
from datetime import datetime, timezone

from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.db.models import Environment, WebhookDelivery, WebhookSubscription
from app.core.ssrf import validate_outbound_url
from app.tenancy.isolation import BoundaryDenied

_UNSCOPED = object()


def seal_secret(tenant_id: uuid.UUID, secret: str) -> str:
    from app.auth.identity.secrets import encryption_available, encrypt_text

    if encryption_available():
        envelope, _key = encrypt_text(secret, tenant_id=str(tenant_id), purpose="outbound_webhook")
        return envelope
    if settings.is_production:
        from app.auth.identity.exceptions import IdentitySecretsUnavailable

        raise IdentitySecretsUnavailable("webhook secrets require the encryption key ring")
    return "local:" + secret


def open_secret(tenant_id: uuid.UUID, envelope: str) -> str:
    if envelope.startswith("local:"):
        if settings.is_production:
            from app.auth.identity.exceptions import IdentitySecretsUnavailable

            raise IdentitySecretsUnavailable("refusing an unsealed webhook secret")
        return envelope[len("local:") :]
    from app.auth.identity.secrets import decrypt_text

    return decrypt_text(envelope, tenant_id=str(tenant_id), purpose="outbound_webhook")


async def create_subscription(
    session: AsyncSession,
    *,
    tenant_id: uuid.UUID,
    endpoint: str,
    secret: str,
    event_types: list[str],
    environment_id: uuid.UUID | None = None,
) -> WebhookSubscription:
    await _validate_environment(session, tenant_id, environment_id)
    validate_outbound_url(endpoint, require_https=True)
    event_types = _event_types(event_types)
    if not secret:
        raise ValueError("Webhook secret must not be empty")
    row = WebhookSubscription(
        tenant_id=tenant_id,
        environment_id=environment_id,
        endpoint=endpoint,
        enabled=True,
        event_types=list(event_types),
        secret_envelope=seal_secret(tenant_id, secret),
        secret_version=1,
    )
    session.add(row)
    await session.flush()
    return row


async def get_subscription(
    session: AsyncSession, *, tenant_id: uuid.UUID, subscription_id: uuid.UUID,
    environment_id: uuid.UUID | None | object = _UNSCOPED,
) -> WebhookSubscription | None:
    """Tenant-wide internal lookup unless an exact environment is supplied.

    Environment-aware API callers must explicitly pass environment_id, including
    None for a tenant-wide subscription. Omitting it preserves internal worker
    compatibility; it must not be used to bypass an authenticated environment.
    """
    query = select(WebhookSubscription).where(
        WebhookSubscription.id == subscription_id,
        WebhookSubscription.tenant_id == tenant_id,
    )
    if environment_id is not _UNSCOPED:
        query = query.where(WebhookSubscription.environment_id == environment_id)
    return (await session.execute(query)).scalar_one_or_none()


async def create_delivery(
    session: AsyncSession,
    *,
    tenant_id: uuid.UUID,
    subscription_id: uuid.UUID,
    event_id: str,
    environment_id: uuid.UUID | None = None,
) -> tuple[WebhookDelivery, bool]:
    subscription = await get_subscription(
        session, tenant_id=tenant_id, subscription_id=subscription_id,
    )
    if subscription is None or (
        subscription.environment_id is not None
        and subscription.environment_id != environment_id
    ):
        raise BoundaryDenied()
    await _validate_environment(session, tenant_id, environment_id)
    if not event_id or len(event_id) > 128:
        raise ValueError("Webhook event identity must contain 1 to 128 characters")
    row = WebhookDelivery(
        tenant_id=tenant_id,
        environment_id=environment_id,
        subscription_id=subscription_id,
        event_id=event_id,
        status="queued",
    )
    try:
        async with session.begin_nested():
            session.add(row)
            await session.flush()
    except IntegrityError:
        found = (
            await session.execute(
                select(WebhookDelivery).where(
                    WebhookDelivery.tenant_id == tenant_id,
                    WebhookDelivery.environment_id == environment_id,
                    WebhookDelivery.subscription_id == subscription_id,
                    WebhookDelivery.event_id == event_id,
                )
            )
        ).scalar_one_or_none()
        if found is None:
            raise
        return found, False
    return row, True


async def _validate_environment(session, tenant_id, environment_id) -> None:
    if environment_id is not None:
        owned = await session.scalar(select(Environment.id).where(
            Environment.id == environment_id, Environment.tenant_id == tenant_id,
        ))
        if owned is None:
            raise BoundaryDenied()


def _event_types(values: list[str]) -> list[str]:
    if not isinstance(values, list) or len(values) > 100 or any(
        not isinstance(value, str) or not value.strip() or len(value) > 128
        for value in values
    ):
        raise ValueError("event_types must contain at most 100 nonempty event names")
    return list(dict.fromkeys(values))


async def list_subscriptions(
    session: AsyncSession, *, tenant_id: uuid.UUID,
    environment_id: uuid.UUID | None, limit: int = 100, offset: int = 0,
) -> list[WebhookSubscription]:
    """List one exact authenticated scope, with bounded deterministic paging."""
    query = select(WebhookSubscription).where(
        WebhookSubscription.tenant_id == tenant_id,
        WebhookSubscription.environment_id == environment_id,
    ).order_by(WebhookSubscription.created_at, WebhookSubscription.id)
    return list((await session.scalars(
        query.limit(max(1, min(limit, 200))).offset(max(0, offset))
    )).all())


async def _locked_subscription(session, tenant_id, environment_id, subscription_id):
    row = (await session.execute(select(WebhookSubscription).where(
        WebhookSubscription.id == subscription_id,
        WebhookSubscription.tenant_id == tenant_id,
        WebhookSubscription.environment_id == environment_id,
    ).with_for_update().execution_options(populate_existing=True))).scalar_one_or_none()
    if row is None:
        raise BoundaryDenied()
    return row


async def update_subscription(
    session: AsyncSession, *, tenant_id: uuid.UUID,
    environment_id: uuid.UUID | None, subscription_id: uuid.UUID,
    endpoint: str | None = None, enabled: bool | None = None,
    event_types: list[str] | None = None,
) -> WebhookSubscription:
    """Modify only mutable fields. Scope and signing secret cannot be patched."""
    row = await _locked_subscription(session, tenant_id, environment_id, subscription_id)
    if endpoint is not None:
        validate_outbound_url(endpoint, require_https=True)
    if event_types is not None:
        event_types = _event_types(event_types)
    if enabled is not None and not isinstance(enabled, bool):
        raise ValueError("enabled must be a boolean")
    if endpoint is not None:
        row.endpoint = endpoint
    if enabled is not None:
        row.enabled = enabled
    if event_types is not None:
        row.event_types = event_types
    row.updated_at = datetime.now(timezone.utc)
    await session.flush()
    return row


async def rotate_secret(
    session: AsyncSession, *, tenant_id: uuid.UUID,
    environment_id: uuid.UUID | None, subscription_id: uuid.UUID, secret: str,
) -> WebhookSubscription:
    """Seal a caller-generated secret and increment its durable version.

    PostgreSQL row locking serializes concurrent rotations. Flush only, so an
    API audit write and this rotation may commit or roll back as one unit.
    """
    row = await _locked_subscription(session, tenant_id, environment_id, subscription_id)
    if not secret:
        raise ValueError("Webhook secret must not be empty")
    envelope = seal_secret(tenant_id, secret)
    row.secret_envelope = envelope
    row.secret_version += 1
    row.updated_at = datetime.now(timezone.utc)
    await session.flush()
    return row


async def delete_subscription(
    session: AsyncSession, *, tenant_id: uuid.UUID,
    environment_id: uuid.UUID | None, subscription_id: uuid.UUID,
) -> None:
    """Delete the owned row; the existing delivery FK defines its cascade."""
    row = await _locked_subscription(session, tenant_id, environment_id, subscription_id)
    await session.delete(row)
    await session.flush()

````````

## `app/telephony/call_state.py`

SHA-256: `a235629c3600c86eaca8681f69f58ead93c45ccaa0886822c60c2080fc5be4fa`

````````
"""
The single source of truth for call lifecycle state.

Before this module, call status was written from four different places --
`incoming_call`, `media_stream`'s exception handler, `call_status`, and
`place_call` -- each with its own idea of what was legal. The status webhook in
particular did:

    call.status = _TERMINAL_STATUS.get(CallStatus_, CallStatus.COMPLETED)

which means a duplicate or late Twilio callback would happily rewrite a
TRANSFERRED call as COMPLETED, and an unrecognised status string would silently
be recorded as a successful completion. Twilio retries webhooks, and callbacks
from a parent call and a transfer leg can arrive out of order, so both of those
things happen in production rather than in theory.

The transition functions are pure state-machine logic over a `Call` row.
The asynchronous publish_transition adapter writes customer facts through the
existing outbox before the caller commits. Neither path imports a provider SDK.

Terminology
-----------
*Terminal* states are COMPLETED, FAILED, NO_ANSWER and CANCELLED. Once a call reaches one,
nothing may move it anywhere else.

TRANSFERRED is deliberately **not** terminal: the provider accepted the handoff,
but the transfer leg may still be ringing. Only TransferState.CONNECTED proves
a human answered. The call can subsequently reach COMPLETED or FAILED.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime

import structlog

from app.core import observability
from app.db.models import Call, CallStatus

log = structlog.get_logger()


# --------------------------------------------------------------- the graph ---

#: Every transition this application considers legal.
ALLOWED_TRANSITIONS: dict[CallStatus, frozenset[CallStatus]] = {
    CallStatus.RINGING: frozenset(
        {
            CallStatus.IN_PROGRESS,
            CallStatus.NO_ANSWER,
            CallStatus.FAILED,
            CallStatus.CANCELLED,
            # Twilio can report a call as completed straight from ringing when the
            # caller hangs up during ringback.
            CallStatus.COMPLETED,
        }
    ),
    CallStatus.IN_PROGRESS: frozenset(
        {
            CallStatus.TRANSFERRED,
            CallStatus.COMPLETED,
            CallStatus.FAILED,
        }
    ),
    CallStatus.TRANSFERRED: frozenset(
        {
            # The human hung up, or the transfer leg died after connecting.
            CallStatus.COMPLETED,
            CallStatus.FAILED,
        }
    ),
    # Terminal.
    CallStatus.COMPLETED: frozenset(),
    CallStatus.FAILED: frozenset(),
    CallStatus.NO_ANSWER: frozenset(),
    CallStatus.CANCELLED: frozenset(),
}

TERMINAL_STATUSES: frozenset[CallStatus] = frozenset(
    {
        CallStatus.COMPLETED,
        CallStatus.FAILED,
        CallStatus.NO_ANSWER,
        CallStatus.CANCELLED,
    }
)

#: Provider status string -> our enum. Twilio's vocabulary, lowercased.
PROVIDER_STATUS_MAP: dict[str, CallStatus] = {
    "queued": CallStatus.RINGING,
    "initiated": CallStatus.RINGING,
    "ringing": CallStatus.RINGING,
    "in-progress": CallStatus.IN_PROGRESS,
    "in_progress": CallStatus.IN_PROGRESS,
    "answered": CallStatus.IN_PROGRESS,
    "completed": CallStatus.COMPLETED,
    "no-answer": CallStatus.NO_ANSWER,
    "no_answer": CallStatus.NO_ANSWER,
    "busy": CallStatus.FAILED,
    "failed": CallStatus.FAILED,
    "canceled": CallStatus.CANCELLED,
    "cancelled": CallStatus.CANCELLED,
}

#: Provider statuses that explain *why* a call ended badly. Stored verbatim so
#: support can tell "nobody picked up" apart from "the number is disconnected".
FAILURE_REASONS = {"busy", "failed", "no-answer", "no_answer"}


def is_terminal(status: CallStatus) -> bool:
    return status in TERMINAL_STATUSES


def can_transition(current: CallStatus, target: CallStatus) -> bool:
    """A transition to the same state is always allowed (it is a no-op)."""
    if current == target:
        return True
    return target in ALLOWED_TRANSITIONS.get(current, frozenset())


def map_provider_status(raw: str | None) -> CallStatus | None:
    """
    Translate a provider status string. Returns None for anything unknown.

    Returning None rather than defaulting to COMPLETED is the whole point: an
    unrecognised string must not be able to terminate a live call.
    """
    if not raw:
        return None
    return PROVIDER_STATUS_MAP.get(raw.strip().lower())


# ------------------------------------------------------------------ result ---


@dataclass(frozen=True)
class TransitionResult:
    """What `apply_status` actually did. Never raises; always reports."""

    applied: bool
    previous: CallStatus
    current: CallStatus
    reason: str

    @property
    def ignored(self) -> bool:
        return not self.applied


# ------------------------------------------------------------------- apply ---


def apply_status(
    call: Call,
    target: CallStatus,
    *,
    reason: str = "",
    duration_seconds: float | None = None,
    ended_at: datetime | None = None,
    source: str = "unknown",
) -> TransitionResult:
    """
    Move `call` to `target` if that is legal. Idempotent and non-raising.

    The caller is responsible for committing the session. This function only
    mutates the in-memory row so it can be composed inside a larger unit of
    work (for example: transition + write a transcript event + bill minutes,
    all in one transaction).

    Outcomes:
        applied=True   the status changed
        applied=False  duplicate (same status), terminal, or illegal
    """
    previous = call.status

    # 1. Duplicate callback. Twilio retries; this is the common case, not an
    #    error. We still refresh duration/ended_at because a retry sometimes
    #    carries a more complete payload than the first delivery.
    if previous == target:
        _stamp(call, duration_seconds, ended_at, target)
        log.debug(
            "call_state.duplicate",
            call_id=str(call.id),
            call_sid=call.call_sid,
            status=target.value,
            source=source,
        )
        return TransitionResult(False, previous, previous, "duplicate")

    # 2. Already finished. A late webhook must not resurrect or rewrite it.
    if is_terminal(previous):
        log.warning(
            "call_state.terminal_protected",
            call_id=str(call.id),
            call_sid=call.call_sid,
            current=previous.value,
            rejected=target.value,
            source=source,
        )
        return TransitionResult(False, previous, previous, "terminal")

    # 3. Illegal edge, e.g. COMPLETED -> RINGING or FAILED -> IN_PROGRESS.
    if not can_transition(previous, target):
        log.warning(
            "call_state.illegal_transition",
            call_id=str(call.id),
            call_sid=call.call_sid,
            current=previous.value,
            rejected=target.value,
            source=source,
        )
        return TransitionResult(False, previous, previous, "illegal")

    call.status = target
    _stamp(call, duration_seconds, ended_at, target)

    # Step 7 observability: count the call-shaped signals once, at the exact
    # transition that produced them. Bounded labels only — the call id/SID
    # stay in the log line below, never in a Prometheus label.
    if target is CallStatus.IN_PROGRESS and previous is CallStatus.RINGING:
        observability.record_call_answered()
    if is_terminal(target):
        observability.record_call_outcome(target.value)
        observability.observe_call_duration(call.duration_seconds)

    if reason and target in (CallStatus.FAILED, CallStatus.NO_ANSWER):
        # Only record a failure reason where one is meaningful. `summary` is
        # the caller-visible outcome field and is left alone.
        call.failure_reason = reason[:120]

    log.info(
        "call_state.transition",
        call_id=str(call.id),
        call_sid=call.call_sid,
        previous=previous.value,
        current=target.value,
        reason=reason or None,
        source=source,
    )
    return TransitionResult(True, previous, target, "applied")


def _stamp(
    call: Call,
    duration_seconds: float | None,
    ended_at: datetime | None,
    target: CallStatus,
) -> None:
    """
    Update timestamps and duration without ever losing information.

    Duration only ever grows: a retry that reports 0 seconds must not erase a
    previously recorded 143 seconds. `ended_at` is written once and then left
    alone, so the first authoritative end time wins.
    """
    if duration_seconds is not None and duration_seconds > (call.duration_seconds or 0):
        call.duration_seconds = duration_seconds

    if is_terminal(target) and call.ended_at is None:
        call.ended_at = ended_at or datetime.utcnow()


def apply_provider_status(
    call: Call,
    raw_status: str | None,
    *,
    duration_seconds: float | None = None,
    source: str = "provider",
) -> TransitionResult:
    """
    Apply a raw provider status string.

    An unknown string is ignored rather than guessed at, because guessing here
    means terminating somebody's live call on a typo.
    """
    target = map_provider_status(raw_status)
    if target is None:
        log.warning(
            "call_state.unknown_provider_status",
            call_id=str(call.id),
            call_sid=call.call_sid,
            raw=raw_status,
            source=source,
        )
        return TransitionResult(False, call.status, call.status, "unknown_status")

    normalized = (raw_status or "").strip().lower()
    reason = normalized if normalized in FAILURE_REASONS else ""
    return apply_status(
        call,
        target,
        reason=reason,
        duration_seconds=duration_seconds,
        source=source,
    )


async def publish_transition(session, call: Call, result: TransitionResult) -> None:
    """Publish an applied lifecycle fact inside the caller's transaction.

    Keep pure transition functions usable by non-persistent callers. Runtime
    callers must await this before committing; publication failure propagates.
    Delivery belongs to the existing outbox worker, never to the callback.
    """
    if not result.applied:
        return
    from app.webhooks.call_event_bridge import publish_call_event

    if is_terminal(result.current):
        event = "call_ended"
    elif result.current in (CallStatus.RINGING, CallStatus.IN_PROGRESS):
        event = "call_started"
    elif result.current is CallStatus.TRANSFERRED:
        # Provider acceptance starts a transfer; it does not prove human pickup.
        event = "transfer_started"
    else:
        return
    await publish_call_event(session, call, event)

````````

## `app/telephony/twilio_handler.py`

SHA-256: `5c85a8ff9c22d16ac63f724fab12bea6726cceba179704579e6190504be64dc7`

````````
"""Twilio webhooks.

Flow:
  1. Someone dials the tenant's number.
  2. Twilio POSTs /telephony/voice  -> we answer with TwiML containing <Stream>.
  3. Twilio opens a WebSocket to /telephony/ws and pumps raw audio both ways.
"""

from __future__ import annotations

import asyncio
import json

from fastapi import APIRouter, Depends, Form, HTTPException, Request, WebSocket, WebSocketDisconnect
from fastapi.responses import PlainTextResponse
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession
from twilio.twiml.voice_response import Connect, VoiceResponse

from app.agent.errors import ProviderError
from app.agent.provider_observability import record_provider_error
from app.core import metrics
from app.core.config import settings
from app.core.logging import log
from app.db.models import (
    Call,
    CallStatus,
    Lead,
    LeadStatus,
    Tenant,
    TransferState,
)
from app.db.session import get_session, get_sessionmaker
from app.integrations import crm
from app.billing import hooks as billing_hooks
from app.integrations.crm import hooks as crm_hooks
from app.realtime import events as realtime_events
from app.telephony import call_state, e2e_guard, phone, transfer_service
from app.webhooks.call_event_bridge import publish_call_event
from app.telephony.ivr import DEFAULT_FLOW, next_node, render_node
from app.telephony.stream_auth import (
    create_stream_token,
    verify_stream_token,
    verify_twilio_request,
)

router = APIRouter(prefix="/telephony", tags=["telephony"])


# Single shared implementation -- see app/telephony/stream_auth.py.
_verify_twilio = verify_twilio_request


@router.post("/voice", response_class=PlainTextResponse)
async def incoming_call(
    request: Request,
    CallSid: str = Form(...),
    From: str = Form(...),
    To: str = Form(...),
    session: AsyncSession = Depends(get_session),
):
    if not await _verify_twilio(request):
        return PlainTextResponse("forbidden", status_code=403)

    tenant = (
        await session.execute(select(Tenant).where(Tenant.twilio_number == To))
    ).scalar_one_or_none()

    # Step 5 (scale-compliance): the real-call E2E guard. A no-op unless the
    # operator armed E2E mode; when armed, only an explicit, allowlisted,
    # test-tenant call may pass. Rejections happen before any Call row exists,
    # so a refused caller can never create a session, stream, usage event, or
    # audit record. See app/telephony/e2e_guard.py.
    try:
        e2e_ctx = e2e_guard.check_inbound(settings, from_number=From, to_number=To, tenant=tenant)
    except e2e_guard.E2ERejected as exc:
        log.warning(
            "call.e2e_rejected_hangup",
            reason=str(exc),
            from_=phone.redact(From),
            to=phone.redact(To),
        )
        rejected = VoiceResponse()
        rejected.say("This number is in test mode and this caller is not authorized. Goodbye.")
        rejected.hangup()
        return PlainTextResponse(str(rejected), media_type="application/xml")
    except e2e_guard.E2EConfigurationError:
        # Fail-closed: refuse traffic rather than answer without the guard.
        raise HTTPException(status_code=503, detail="E2E configuration error")

    response = VoiceResponse()

    if tenant is None or not tenant.is_active:
        response.say("This number is not configured. Goodbye.")
        response.hangup()
        return PlainTextResponse(str(response), media_type="application/xml")

    # STEP 7 removed the usage cap that used to live here.
    #
    # It compared a **lifetime** counter (`minutes_used`, which nothing ever
    # reset -- audit F2) against a **monthly** allowance, so a tenant on 500
    # included minutes got 750 minutes ever and was then permanently answered
    # with "This account has reached its usage limit".
    #
    # It was also the wrong lever. Hanging up on a dentist's patients because
    # the dentist owes forty dollars punishes the one party who has no way to
    # fix it, and costs the business far more than the debt. Entitlement is
    # now enforced where the spend actually originates -- outbound calls and
    # account-level features, via `billing.hooks.may_place_outbound_call` --
    # and inbound calls, which are the customer's revenue, are never blocked.
    #
    # `tenant.is_active`, checked above, remains the deliberate off switch for
    # an account that genuinely must stop.

    # Idempotent call creation: Twilio may re-deliver /voice for the same
    # CallSid (network retry). The unique index on call_sid already prevents a
    # duplicate row, but the naive insert turned that into a 500 and another
    # retry. Answering an already-known CallSid with fresh TwiML is correct and
    # creates no second call/session/billing/usage/audit record.
    call = (
        await session.execute(select(Call).where(Call.call_sid == CallSid))
    ).scalar_one_or_none()
    created_call = False
    if call is None:
        call = Call(
            tenant_id=tenant.id,
            call_sid=CallSid,
            from_number=From,
            to_number=To,
            status=CallStatus.IN_PROGRESS,
        )
        session.add(call)
        try:
            await session.flush()
            await publish_call_event(session, call, "call_started")
            await session.commit()
            created_call = True
        except IntegrityError:
            # Lost a race with a concurrent duplicate; roll back and reuse the
            # row the other request created.
            await session.rollback()
            await session.refresh(tenant)
            call = (
                await session.execute(select(Call).where(Call.call_sid == CallSid))
            ).scalar_one_or_none()
            if call is None:
                # Not a duplicate CallSid: preserve publication/DB failures.
                raise
    else:
        log.info("call.incoming_duplicate", call_sid=CallSid, tenant=tenant.name)

    if call is not None and call.tenant_id != tenant.id:
        # A retried SID must not mint stream access under another tenant's To.
        raise HTTPException(status_code=404, detail="Call not found")

    # Realtime: announce a genuinely-new call once, AFTER its row is durable.
    # A redelivered /voice (Twilio retry) does not re-announce — that is the
    # whole point of created_call tracking instead of "emit on every POST".
    if created_call and call is not None:
        await realtime_events.emit_call_event(call, kind="call.created")

    # Short-lived signed token so the media WebSocket is not open to anyone
    # who learns a call SID. See app/telephony/stream_auth.py.
    ws_url = f"{settings.ws_base_url}/telephony/ws" f"?token={create_stream_token(CallSid)}"

    # IVR চালু থাকলে আগে মেনু, তারপর AI। ফ্লো ভাঙা থাকলে চুপচাপ AI-তে যাবে।
    if tenant.ivr_enabled:
        flow = tenant.ivr_flow or DEFAULT_FLOW
        start = flow.get("start", "start")
        log.info("call.incoming.ivr", tenant=tenant.name, node=start, e2e_test=bool(e2e_ctx))
        return PlainTextResponse(
            render_node(flow, start, tenant, ws_url=ws_url),
            media_type="application/xml",
        )

    connect = Connect()
    connect.stream(url=ws_url)
    response.append(connect)
    log.info(
        "call.incoming",
        from_=phone.redact(From),
        to=phone.redact(To),
        tenant=tenant.name,
        call_sid=CallSid,
        e2e_test=bool(e2e_ctx),
    )
    return PlainTextResponse(str(response), media_type="application/xml")


@router.post("/ivr", response_class=PlainTextResponse)
async def ivr_step(
    request: Request,
    node: str = "",
    To: str = Form(...),
    CallSid: str = Form(...),
    Digits: str = Form(""),
    session: AsyncSession = Depends(get_session),
):
    """Every Gather in a flow posts back here with the pressed digit."""
    if not await _verify_twilio(request):
        return PlainTextResponse("forbidden", status_code=403)

    tenant = (
        await session.execute(select(Tenant).where(Tenant.twilio_number == To))
    ).scalar_one_or_none()
    if tenant is None:
        return PlainTextResponse("<Response><Hangup/></Response>", media_type="application/xml")

    call = (await session.execute(select(Call).where(
        Call.call_sid == CallSid, Call.tenant_id == tenant.id,
    ))).scalar_one_or_none()
    if call is None:
        raise HTTPException(status_code=404, detail="Call not found")
    if Digits:
        if len(Digits) > 64 or any(digit not in "0123456789ABCD*#" for digit in Digits):
            raise HTTPException(status_code=422, detail="Invalid DTMF input")
        # Version one records occurrence, not raw keys or per-key occurrences.
        # The database event key absorbs retries; nothing private is persisted.
        await publish_call_event(session, call, "dtmf_received")
        await session.commit()

    flow = tenant.ivr_flow or DEFAULT_FLOW
    target = next_node(flow, node, Digits) if Digits else (node or flow.get("start"))
    # Short-lived signed token so the media WebSocket is not open to anyone
    # who learns a call SID. See app/telephony/stream_auth.py.
    ws_url = f"{settings.ws_base_url}/telephony/ws" f"?token={create_stream_token(CallSid)}"
    log.info("ivr.step", node=node, digit_present=bool(Digits), next=target)
    return PlainTextResponse(
        render_node(flow, target, tenant, ws_url=ws_url), media_type="application/xml"
    )


@router.post("/outbound-answer", response_class=PlainTextResponse)
async def outbound_answer(
    request: Request,
    campaign_id: str = "",
    lead_id: str = "",
    AnsweredBy: str = Form(""),
    CallSid: str = Form(""),
    session: AsyncSession = Depends(get_session),
):
    """
    Twilio hits this when an outbound call is picked up. If the answer machine
    detector says it is voicemail we hang up immediately -- talking to an
    answering machine burns money and annoys people.

    Like the other Twilio webhooks this authenticates by HMAC signature, not
    by a user token. It was the last route in the telephony path still missing
    that check: without it anyone could mint a media-stream URL for an
    arbitrary call SID.
    """
    from twilio.twiml.voice_response import VoiceResponse as VR

    if not await _verify_twilio(request):
        return PlainTextResponse("forbidden", status_code=403)

    response = VR()
    if AnsweredBy.startswith("machine"):
        # Only documented provider verdicts are customer-facing facts. Unknown
        # machine-prefixed values retain the old hangup behavior, not a verdict.
        recognized_machine = AnsweredBy in {
            "machine_start", "machine_end_beep", "machine_end_silence", "machine_end_other",
        }
        if recognized_machine:
            call = (await session.execute(select(Call).where(
                Call.call_sid == CallSid,
            ))).scalar_one_or_none()
            if call is not None:
                await publish_call_event(session, call, "voicemail_detected")
                await session.commit()
        log.info("outbound.machine_hangup", lead=lead_id, recognized=recognized_machine)
        response.hangup()
        return PlainTextResponse(str(response), media_type="application/xml")

    connect = Connect()
    connect.stream(
        url=(
            f"{settings.ws_base_url}/telephony/ws"
            f"?token={create_stream_token(CallSid)}"
            f"&campaign_id={campaign_id}&lead_id={lead_id}"
        )
    )
    response.append(connect)
    log.info("outbound.answered", lead=lead_id, campaign=campaign_id)
    return PlainTextResponse(str(response), media_type="application/xml")


@router.websocket("/ws")
async def media_stream(websocket: WebSocket):
    """
    Twilio Media Stream. Machine-to-machine: authenticated by the signed
    token we minted into the <Stream> URL, NOT by a user JWT.
    """
    token = websocket.query_params.get("token")
    await websocket.accept()

    # Twilio sends "connected" then "start" before any audio. Bound this with
    # a timeout: a socket that connects and never speaks must not hold a
    # database session and a pipeline slot open forever. The bound is a
    # handshake bound only (generous by default and disable-able via
    # STREAM_HANDSHAKE_TIMEOUT_SECONDS=0) -- it never touches the live
    # conversation, which runs off the WebSocket, not a wall clock.
    async def _await_start():
        await websocket.receive_text()  # connected
        return json.loads(await websocket.receive_text())  # start

    try:
        timeout = settings.stream_handshake_timeout_seconds
        start_msg = await (
            asyncio.wait_for(_await_start(), timeout) if timeout and timeout > 0 else _await_start()
        )
    except (WebSocketDisconnect, asyncio.TimeoutError):
        log.warning("ws.handshake_incomplete")
        await websocket.close(code=1008)  # policy violation
        return

    start = start_msg.get("start", {})
    stream_sid = start.get("streamSid")
    call_sid = start.get("callSid")

    # The token is bound to this call SID, so a token captured from one call
    # cannot be replayed to listen in on another.
    # Imported here, not at module scope: the pipecat stack is heavy and is
    # only needed once a real media stream arrives. Keeping it lazy lets the
    # HTTP API, the webhooks and the test suite boot without it.
    from app.agent.pipeline import run_voice_agent

    if not verify_stream_token(call_sid, token):
        log.warning("ws.rejected_bad_stream_token", call_sid=call_sid)
        await websocket.close(code=1008)  # policy violation
        return

    async with get_sessionmaker()() as session:
        call = (
            await session.execute(select(Call).where(Call.call_sid == call_sid))
        ).scalar_one_or_none()
        if call is None:
            await websocket.close()
            return
        tenant = await session.get(Tenant, call.tenant_id)

        # Step 7 observability: the gauge counts live media-stream pipelines,
        # which is what "calls in flight" means to an operator watching the
        # dashboard. Bounded (a bare gauge), and cleared in `finally` even if
        # the pipeline crashes.
        metrics.ACTIVE_CALLS.inc()
        try:
            await run_voice_agent(
                websocket=websocket,
                stream_sid=stream_sid,
                call_sid=call_sid,
                session=session,
                tenant=tenant,
                call=call,
            )
        except Exception as exc:
            if isinstance(exc, ProviderError):
                # A typed provider failure: record the category and
                # retryability so dashboards/alerts can group them, and log
                # only the safe, fixed message (never a payload or secret).
                # The counter labels are normalised to a closed set, so this
                # cannot mint unbounded Prometheus series.
                record_provider_error(exc.provider, exc.category)
                log.error(
                    "call.crashed",
                    call_sid=call_sid,
                    tenant_id=str(call.tenant_id),
                    provider=exc.provider,
                    category=exc.category,
                    retryable=exc.retryable,
                    error=exc.safe_message,
                )
            else:
                log.error(
                    "call.crashed", call_sid=call_sid, tenant_id=str(call.tenant_id), error=str(exc)
                )
            # A transfer tears our stream down on purpose -- Twilio replaces
            # the TwiML and the socket dies. That is a successful handoff, not
            # a crashed call, so it must not be recorded as FAILED. Going
            # through call_state also protects an already-terminal status.
            await session.refresh(call)
            if call.transfer_state is TransferState.NONE:
                transition = call_state.apply_status(
                    call,
                    CallStatus.FAILED,
                    reason="media stream error",
                    source="media_stream",
                )
                await call_state.publish_transition(session, call, transition)
                await session.commit()
            else:
                log.info(
                    "call.stream_closed_for_transfer",
                    call_sid=call_sid,
                    transfer_state=call.transfer_state.value,
                )
        finally:
            metrics.ACTIVE_CALLS.dec()


@router.post("/status", response_class=PlainTextResponse)
async def call_status(
    request: Request,
    CallSid: str = Form(...),
    CallStatus_: str = Form(alias="CallStatus", default=""),
    CallDuration: str = Form(default="0"),
    session: AsyncSession = Depends(get_session),
):
    """
    Twilio's call status callback.

    Twilio retries this webhook, and for a transferred call the parent leg and
    the dial leg can report out of order, so everything here must be safe to
    run twice and must never regress a terminal state. All of that logic lives
    in `app.telephony.call_state`; this function only decides what a *changed*
    status means for billing, leads and the CRM.

    Previously this route had no signature check at all, which meant anyone
    who could reach the URL could terminate any call and inflate a tenant's
    billed minutes.
    """
    if not await _verify_twilio(request):
        return PlainTextResponse("forbidden", status_code=403)

    call = (
        await session.execute(
            select(Call).where(Call.call_sid == CallSid)
            .with_for_update().execution_options(populate_existing=True)
        )
    ).scalar_one_or_none()
    if call is None:
        # Unknown SID: acknowledge so Twilio stops retrying, but do nothing.
        log.info("status.unknown_call_sid", call_sid=CallSid)
        return PlainTextResponse("ok")

    try:
        duration = float(CallDuration or 0)
    except ValueError:
        duration = 0.0

    # `previous_duration` used to be captured here for the delta-billing that
    # STEP 7 removed. Nothing reads it now: billing takes the final absolute
    # duration once, which is what makes it order-independent.
    result = call_state.apply_provider_status(
        call, CallStatus_, duration_seconds=duration, source="twilio_status"
    )

    await call_state.publish_transition(session, call, result)

    tenant = await session.get(Tenant, call.tenant_id)

    # A transfer that was still dialling when the call ended never connected.
    if result.applied and call_state.is_terminal(call.status):
        if call.transfer_state in (TransferState.REQUESTED, TransferState.DIALING):
            # An inference, not a provider verdict: the <Dial> callback may
            # still arrive and correct it. See transfer_service.INFERRED_PREFIX.
            await transfer_service.mark_transfer_failed(
                session,
                call,
                f"{transfer_service.INFERRED_PREFIX}"
                f"call ended while {call.transfer_state.value}",
            )

    # STEP 7: bill from the *final absolute duration*, once, through an
    # immutable idempotency-keyed usage event.
    #
    # The old line here was `minutes_used += duration - previous_duration`,
    # which subtracted whatever an earlier callback had stamped. Duplicates
    # were handled correctly, but *ordered* callbacks were not: the same
    # 120-second call billed 2.00, 1.00 or 0.50 minutes depending on whether
    # Twilio sent an intermediate `in-progress` or `answered` payload
    # carrying a duration. Measured, not theorised -- see
    # `docs/BILLING-AUDIT.md` F1. Direction of the error was *under*-billing,
    # so nobody complained and it was never found.
    #
    # `on_call_finalized` keys on the call id, so ordering stops mattering:
    # the first terminal callback records the full duration and every
    # subsequent one is a no-op at the database's unique constraint.
    if result.applied and call_state.is_terminal(call.status) and tenant:
        await billing_hooks.on_call_finalized(session, tenant, call)

    # Outbound: record how the attempt went so the dialer stops or retries.
    # Guarded by `result.applied` so a retried webhook cannot re-grade a lead.
    #
    # Batch 06: the grade goes through the canonical lead lifecycle — no
    # direct ``lead.status`` write — and only when the call and the lead
    # agree on tenant *and* environment. A lead whose environment does not
    # match the call's is left untouched (logged, never silently updated),
    # and a racing/repeated grade loses the lifecycle's compare-and-set
    # instead of overwriting state. Existing call terminal-state handling,
    # billing and CRM call events below are unchanged; the lifecycle fires
    # the lead-update CRM hook exactly once per applied transition.
    if result.applied and call.lead_id:
        lead = await session.get(Lead, call.lead_id)
        if lead is not None and (
            lead.tenant_id != call.tenant_id
            or lead.environment_id != call.environment_id
        ):
            log.warning(
                "status.lead_scope_mismatch",
                call_sid=CallSid, lead=str(lead.id),
            )
        elif lead and lead.status is not LeadStatus.DNC:
            from app.leads import lifecycle
            from app.leads.exceptions import ClaimConflict, InvalidTransition

            target = None
            if call.status is CallStatus.COMPLETED and (call.duration_seconds or 0) > 10:
                target = (
                    LeadStatus.QUALIFIED if (call.lead_score or 0) >= 50 else LeadStatus.CALLED
                )
                lead.score = call.lead_score
            elif lead.attempts >= (tenant.max_call_attempts if tenant else 3):
                target = LeadStatus.FAILED
            if target is not None:
                try:
                    await lifecycle.transition(
                        session,
                        lead,
                        target.value,
                        reason="twilio_status_callback",
                        source="telephony",
                        expected=lead.status,
                        environment_id=call.environment_id,
                    )
                except (InvalidTransition, ClaimConflict):
                    # Repeated or racing callback: `result.applied` already
                    # gates duplicates, and the lifecycle's compare-and-set
                    # arbitrates the rest. Never force a grade.
                    log.info(
                        "status.lead_grade_skipped",
                        call_sid=CallSid, lead=str(lead.id),
                    )

    # STEP 5: record the CRM event *inside this transaction*, before the
    # commit. The old code committed first, set `crm_synced = True`, committed
    # again, and only then fired an unawaited `asyncio.create_task` -- so a
    # process death between the flag and the POST marked the call synced and
    # never sent it. Now the event is part of the same commit as the call's
    # final state: either both land or neither does, and delivery is the
    # worker's problem.
    if result.applied and call_state.is_terminal(call.status) and not call.crm_synced:
        if call.status is CallStatus.COMPLETED:
            emitted = await crm_hooks.on_call_completed(session, tenant, call)
        else:
            # NO_ANSWER / FAILED. Commercially the more valuable of the two
            # for a home-service business: somebody should call back.
            emitted = await crm_hooks.on_call_missed(session, tenant, call)
        # The flag now means "an event exists for this call", which is a fact
        # about our own database rather than a guess about a remote system.
        call.crm_synced = call.crm_synced or emitted

    await session.commit()

    # Realtime: announce the APPLIED status change, after the commit, exactly
    # once per logical transition — a retried callback fails result.applied
    # and emits nothing, and the gateway's replay cache covers the remaining
    # crash-between-commit-and-publish window via the deterministic event id.
    if result.applied:
        await realtime_events.emit_call_event(call, kind="call.updated")

    return PlainTextResponse("ok")


@router.post("/transfer-status", response_class=PlainTextResponse)
async def transfer_status(
    request: Request,
    CallSid: str = Form(...),
    DialCallStatus: str = Form(default=""),
    DialCallDuration: str = Form(default="0"),
    session: AsyncSession = Depends(get_session),
):
    """
    Outcome of the <Dial> leg to the human.

    This is what turns "we asked Twilio to transfer" into "a human actually
    picked up". Without it the application could never honestly distinguish a
    connected transfer from one that rang out, which is exactly the guarantee
    STEP 3 is about.

    Point Twilio's Dial `action` at this URL. It is idempotent: a retried
    callback neither re-writes state nor duplicates transcript events.
    """
    if not await _verify_twilio(request):
        return PlainTextResponse("forbidden", status_code=403)

    call = (
        await session.execute(
            select(Call).where(Call.call_sid == CallSid)
            .with_for_update().execution_options(populate_existing=True)
        )
    ).scalar_one_or_none()
    if call is None:
        log.info("transfer_callback", result="unknown_call_sid", call_sid=CallSid)
        return PlainTextResponse("ok")

    outcome = (DialCallStatus or "").strip().lower()
    log.info(
        "transfer_callback",
        call_id=str(call.id),
        call_sid=CallSid,
        tenant_id=str(call.tenant_id),
        dial_status=outcome,
        transfer_state=call.transfer_state.value,
    )

    if outcome in ("answered", "completed"):
        changed = await transfer_service.mark_transfer_connected(session, call)
        # A human actually picked up. Emitted here rather than on call
        # completion because "was transferred" and "the transfer connected"
        # are different facts, and a CRM that conflates them tells the
        # business somebody spoke to the customer when nobody did.
        if changed:
            tenant = await session.get(Tenant, call.tenant_id)
            await crm_hooks.on_transfer_completed(session, tenant, call)
    elif outcome in ("busy", "no-answer", "failed", "canceled", "cancelled"):
        inferred_failure = (
            call.transfer_state is TransferState.FAILED
            and (call.transfer_error or "").startswith(transfer_service.INFERRED_PREFIX)
        )
        changed = await transfer_service.mark_transfer_failed(session, call, outcome)
        if inferred_failure:
            # A provider verdict replaces our earlier guess. Otherwise a later
            # answered callback could wrongly "correct" a confirmed failure.
            call.transfer_error = outcome
            changed = True
    elif outcome in ("initiated", "ringing") and call.transfer_state in (
        TransferState.REQUESTED, TransferState.DIALING,
    ):
        await publish_call_event(session, call, "transfer_started")
        changed = False  # Ringing is not a successful connection.
    else:
        changed = False
        log.warning(
            "invalid_transfer_state",
            reason="unknown_dial_status",
            call_id=str(call.id),
            dial_status=outcome,
        )

    if changed:
        event = "transfer_completed" if outcome in ("answered", "completed") else "transfer_failed"
        await publish_call_event(session, call, event)
    await session.commit()

    # Realtime: transfers are the moment a wallboard most needs live — and
    # only a state that genuinely CHANGED is announced (a retried callback
    # makes mark_transfer_* return False, which is the same idempotency the
    # transcript events already honour).
    if outcome in ("answered", "completed"):
        if changed:
            await realtime_events.emit_call_event(
                call, kind="call.transfer", extra={"transfer_outcome": "connected"}
            )
    elif outcome in ("busy", "no-answer", "failed", "canceled", "cancelled"):
        if changed:
            await realtime_events.emit_call_event(
                call, kind="call.transfer", extra={"transfer_outcome": outcome}
            )

    # Empty TwiML: let the rest of the original <Dial> verb's document run
    # (our transfer TwiML falls through to voicemail when nobody answers).
    return PlainTextResponse("<Response/>", media_type="application/xml")


async def _push_to_crm(tenant: Tenant, call: Call) -> None:
    """Fire-and-forget CRM sync. Logged, never raised."""
    payload = crm.build_payload(
        tenant_name=tenant.name,
        call_id=str(call.id),
        direction=call.direction.value,
        from_number=call.from_number,
        to_number=call.to_number,
        duration_seconds=call.duration_seconds,
        intent=call.intent,
        summary=call.summary,
        booked=call.booked,
        escalated=call.escalated,
        lead_score=call.lead_score,
        recording_url=call.recording_url,
    )
    ok = await crm.push(
        webhook_url=tenant.crm_webhook_url,
        payload=payload,
        crm_type=tenant.crm_type,
        api_key=tenant.crm_api_key,
    )
    log.info("crm.sync", call=str(call.id), ok=ok)

````````

## `tests/webhooks/__init__.py`

SHA-256: `34e54f31646d11fc9da847c3295ce5823a0532ab0629170d27ba7b6d24ccec43`

````````
"""Customer webhook runtime contracts."""

````````

## `tests/webhooks/test_call_event_bridge.py`

SHA-256: `a2bc1cd1667919be4e7b308934737942e847fc3fa1c8922cffd583795cd51b62`

````````
"""Transactional, replay and data-minimization contracts for call events."""
import uuid

import pytest
from jsonschema import ValidationError
from sqlalchemy import select

from app.db.models import Call, CallStatus
from app.outbox.models import OutboxEvent
from app.telephony.call_state import apply_status, publish_transition
from app.webhooks.call_event_bridge import publish_call_event
from app.webhooks.call_event_catalog import EVENT_NAMES, schema_for, validate_payload
from tests.conftest import make_call


@pytest.mark.asyncio
async def test_transition_and_replay_publish_one_fact(db, tenant_a):
    call = await make_call(db, tenant_a, status=CallStatus.IN_PROGRESS)
    for _ in range(2):
        result = apply_status(call, CallStatus.COMPLETED)
        await publish_transition(db, call, result)
    event, created = await publish_call_event(db, call, "call_ended")
    assert not created
    await db.commit()
    rows = list((await db.scalars(select(OutboxEvent))).all())
    assert len(rows) == 1
    assert event.idempotency_key == f"call:{call.id}:call_ended:v1"
    assert event.tenant_id == tenant_a.id
    assert event.payload == {
        "call_id": str(call.id), "status": "completed",
        "direction": "inbound", "duration_seconds": 92.5,
    }


@pytest.mark.asyncio
async def test_rollback_removes_event_and_state(db, tenant_a):
    call = await make_call(db, tenant_a, status=CallStatus.IN_PROGRESS)
    call_id = call.id
    result = apply_status(call, CallStatus.FAILED)
    await publish_transition(db, call, result)
    await db.rollback()
    assert list((await db.scalars(select(OutboxEvent))).all()) == []
    stored = await db.get(Call, call_id)
    assert stored.status is CallStatus.IN_PROGRESS


@pytest.mark.asyncio
async def test_rejected_transition_publishes_nothing(db, tenant_a):
    call = await make_call(db, tenant_a)
    await publish_transition(db, call, apply_status(call, CallStatus.IN_PROGRESS))
    assert list((await db.scalars(select(OutboxEvent))).all()) == []


@pytest.mark.asyncio
async def test_payload_cannot_override_scope_or_leak_transcript(db, tenant_a):
    call = await make_call(db, tenant_a)
    with pytest.raises(ValueError):
        await publish_call_event(db, call, "call_ended", {"call_id": str(uuid.uuid4())})
    with pytest.raises(ValidationError):
        await publish_call_event(db, call, "call_ended", {"transcript": "private"})
    assert list((await db.scalars(select(OutboxEvent))).all()) == []


@pytest.mark.parametrize("event", sorted(EVENT_NAMES))
def test_catalog_schema_is_versioned_and_not_shared(event):
    first = schema_for(event)
    assert first["$id"].endswith(":v1")
    first["properties"].clear()
    assert schema_for(event)["properties"]


def test_unknown_event_rejected():
    with pytest.raises(ValueError):
        validate_payload("invented", {})


@pytest.mark.asyncio
async def test_real_status_route_is_replay_safe(client, db, tenant_a):
    call = await make_call(db, tenant_a, status=CallStatus.IN_PROGRESS)
    for _ in range(2):
        response = await client.post("/telephony/status", data={
            "CallSid": call.call_sid, "CallStatus": "completed", "CallDuration": "100",
        })
        assert response.status_code == 200
    events = list((await db.scalars(select(OutboxEvent).where(
        OutboxEvent.aggregate_id == str(call.id),
        OutboxEvent.event_type == "call_ended",
    ))).all())
    assert len(events) == 1
    assert events[0].payload["duration_seconds"] == 100


@pytest.mark.asyncio
async def test_subscription_fanout_is_tenant_environment_and_filter_scoped(db, tenant_a, tenant_b):
    from app.db.models import Environment
    from app.outbox.dispatcher import matching_subscriptions
    from app.webhooks.repository import create_subscription

    call = await make_call(db, tenant_a)
    event, _ = await publish_call_event(db, call, "call_ended")
    staging = Environment(tenant_id=tenant_a.id, name="Staging", slug="staging",
                          kind="staging", status="active", is_default=False)
    db.add(staging)
    await db.flush()
    expected = []
    for tenant, environment, events, enabled, matches in [
        (tenant_a, None, [], True, True),
        (tenant_a, call.environment_id, ["call_ended"], True, True),
        (tenant_a, staging.id, ["call_ended"], True, False),
        (tenant_a, None, ["call_started"], True, False),
        (tenant_a, None, [], False, False),
        (tenant_b, None, [], True, False),
    ]:
        subscription = await create_subscription(
            db, tenant_id=tenant.id, environment_id=environment,
            endpoint="https://receiver.example.com/hooks", secret="test-only-signing-secret",
            event_types=events,
        )
        subscription.enabled = enabled
        if matches:
            expected.append(subscription.id)
    await db.flush()
    assert {s.id for s in await matching_subscriptions(db, event)} == set(expected)


@pytest.mark.asyncio
async def test_callback_publication_failure_rolls_back_state(client, db, tenant_a, monkeypatch):
    from app.webhooks import call_event_bridge

    call = await make_call(db, tenant_a, status=CallStatus.IN_PROGRESS)

    async def fail(*args, **kwargs):
        raise RuntimeError("publication failed")

    monkeypatch.setattr(call_event_bridge, "publish_call_event", fail)
    with pytest.raises(RuntimeError, match="publication failed"):
        await client.post("/telephony/status", data={
            "CallSid": call.call_sid, "CallStatus": "completed", "CallDuration": "100",
        })
    await db.refresh(call)
    assert call.status is CallStatus.IN_PROGRESS
    assert list((await db.scalars(select(OutboxEvent))).all()) == []


@pytest.mark.asyncio
async def test_dtmf_occurrence_is_private_scoped_and_replay_safe(client, db, tenant_a):
    call = await make_call(db, tenant_a, status=CallStatus.IN_PROGRESS)
    digits = "4929382716451029"
    for _ in range(2):
        response = await client.post("/telephony/ivr?node=menu", data={
            "To": tenant_a.twilio_number, "CallSid": call.call_sid, "Digits": digits,
        })
        assert response.status_code == 200
    events = list((await db.scalars(select(OutboxEvent))).all())
    assert len(events) == 1
    event = events[0]
    assert event.event_type == "dtmf_received"
    assert event.tenant_id == tenant_a.id
    assert event.environment_id == call.environment_id
    assert digits not in str(event.payload)
    assert set(event.payload) == {"call_id", "status", "direction", "duration_seconds"}


@pytest.mark.asyncio
@pytest.mark.parametrize("route", ["/telephony/ivr", "/telephony/voice"])
async def test_call_sid_cannot_be_reused_under_another_tenant_number(client, db, tenant_a, tenant_b, route):
    call = await make_call(db, tenant_a, status=CallStatus.IN_PROGRESS)
    payload = {"To": tenant_b.twilio_number, "CallSid": call.call_sid}
    payload.update({"Digits": "1"} if route.endswith("ivr") else {"From": "+15551230000"})
    response = await client.post(route, data=payload)
    assert response.status_code == 404
    assert "<Stream" not in response.text
    assert list((await db.scalars(select(OutboxEvent))).all()) == []


@pytest.mark.asyncio
@pytest.mark.parametrize("digits, expected", [("", 200), ("not-dtmf", 422), ("1" * 65, 422)])
async def test_empty_or_invalid_dtmf_publishes_nothing(client, db, tenant_a, digits, expected):
    call = await make_call(db, tenant_a, status=CallStatus.IN_PROGRESS)
    response = await client.post("/telephony/ivr", data={
        "To": tenant_a.twilio_number, "CallSid": call.call_sid, "Digits": digits,
    })
    assert response.status_code == expected
    assert list((await db.scalars(select(OutboxEvent))).all()) == []


@pytest.mark.asyncio
@pytest.mark.parametrize("verdict", ["machine_start", "machine_end_beep", "machine_end_silence", "machine_end_other"])
async def test_machine_verdict_publishes_one_owned_event(client, db, tenant_a, verdict):
    from app.db.models import CallDirection
    call = await make_call(db, tenant_a, status=CallStatus.IN_PROGRESS, direction=CallDirection.OUTBOUND)
    for _ in range(2):
        response = await client.post("/telephony/outbound-answer", data={
            "CallSid": call.call_sid, "AnsweredBy": verdict,
        })
        assert response.status_code == 200
        assert "<Hangup" in response.text
    rows = list((await db.scalars(select(OutboxEvent))).all())
    assert len(rows) == 1
    assert rows[0].event_type == "voicemail_detected"
    assert rows[0].tenant_id == tenant_a.id
    assert rows[0].aggregate_id == str(call.id)
    await db.refresh(call)
    assert call.status is CallStatus.IN_PROGRESS


@pytest.mark.asyncio
@pytest.mark.parametrize("verdict", ["human", "unknown", "machine_invented"])
async def test_non_machine_verdict_is_not_fabricated_voicemail(client, db, tenant_a, verdict):
    call = await make_call(db, tenant_a, status=CallStatus.IN_PROGRESS)
    response = await client.post("/telephony/outbound-answer", data={
        "CallSid": call.call_sid, "AnsweredBy": verdict,
    })
    assert response.status_code == 200
    assert list((await db.scalars(select(OutboxEvent))).all()) == []


@pytest.mark.asyncio
async def test_unknown_machine_call_is_acknowledged_without_event(client, db):
    response = await client.post("/telephony/outbound-answer", data={
        "CallSid": "CA-unknown", "AnsweredBy": "machine_start",
    })
    assert response.status_code == 200
    assert list((await db.scalars(select(OutboxEvent))).all()) == []


@pytest.mark.asyncio
async def test_transfer_acceptance_does_not_publish_completion(db, tenant_a):
    call = await make_call(db, tenant_a, status=CallStatus.IN_PROGRESS)
    result = apply_status(call, CallStatus.TRANSFERRED)
    await publish_transition(db, call, result)
    rows = list((await db.scalars(select(OutboxEvent))).all())
    assert [row.event_type for row in rows] == ["transfer_started"]


@pytest.mark.asyncio
async def test_transfer_ringing_then_provider_failure_then_late_answer(client, db, tenant_a, monkeypatch):
    from app.db.models import TransferState
    from app.telephony import twilio_handler

    call = await make_call(db, tenant_a, status=CallStatus.TRANSFERRED,
                           transfer_state=TransferState.DIALING)
    unexpected = []
    original = twilio_handler.crm_hooks.on_transfer_completed

    async def capture(*args, **kwargs):
        unexpected.append(True)
        return await original(*args, **kwargs)

    monkeypatch.setattr(twilio_handler.crm_hooks, "on_transfer_completed", capture)
    for outcome in ["ringing", "ringing", "busy", "busy", "answered"]:
        response = await client.post("/telephony/transfer-status", data={
            "CallSid": call.call_sid, "DialCallStatus": outcome,
        })
        assert response.status_code == 200
    await db.refresh(call)
    assert call.transfer_state is TransferState.FAILED
    assert call.transfer_error == "busy"
    assert unexpected == []
    rows = list((await db.scalars(select(OutboxEvent))).all())
    assert sorted(row.event_type for row in rows) == ["transfer_failed", "transfer_started"]


@pytest.mark.asyncio
async def test_authoritative_failure_replaces_inference_before_late_answer(client, db, tenant_a):
    from app.db.models import TransferState
    from app.telephony.transfer_service import INFERRED_PREFIX

    call = await make_call(db, tenant_a, status=CallStatus.COMPLETED,
                           transfer_state=TransferState.FAILED,
                           transfer_error=INFERRED_PREFIX + "call ended while dialing")
    for outcome in ["busy", "answered"]:
        response = await client.post("/telephony/transfer-status", data={
            "CallSid": call.call_sid, "DialCallStatus": outcome,
        })
        assert response.status_code == 200
    await db.refresh(call)
    assert call.transfer_state is TransferState.FAILED
    assert call.transfer_error == "busy"
    rows = list((await db.scalars(select(OutboxEvent))).all())
    assert [row.event_type for row in rows] == ["transfer_failed"]


@pytest.mark.asyncio
@pytest.mark.parametrize("route", ["/telephony/ivr", "/telephony/outbound-answer"])
async def test_new_producers_reject_unverified_callbacks(client, db, tenant_a, monkeypatch, route):
    from app.core.config import settings
    call = await make_call(db, tenant_a, status=CallStatus.IN_PROGRESS)
    monkeypatch.setattr(settings, "twilio_skip_webhook_verify", False)
    response = await client.post(route, data={
        "CallSid": call.call_sid, "To": tenant_a.twilio_number,
        "Digits": "1", "AnsweredBy": "machine_start",
    })
    assert response.status_code == 403
    assert list((await db.scalars(select(OutboxEvent))).all()) == []


@pytest.mark.asyncio
@pytest.mark.parametrize("route", ["/telephony/ivr", "/telephony/outbound-answer"])
async def test_producer_publication_failure_is_not_acknowledged(client, db, tenant_a, monkeypatch, route):
    from app.telephony import twilio_handler
    call = await make_call(db, tenant_a, status=CallStatus.IN_PROGRESS)

    async def fail(*args, **kwargs):
        raise RuntimeError("outbox unavailable")

    monkeypatch.setattr(twilio_handler, "publish_call_event", fail)
    with pytest.raises(RuntimeError, match="outbox unavailable"):
        await client.post(route, data={
            "CallSid": call.call_sid, "To": tenant_a.twilio_number,
            "Digits": "1", "AnsweredBy": "machine_start",
        })
    assert list((await db.scalars(select(OutboxEvent))).all()) == []

````````

## `tests/webhooks/test_webhook_lifecycle_real.py`

SHA-256: `64ee157a36daa1b872b54fef63aac92667e81a7b430dad8165509a7aab91d230`

````````
"""Real local HTTP receipt via a test-only network relay, not a guard bypass.

Production validates the configured public HTTPS URL. This test transport then
relays the signed bytes to an isolated loopback HTTP receiver. This proves wire
receipt/signing, not public TLS, DNS-rebinding defense or hosted deployment.
"""
import json

import httpx
import pytest
from sqlalchemy import select

from app.db.models import CallStatus, WebhookDelivery
from app.outbox.dispatcher import deliver_event
from app.outbox.models import OutboxEvent
from app.webhooks.delivery import deliver
from app.webhooks.repository import create_subscription
from app.webhooks.signing import verify
from tests.conftest import make_call


@pytest.mark.asyncio
async def test_callback_delivers_signed_bytes_to_local_receiver(client, db, tenant_a):
    import asyncio

    received = []

    async def receive(reader, writer):
        head = await reader.readuntil(b"\r\n\r\n")
        headers = {}
        for line in head.decode().split("\r\n")[1:]:
            if ":" in line:
                key, value = line.split(":", 1)
                headers[key.lower()] = value.strip()
        body = await reader.readexactly(int(headers["content-length"]))
        received.append((headers, body))
        writer.write(b"HTTP/1.1 204 No Content\r\nConnection: close\r\n\r\n")
        await writer.drain()
        writer.close()
        await writer.wait_closed()

    server = await asyncio.start_server(receive, "127.0.0.1", 0)
    port = server.sockets[0].getsockname()[1]

    class LocalRelay(httpx.AsyncBaseTransport):
        async def handle_async_request(self, request):
            async with httpx.AsyncHTTPTransport() as transport:
                local = httpx.Request(
                    request.method, f"http://127.0.0.1:{port}/hooks",
                    headers=request.headers, content=await request.aread(),
                )
                response = await transport.handle_async_request(local)
                await response.aread()
                return response

    secret = "test-only-shared-secret"
    await create_subscription(db, tenant_id=tenant_a.id,
                              endpoint="https://receiver.example.com/hooks",
                              secret=secret, event_types=["call_ended"])
    call = await make_call(db, tenant_a, status=CallStatus.IN_PROGRESS)
    try:
        response = await client.post("/telephony/status", data={
            "CallSid": call.call_sid, "CallStatus": "completed", "CallDuration": "100",
        })
        assert response.status_code == 200
        event = (await db.scalars(select(OutboxEvent).where(
            OutboxEvent.aggregate_id == str(call.id),
            OutboxEvent.event_type == "call_ended",
        ))).one()
        async with httpx.AsyncClient(transport=LocalRelay()) as http:
            async def send(**kwargs):
                return await deliver(client=http, **kwargs)
            assert await deliver_event(db, event, transport=send) == "delivered"
            assert await deliver_event(db, event, transport=send) == "delivered"
        assert len(received) == 1
        headers, body = received[0]
        assert verify(secret, body, headers["x-voxdesk-signature"])
        assert headers["x-voxdesk-timestamp"] == headers["x-voxdesk-signature"].split(",")[0][2:]
        assert headers["x-voxdesk-event"] == str(event.id)
        assert json.loads(body)["payload"]["call_id"] == str(call.id)
        delivery = (await db.scalars(select(WebhookDelivery))).one()
        assert delivery.status == "succeeded"
        assert delivery.attempt == 1
    finally:
        server.close()
        await server.wait_closed()


@pytest.mark.asyncio
@pytest.mark.parametrize("url", ["https://127.0.0.1", "https://169.254.169.254",
                                     "https://metadata.google.internal", "http://example.com"])
async def test_ssrf_rejected_before_transport(url):
    def forbidden(request):
        pytest.fail("Unsafe destination reached transport")
    async with httpx.AsyncClient(transport=httpx.MockTransport(forbidden)) as client:
        result = await deliver(url=url, body=b"{}", secret="test", event_id="test", client=client)
    assert result.kind == "permanent"
    assert result.category == "invalid_endpoint"


@pytest.mark.asyncio
async def test_http_failures_retry_then_exhaust_to_dlq(db, tenant_a):
    from app.webhooks.call_event_bridge import publish_call_event

    call = await make_call(db, tenant_a)
    await create_subscription(db, tenant_id=tenant_a.id,
                              endpoint="https://receiver.example.com/hooks",
                              secret="test", event_types=["call_ended"])
    event, _ = await publish_call_event(db, call, "call_ended")
    event.max_attempts = 2
    seen = []

    def unavailable(request):
        assert str(request.url) == "https://receiver.example.com/hooks"
        assert verify("test", request.content, request.headers["X-VoxDesk-Signature"])
        seen.append(request)
        return httpx.Response(503, text="Unavailable")

    async with httpx.AsyncClient(transport=httpx.MockTransport(unavailable)) as http:
        async def send(**kwargs):
            return await deliver(client=http, **kwargs)
        # Model the round number maintained by the existing dispatcher. This
        # exercises HTTP classification/budget, not job claim concurrency.
        event.attempt_count = 1
        assert await deliver_event(db, event, transport=send) == "pending"
        row = (await db.scalars(select(WebhookDelivery))).one()
        assert row.status == "queued"
        assert row.next_attempt_at is not None
        event.attempt_count = 2
        assert await deliver_event(db, event, transport=send) == "dead_letter"
    assert len(seen) == 2
    assert event.last_error_category == "attempts_exhausted"
    assert row.status != "succeeded"
    assert row.attempt == 2


@pytest.mark.asyncio
async def test_custom_headers_timeout_and_bounded_response_are_real():
    seen = []

    def receive(request):
        seen.append(request)
        assert request.headers["X-Customer-Trace"] == "tenant-trace"
        assert request.extensions["timeout"]["read"] == 1.5
        assert verify("test", request.content, request.headers["X-VoxDesk-Signature"])
        return httpx.Response(202, text="a" * 5000)

    async with httpx.AsyncClient(transport=httpx.MockTransport(receive)) as http:
        result = await deliver(url="https://example.com/hooks", body=b"{}", secret="test",
                               event_id="event-1", timeout_seconds=1.5,
                               headers={"X-Customer-Trace": "tenant-trace"}, client=http)
    assert len(seen) == 1
    assert result.kind == "success" and result.status == 202
    assert result.latency_ms >= 0
    assert result.response_snippet == "a" * 4096


@pytest.mark.asyncio
async def test_injected_client_cannot_enable_redirect_following():
    seen = []

    def redirect(request):
        seen.append(request)
        return httpx.Response(302, headers={"Location": "https://169.254.169.254"})

    async with httpx.AsyncClient(transport=httpx.MockTransport(redirect), follow_redirects=True) as http:
        result = await deliver(url="https://example.com/hooks", body=b"{}", secret="test",
                               event_id="event-1", client=http)
    assert len(seen) == 1
    assert result.kind == "permanent" and result.category == "redirect_rejected"


@pytest.mark.asyncio
@pytest.mark.parametrize("headers", [
    {"Host": "internal"}, {"X-VoxDesk-Signature": "forged"},
    {"Content-Length": "0"}, {"X-Test": "value\r\nHost: internal"},
])
async def test_protected_or_injected_headers_never_reach_transport(headers):
    def forbidden(request):
        pytest.fail("Invalid headers reached HTTP transport")
    async with httpx.AsyncClient(transport=httpx.MockTransport(forbidden)) as http:
        result = await deliver(url="https://example.com/hooks", body=b"{}", secret="test",
                               event_id="event-1", headers=headers, client=http)
    assert result.kind == "permanent" and result.category == "invalid_headers"


@pytest.mark.asyncio
async def test_informational_response_is_not_delivery_success():
    async with httpx.AsyncClient(transport=httpx.MockTransport(
        lambda request: httpx.Response(101),
    )) as http:
        result = await deliver(url="https://example.com/hooks", body=b"{}", secret="test",
                               event_id="event-1", client=http)
    assert result.kind == "permanent" and result.category == "unexpected_status"

````````

## `tests/webhooks/test_webhook_isolation.py`

SHA-256: `ecbf6938cde7ab303a3af4760be48caa316ea5ae85d59f2ac6e135466b4147b1`

````````
"""Repository boundary and transactional CRUD contracts, not HTTP API coverage."""
import pytest
from sqlalchemy import select

from app.db.models import Environment, WebhookDelivery
from app.tenancy.isolation import BoundaryDenied
from app.webhooks import repository as repo


async def production(db, tenant):
    return await db.scalar(select(Environment.id).where(
        Environment.tenant_id == tenant.id, Environment.kind == "production",
    ))


async def subscribe(db, tenant, environment=None):
    return await repo.create_subscription(
        db, tenant_id=tenant.id, environment_id=environment,
        endpoint="https://example.com/hooks", secret="test-only-secret",
        event_types=["call_ended"],
    )


@pytest.mark.asyncio
async def test_crud_and_rotation_are_durable_and_rollback_safe(db, tenant_a):
    row = await subscribe(db, tenant_a)
    row_id = row.id
    scope = dict(tenant_id=tenant_a.id, environment_id=None, subscription_id=row_id)
    await db.commit()
    await repo.update_subscription(db, **scope, enabled=False, event_types=["call_started"])
    await repo.rotate_secret(db, **scope, secret="new-test-secret")
    assert row.secret_version == 2
    assert repo.open_secret(tenant_a.id, row.secret_envelope) == "new-test-secret"
    await db.rollback()
    await db.refresh(row)
    assert row.enabled is True
    assert row.secret_version == 1
    assert row.event_types == ["call_ended"]
    await repo.rotate_secret(db, **scope, secret="committed-test-secret")
    await db.commit()
    db.expire_all()
    stored = await repo.get_subscription(db, **scope)
    assert stored.secret_version == 2
    assert repo.open_secret(scope["tenant_id"], stored.secret_envelope) == "committed-test-secret"
    await repo.delete_subscription(db, **scope)
    await db.commit()
    assert await repo.get_subscription(db, **scope) is None


@pytest.mark.asyncio
@pytest.mark.parametrize("action", ["update", "rotate", "delete"])
async def test_mutation_conceals_cross_tenant_and_environment(db, tenant_a, tenant_b, action):
    env = await production(db, tenant_a)
    row = await subscribe(db, tenant_a, env)
    fn, args = {
        "update": (repo.update_subscription, {"enabled": False}),
        "rotate": (repo.rotate_secret, {"secret": "replacement-test-secret"}),
        "delete": (repo.delete_subscription, {}),
    }[action]
    for tenant_id, environment_id in [(tenant_b.id, env), (tenant_a.id, None)]:
        with pytest.raises(BoundaryDenied) as caught:
            await fn(db, tenant_id=tenant_id, environment_id=environment_id,
                     subscription_id=row.id, **args)
        assert caught.value.status_code == 404
    assert row.enabled
    assert row.secret_version == 1


@pytest.mark.asyncio
async def test_get_and_list_require_exact_supplied_scope(db, tenant_a, tenant_b):
    env = await production(db, tenant_a)
    row = await subscribe(db, tenant_a, env)
    assert await repo.get_subscription(db, tenant_id=tenant_b.id, subscription_id=row.id) is None
    assert await repo.get_subscription(db, tenant_id=tenant_a.id, environment_id=None,
                                       subscription_id=row.id) is None
    assert await repo.list_subscriptions(db, tenant_id=tenant_a.id, environment_id=None) == []
    assert await repo.list_subscriptions(db, tenant_id=tenant_b.id, environment_id=env) == []
    assert await repo.list_subscriptions(db, tenant_id=tenant_a.id, environment_id=env) == [row]


@pytest.mark.asyncio
async def test_cross_tenant_environment_cannot_be_attached(db, tenant_a, tenant_b):
    other = await production(db, tenant_b)
    with pytest.raises(BoundaryDenied):
        await subscribe(db, tenant_a, other)


@pytest.mark.asyncio
async def test_delivery_cannot_claim_another_subscription_or_environment(db, tenant_a, tenant_b):
    env = await production(db, tenant_a)
    row = await subscribe(db, tenant_a, env)
    for tenant_id, environment in [(tenant_b.id, env), (tenant_a.id, None)]:
        with pytest.raises(BoundaryDenied):
            await repo.create_delivery(db, tenant_id=tenant_id, environment_id=environment,
                                       subscription_id=row.id, event_id="evt-1")
    assert list((await db.scalars(select(WebhookDelivery))).all()) == []


@pytest.mark.asyncio
async def test_tenantwide_subscription_accepts_owned_environment_delivery(db, tenant_a, tenant_b):
    row = await subscribe(db, tenant_a)
    env = await production(db, tenant_a)
    args = dict(tenant_id=tenant_a.id, environment_id=env,
                subscription_id=row.id, event_id="event-1")
    delivery, created = await repo.create_delivery(db, **args)
    duplicate, repeated = await repo.create_delivery(db, **args)
    assert created and not repeated and delivery.id == duplicate.id
    with pytest.raises(BoundaryDenied):
        await repo.create_delivery(db, tenant_id=tenant_a.id,
                                   environment_id=await production(db, tenant_b),
                                   subscription_id=row.id, event_id="event-2")


@pytest.mark.asyncio
async def test_validation_does_not_partially_change_subscription(db, tenant_a):
    row = await subscribe(db, tenant_a)
    with pytest.raises(ValueError):
        await repo.update_subscription(db, tenant_id=tenant_a.id, environment_id=None,
                                       subscription_id=row.id, enabled=False, event_types=[""])
    assert row.enabled
    assert row.event_types == ["call_ended"]

````````

## `docs/WEBHOOKS.md`

SHA-256: `defa0d72ad8a4d7aded1a6e63bf50a1e805373f3518110670310cad42350e0c7`

````````
# Customer webhooks — PART 1 implementation in progress

## Verified scope

The Twilio inbound-call creation, status callback, media-error finalization and
transfer-result callback now publish customer facts through the existing outbox.
Publication is awaited before commit. It does not perform HTTP in the callback.
The existing dispatcher delivers to enabled subscriptions matching the tenant,
optional environment and event filter. An empty filter matches all event types.

Automated tests exercise a status callback, a real loopback HTTP receiver reached
through an explicitly test-only transport relay, signature verification, duplicate
suppression, transaction rollback, filter isolation, SSRF rejection and HTTP 503
retry-budget exhaustion. This is not a public-network or live-provider certificate.
The relay substitutes only the test network destination; it does not disable the
production URL validator. The loopback receiver itself uses HTTP, not TLS.

## Event catalog

`app/webhooks/call_event_catalog.py::schema_for` is the source of version-one JSON
Schemas. Payloads are reference-only: call ID, status, direction and duration.
Phone numbers, transcripts, raw DTMF digits and recording URLs are not included.
Unknown fields fail validation. The generic outbox envelope carries tenant ID,
event UUID, event type/version, aggregate identity and occurrence time.

| Event | Current runtime wiring |
| --- | --- |
| call_started | Inbound creation and applied Twilio answer transition |
| call_ended | Applied Twilio terminal transition and media-error finalization |
| transfer_completed | Changed Twilio transfer-result callback |
| transfer_failed | Changed Twilio failed transfer-result callback |
| call_analyzed | Schema only; post-call pipeline pending |
| transfer_started | Handler accepts initiated/ringing callbacks for a recorded transfer; default provider callback configuration and redirect-path wiring still pending |
| voicemail_detected | Recognized machine verdict on outbound-answer, for an existing Call |
| dtmf_received | Nonempty validated IVR DTMF for a Call owned by the destination tenant |
| recording_ready | Schema only; recording callback wiring pending |
| batch_started / batch_completed | Schema only; batch integration pending |
| agent_published | Schema only; publication integration pending |

The event publication key is `call:{call_id}:{event}:v1`, unique per tenant.
Version one represents at most one fact of each type per call. It is not a
per-digit or per-transfer-attempt stream. Consumers deduplicate the envelope UUID
in `X-VoxDesk-Event`; this is distinct from the internal publication key.

## Signature verification

The request includes `X-VoxDesk-Event`, `X-VoxDesk-Signature` and
`X-VoxDesk-Timestamp`. The timestamp matches `t` inside the signature header.
The HMAC input is the ASCII timestamp, a period and the exact raw request body.
Parse JSON only after verifying the raw bytes. Reject stale timestamps, and store
processed event IDs durably. A repeated delivery must not repeat side effects.

Python, using the application verifier:

```python
from app.webhooks.signing import verify


def authenticate(secret: str, raw_body: bytes, headers: dict) -> bool:
    signature = headers.get("x-voxdesk-signature", "")
    return verify(secret, raw_body, signature, tolerance_seconds=300)
```

Node.js, using a Buffer containing the unmodified request body:

```javascript
const crypto = require('node:crypto');

function authenticate(secret, rawBody, signature) {
  const fields = Object.fromEntries(signature.split(',').map(x => x.trim().split('=')));
  if (!/^\d+$/.test(fields.t || '') || !/^[0-9a-f]{64}$/.test(fields.v1 || '')) return false;
  if (Math.abs(Math.floor(Date.now() / 1000) - Number(fields.t)) > 300) return false;
  const expected = crypto.createHmac('sha256', secret)
    .update(fields.t + '.').update(rawBody).digest();
  return crypto.timingSafeEqual(expected, Buffer.from(fields.v1, 'hex'));
}
```

## Delivery, retries and remaining limitations

The existing worker provides at-least-once delivery. Only an actual successful
HTTP response produces a succeeded per-subscription delivery row. HTTP 408, 429,
5xx and transport failures are retryable; other 4xx, redirects and invalid URLs
are permanent failures. The default event budget is eight rounds; the existing
bounded exponential backoff starts at 30 seconds, caps at 3,600 seconds and
applies deterministic jitter. An exhausted event enters `dead_letter`.

The legacy lifecycle API and duplicate endpoint/attempt tables have not yet been
unified. Do not treat legacy API responses as proof of this runtime path. New
subscription API CRUD, migration, API secret rotation, delivery inspection/redrive
and full API isolation acceptance remain unfinished. Repository CRUD and secret
rotation are implemented and tested, but are not yet exposed by the legacy API. The existing static SSRF check
rejects literal private/metadata destinations but is not proof against public
DNS names resolving to private addresses or DNS rebinding. Per-subscription
headers/timeouts and richer response diagnostics are supported by the transport;
persistence and dispatcher/API wiring of these settings remain pending. The
transport refuses protected header overrides and control-character injection,
forces redirects off even with an injected client, and reports status, measured
latency and a response snippet bounded to the first 4096 source bytes. Response
snippets are untrusted and may contain sensitive content; callers must not log
them or render them as HTML. Only 2xx responses count as successful delivery.

Callback reconciliation, transfer initiation and other provider/runtime paths
still need review/wiring before 1A can be accepted. No facade allowlist entry has
been removed, no live-provider verification is claimed, and PART 1 is not PASS.


## Repository scope and transactions

`list_subscriptions`, `update_subscription`, `rotate_secret` and
`delete_subscription` require an explicit environment (None denotes tenant-wide).
`get_subscription` preserves a tenant-wide internal lookup when the environment
argument is omitted; authenticated environment-aware routes must pass it.
Queries filter ownership in SQL. Cross-boundary mutations raise the same 404
domain exception as missing rows. Delivery creation verifies subscription and
environment ownership before insertion, including on duplicate recovery.

Repository mutations flush without committing. PostgreSQL row locks serialize
updates/rotations, with existing identity-map state refreshed when the lock is
acquired. SQLite tests prove durability/rollback and ownership behavior; they do
not prove PostgreSQL concurrent-rotation behavior. Existing secret sealing and
production fail-closed behavior are retained. No new fallback key was added.
Description/configuration schema migration, API RBAC/audit integration and
PostgreSQL concurrency tests are still required before sub-part acceptance.


## Additional callback contracts

Voicemail publication recognizes `machine_start`, `machine_end_beep`,
`machine_end_silence` and `machine_end_other`. Unknown call SIDs or unknown
verdicts do not manufacture events. Unknown machine-prefixed verdicts retain the
legacy hangup behavior, but the log now describes that hangup rather than
asserting detection. A callback that arrives before its Call row exists is not
queued for later matching by this route; that reconciliation gap remains.

DTMF version one records only that input was received, once per call. Empty
input produces no event; non-DTMF or more than 64 characters is rejected. Raw
keys are neither included in the event nor written by the IVR-step log. IVR and
inbound duplicate-SID requests cannot mint stream access using another tenant's
destination number; mismatches return 404. The inbound duplicate-creation race
refreshes its tenant after rollback before accessing expired ORM attributes.

`CallStatus.TRANSFERRED` proves provider acceptance, not human connection. The
publication adapter now maps it to `transfer_started`, correcting the earlier
latent `transfer_completed` mapping. Confirmed pickup remains a transfer-result
fact. A rejected late `answered` callback cannot emit CRM completion. A real
failure verdict replaces a prior inferred failure reason, so a later answer
cannot treat the confirmed failure as a correctable guess. Inferred failures
alone are not published as confirmed customer transfer-failure events.

Status and transfer-result queries now acquire PostgreSQL row locks and refresh
identity-map state before applying transitions. SQLite callback tests pass;
this is not a PostgreSQL concurrent-callback certification. The transfer-result
handler accepts initiated/ringing callbacks, but configuring the provider to
send those callbacks is not established by these HTTP contract tests. Direct
transfer initiation, reconciliation and recording producers still need wiring.

````````

## `reports/part1/build_report.py`

SHA-256: `9304b23dfc4b08717b7adaac6eabe7801069c3a89ffc10637a4c5138d1ae8818`

````````
"""Rebuild the complete-source PART 1 work-in-progress delivery."""
from pathlib import Path
import hashlib
import json
import zipfile

root = Path(__file__).resolve().parents[2]
files = [
    'app/webhooks/call_event_catalog.py',
    'app/webhooks/call_event_bridge.py',
    'app/webhooks/delivery.py',
    'app/webhooks/repository.py',
    'app/telephony/call_state.py',
    'app/telephony/twilio_handler.py',
    'tests/webhooks/__init__.py',
    'tests/webhooks/test_call_event_bridge.py',
    'tests/webhooks/test_webhook_lifecycle_real.py',
    'tests/webhooks/test_webhook_isolation.py',
    'docs/WEBHOOKS.md',
    'reports/part1/build_report.py',
]
summary = '''# PART 1 — implementation started; acceptance NOT COMPLETE

## Status

This is a complete-source delivery of the implemented slices of **1A**,
not a completed PART 1 report or a sub-part acceptance certificate.
No PART 2 work was started. No facade allowlist entry was removed.
No completion commit was made: the required single 1A commit remains pending
until the whole sub-part is complete. The pre-existing staged A/B additions
remain untouched.

| Sub-part | Status |
| --- | --- |
| 1A | PARTIAL: catalog, transactional bridge, selected Twilio hooks, wire-receipt tests |
| 1C | NOT STARTED: durable post-call pipeline and analysis service |
| 1D | NOT STARTED: unified PII, retention enforcement, recording policy |
| 1E | NOT STARTED: enterprise durable request state and audit |
| 1B | NOT STARTED: batch/campaign engine integration and shared DNC/limits |
| 1F | NOT STARTED: Salesforce provider and generic CRM writeback |
| 1G | NOT STARTED: runtime experiment assignment and real promotion |

## Implemented behavior

- Version-one schemas for twelve customer event names, with strict reference-only
  payloads. Defining a schema does not mean every event is wired at runtime.
- Existing transactional outbox publication with key `call:{id}:{event}:v1`.
  Existing dispatcher, delivery ledger, signing and retry mechanisms are reused.
- Inbound creation, Twilio status transition, media-error finalization and transfer
  result callbacks publish before commit. Failures propagate; no background-task
  publication or process-local authoritative queue was introduced.
- Pure transition rules remain unchanged; async publication is an explicit adapter.
- HTTP delivery now also emits the timestamp present in its signature header.
- Added tests for duplicate suppression, rollback, publication failure, strict
  payloads, real status callback, subscription tenant/environment/event filtering,
  local socket receipt/signature, SSRF rejection and 503 retry exhaustion.

## Latest continuation: additional callback producers and transfer truth

- Recognized voicemail verdicts publish one owned, replay-safe event. Unknown
  calls/verdicts do not fabricate events; hangup behavior is preserved.
- IVR publishes reference-only DTMF occurrence events, without raw digits.
  Invalid/oversized input is rejected; empty input is not a DTMF event.
- IVR/inbound duplicate SID cannot mint stream access under another tenant's To.
  The inbound creation-race rollback now refreshes expired tenant state.
- Corrected a latent mapping from TRANSFERRED to transfer_completed: provider
  acceptance only means transfer_started. Human pickup requires evidence.
- A rejected late answered callback no longer invokes the CRM completion hook.
  A confirmed failure supersedes a local inference and cannot be undone as a
  guess by a subsequent answer. Ringing support is tested at the HTTP handler;
  provider configuration to emit those callbacks is NOT claimed verified.
- Status/transfer-result lookups lock rows and refresh loaded state. Tests use
  SQLite; PostgreSQL concurrency proof remains outstanding.

Command:
`OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 .venv/bin/python -m pytest tests/webhooks tests/outbox tests/operations/test_notification_webhook_email.py tests/test_call_state.py tests/test_call_callbacks.py tests/test_transfer.py tests/telephony/test_lead_lifecycle_callbacks.py -q --junitxml=reports/part1/producers.xml`

**180 passed, 849 warnings; no failures/errors/skips.** Latest truth gate:
**41 passed, 59 warnings**. Latest selected Ruff: **All checks passed**.
These are separate runs. Earlier 114/87-pass runs below are historical, not
additional unique passes. No tests were disabled, removed or weakened.

No new migration, router or completion commit was made. The legacy lifecycle
API, unification migration and remaining producer paths still block 1A acceptance.

## Earlier continuation: repository and transport

Repository CRUD/rotation and stricter delivery ownership checks are now implemented.
Mutation queries use explicit tenant/environment scope and PostgreSQL row locks.
Existing identity-map state is refreshed when acquiring the lock. No new tables,
parallel repository, encryption fallback or process-local authoritative state.

Transport supports configurable headers/timeouts and real status/latency/body
snippet diagnostics. Protected headers and CRLF injection are rejected, redirects
are disabled per request even for an injected redirect-following client, and
informational HTTP responses are no longer classified as delivery success.
These options still need persistence and API/dispatcher wiring.

Latest command:
`OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 .venv/bin/python -m pytest tests/webhooks tests/outbox tests/operations/test_notification_webhook_email.py tests/test_call_state.py tests/telephony/test_lead_lifecycle_callbacks.py -q --junitxml=reports/part1/repository.xml`

**114 passed, 356 warnings; no failures/errors/skips.** Current `make verify-truth`:
**41 passed, 59 warnings**. Current selected Ruff: **All checks passed**.
These are separate runs, not an additive unique-test total. The old 87-pass run
below is retained historical evidence, superseded by the broader 114-pass run.

`test_webhook_isolation.py` currently proves repository-level domain 404s, not
HTTP API RBAC/isolation. PostgreSQL multi-worker behavior has not been exercised.
Description/model migration, full lifecycle API replacement and audited API
rotation remain pending. No 1A completion commit or allowlist removal yet.

## Earlier verification (first slice)

Commands were run from the repository root with the restored Python 3.12 venv.

1. `OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 .venv/bin/python -m pytest tests/webhooks tests/outbox tests/test_call_state.py tests/telephony/test_lead_lifecycle_callbacks.py -q --junitxml=reports/part1/webhooks.xml`
   **87 passed, 253 warnings; no failures/errors/skips.**
2. `PATH=$PWD/.venv/bin:$PATH OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 make verify-truth`
   **41 passed, 59 warnings.** Report these as separate runs, not a deduplicated suite count.
3. Configured Ruff on the five changed production modules and tests/webhooks:
   **All checks passed.**
4. Runtime route enumeration: **1156 routes**; no new router added.
5. `alembic heads`: **0049_runtime_schema_alignment (head)**, one head.
6. `make contracts-check`: initially failed because protoc was absent in the
   restored environment. Installed protobuf-compiler, reran, **PASS: five proto
   files compile; enum vocabulary and tenant scoping checks pass**. Both logs retained.

The local receiver is an actual loopback HTTP server. A test-only transport
relays the signed request to it after production URL validation. This verifies
actual bytes and signature receipt, not public HTTPS/TLS or hosted egress.
Retry exhaustion uses real HTTP-result classification through a recording fake;
round numbers are set explicitly to test the existing delivery budget, not to
claim a multi-worker scheduler concurrency test.

## Remaining acceptance gaps — do not mark 1A or PART 1 PASS

- Legacy WebhookEndpoint/DeliveryAttempt and lifecycle API are unchanged. No new
  migration, canonical-model fields, API CRUD/rotation, test-send diagnostics,
  delivery API, replay/redrive or API-level two-tenant 404 acceptance yet.
- Callback reconciliation, direct transfer initiation, recording, batch and
  agent-publication producer paths are not fully wired. IVR DTMF and recognized
  voicemail callbacks are now wired; unmatched early callbacks remain a gap.
- Subscription settings persistence and API/dispatcher wiring remain unfinished;
  transport support and request/response contracts are now implemented.
- The existing delivery URL check is static: DNS resolution/rebinding protection
  is not proven. No SSRF protection was weakened by these tests.
- Outbox events without matched subscriptions close under the existing
  `no_subscriptions` classification; this is not proof of customer HTTP receipt.
- Secrets still use the existing repository implementation; no new encryption
  or fallback was added. Full requested secret-handling review remains pending.
- Migration upgrade/downgrade acceptance was NOT RUN: no migration was created,
  and no isolated PostgreSQL validation database was provisioned in this slice.
- Remaining named PART 1 acceptance modules and live CRM/Salesforce commands
  were NOT RUN. They are not reported as passing or as credential skips.
- PART 1's strict file tree omits canonical `app/db/models.py` and the existing
  outbox dispatcher. Extending these may require a scope decision for later
  work. Correction to the earlier scope note: webhook repository.py IS listed
  in the uploaded tree; its inclusion was initially overlooked.
- No external-provider live test was executed; no LIVE/production-ready claim.

## Complete final files

All created/changed implementation, test and documentation files in this slice
are reproduced below, without shortened file bodies. The report itself is not
recursively embedded. The companion ZIP also contains these exact files, this
report and the actual command logs/XML.

'''
parts = [summary]
manifest = []
for name in files:
    body = (root / name).read_text()
    assert '\x00' not in body, name
    digest = hashlib.sha256((root / name).read_bytes()).hexdigest()
    manifest.append({'path': name, 'sha256': digest})
    fence = '`' * 8
    parts.append(f'\n## `{name}`\n\nSHA-256: `{digest}`\n\n{fence}\n{body}\n{fence}\n')
logs = ['webhooks.log', 'truth-after.log', 'ruff.log', 'routes.log',
        'heads-current.log', 'contracts.log', 'contracts-after-install.log',
        'repository.log', 'truth-repository.log', 'ruff-repository.log',
        'producers.log', 'truth-producers.log', 'ruff-producers.log']
parts.append('\n# Actual command output\n')
for name in logs:
    parts.append(f'\n## {name}\n\n````````text\n{(root / "reports/part1" / name).read_text()}\n````````\n')
report = root / 'reports/PART_1_REPORT.md'
report.write_text(''.join(parts))
(root / 'reports/part1/source-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
archive = root / 'reports/PART_1_WORK_IN_PROGRESS.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as bundle:
    for name in files + ['reports/PART_1_REPORT.md', 'reports/part1/source-manifest.json',
                         'reports/part1/webhooks.xml', 'reports/part1/repository.xml',
                         'reports/part1/producers.xml']:
        bundle.write(root / name, name)
    for name in logs:
        bundle.write(root / 'reports/part1' / name, 'reports/part1/' + name)
print(f'{report}: {report.stat().st_size} bytes')
print(f'{archive}: {archive.stat().st_size} bytes')

````````

# Actual command output

## webhooks.log

````````text
........................................................................ [ 82%]
...............                                                          [100%]
=============================== warnings summary ===============================
tests/webhooks/test_call_event_bridge.py: 8 warnings
tests/webhooks/test_webhook_lifecycle_real.py: 2 warnings
tests/outbox/test_delivery.py: 1 warning
tests/outbox/test_isolation.py: 2 warnings
tests/telephony/test_lead_lifecycle_callbacks.py: 8 warnings
  /home/user/voxdesk-call-ainul-islam/voxdesk-call/app/db/models.py:2938: DeprecationWarning: datetime.datetime.utcnow() is deprecated and scheduled for removal in a future version. Use timezone-aware objects to represent datetimes in UTC: datetime.datetime.now(datetime.UTC).
    now = datetime.utcnow()

tests/webhooks/test_call_event_bridge.py: 34 warnings
tests/webhooks/test_webhook_lifecycle_real.py: 17 warnings
tests/outbox/test_delivery.py: 5 warnings
tests/outbox/test_isolation.py: 6 warnings
tests/telephony/test_lead_lifecycle_callbacks.py: 60 warnings
  /home/user/voxdesk-call-ainul-islam/voxdesk-call/.venv/lib/python3.12/site-packages/sqlalchemy/sql/schema.py:3596: DeprecationWarning: datetime.datetime.utcnow() is deprecated and scheduled for removal in a future version. Use timezone-aware objects to represent datetimes in UTC: datetime.datetime.now(datetime.UTC).
    return util.wrap_callable(lambda ctx: fn(), fn)  # type: ignore

tests/webhooks/test_call_event_bridge.py: 8 warnings
tests/webhooks/test_webhook_lifecycle_real.py: 2 warnings
tests/outbox/test_delivery.py: 1 warning
tests/outbox/test_isolation.py: 2 warnings
tests/telephony/test_lead_lifecycle_callbacks.py: 8 warnings
  /home/user/voxdesk-call-ainul-islam/voxdesk-call/app/db/models.py:2968: DeprecationWarning: datetime.datetime.utcnow() is deprecated and scheduled for removal in a future version. Use timezone-aware objects to represent datetimes in UTC: datetime.datetime.now(datetime.UTC).
    now = datetime.utcnow()

tests/webhooks/test_call_event_bridge.py: 7 warnings
tests/webhooks/test_webhook_lifecycle_real.py: 2 warnings
tests/telephony/test_lead_lifecycle_callbacks.py: 8 warnings
  /home/user/voxdesk-call-ainul-islam/voxdesk-call/tests/conftest.py:569: DeprecationWarning: datetime.datetime.utcnow() is deprecated and scheduled for removal in a future version. Use timezone-aware objects to represent datetimes in UTC: datetime.datetime.now(datetime.UTC).
    "started_at": datetime.utcnow(),

tests/webhooks/test_call_event_bridge.py: 4 warnings
tests/webhooks/test_webhook_lifecycle_real.py: 1 warning
tests/test_call_state.py: 13 warnings
tests/telephony/test_lead_lifecycle_callbacks.py: 8 warnings
  /home/user/voxdesk-call-ainul-islam/voxdesk-call/app/telephony/call_state.py:260: DeprecationWarning: datetime.datetime.utcnow() is deprecated and scheduled for removal in a future version. Use timezone-aware objects to represent datetimes in UTC: datetime.datetime.now(datetime.UTC).
    call.ended_at = ended_at or datetime.utcnow()

tests/webhooks/test_call_event_bridge.py::test_real_status_route_is_replay_safe
tests/webhooks/test_call_event_bridge.py::test_real_status_route_is_replay_safe
tests/webhooks/test_call_event_bridge.py::test_real_status_route_is_replay_safe
tests/webhooks/test_call_event_bridge.py::test_real_status_route_is_replay_safe
tests/webhooks/test_call_event_bridge.py::test_real_status_route_is_replay_safe
tests/webhooks/test_call_event_bridge.py::test_real_status_route_is_replay_safe
  /home/user/voxdesk-call-ainul-islam/voxdesk-call/.venv/lib/python3.12/site-packages/pydantic/_internal/_config.py:295: PydanticDeprecatedSince20: Support for class-based `config` is deprecated, use ConfigDict instead. Deprecated in Pydantic V2.0 to be removed in V3.0. See Pydantic V2 Migration Guide at https://errors.pydantic.dev/2.10/migration/
    warnings.warn(DEPRECATION_MESSAGE, DeprecationWarning)

tests/test_call_state.py: 27 warnings
  /home/user/voxdesk-call-ainul-islam/voxdesk-call/tests/test_call_state.py:27: DeprecationWarning: datetime.datetime.utcnow() is deprecated and scheduled for removal in a future version. Use timezone-aware objects to represent datetimes in UTC: datetime.datetime.now(datetime.UTC).
    started_at=datetime.utcnow(),

tests/test_call_state.py::test_ended_at_can_be_supplied_explicitly
  /home/user/voxdesk-call-ainul-islam/voxdesk-call/tests/test_call_state.py:132: DeprecationWarning: datetime.datetime.utcnow() is deprecated and scheduled for removal in a future version. Use timezone-aware objects to represent datetimes in UTC: datetime.datetime.now(datetime.UTC).
    when = datetime.utcnow() - timedelta(minutes=5)

tests/telephony/test_lead_lifecycle_callbacks.py: 12 warnings
  /home/user/voxdesk-call-ainul-islam/voxdesk-call/app/leads/models.py:25: DeprecationWarning: datetime.datetime.utcnow() is deprecated and scheduled for removal in a future version. Use timezone-aware objects to represent datetimes in UTC: datetime.datetime.now(datetime.UTC).
    return datetime.utcnow()

-- Docs: https://docs.pytest.org/en/stable/how-to/capture-warnings.html
- generated xml file: /home/user/voxdesk-call-ainul-islam/voxdesk-call/reports/part1/webhooks.xml -
87 passed, 253 warnings in 20.36s

````````

## truth-after.log

````````text
python scripts/verify_no_filler.py
[]
python scripts/verify_no_fake_success.py
[]
python scripts/verify_retired_references.py
[]
python scripts/verify_no_null_bytes.py
[]
python scripts/strip_padding_markers.py --check
{}
python -m pytest tests/truth -q
.........................................                                [100%]
=============================== warnings summary ===============================
.venv/lib/python3.12/site-packages/pydantic/_internal/_config.py:295
.venv/lib/python3.12/site-packages/pydantic/_internal/_config.py:295
.venv/lib/python3.12/site-packages/pydantic/_internal/_config.py:295
.venv/lib/python3.12/site-packages/pydantic/_internal/_config.py:295
.venv/lib/python3.12/site-packages/pydantic/_internal/_config.py:295
.venv/lib/python3.12/site-packages/pydantic/_internal/_config.py:295
  /home/user/voxdesk-call-ainul-islam/voxdesk-call/.venv/lib/python3.12/site-packages/pydantic/_internal/_config.py:295: PydanticDeprecatedSince20: Support for class-based `config` is deprecated, use ConfigDict instead. Deprecated in Pydantic V2.0 to be removed in V3.0. See Pydantic V2 Migration Guide at https://errors.pydantic.dev/2.10/migration/
    warnings.warn(DEPRECATION_MESSAGE, DeprecationWarning)

tests/truth/test_part0_authorized_repairs.py::test_legacy_test_creation_is_scoped_and_cannot_issue_fake_session
tests/truth/test_part0_authorized_repairs.py::test_legacy_test_creation_is_scoped_and_cannot_issue_fake_session
tests/truth/test_part0_authorized_repairs.py::test_dnc_and_audit_commit_together
tests/truth/test_part0_authorized_repairs.py::test_failed_audit_cannot_commit_dnc
tests/truth/test_part0_authorized_repairs.py::test_qms_http_unavailable_is_not_empty_success_and_is_tenant_scoped
tests/truth/test_part0_authorized_repairs.py::test_qms_http_unavailable_is_not_empty_success_and_is_tenant_scoped
tests/truth/test_part0_authorized_repairs.py::test_replay_does_not_manufacture_a_signed_recording_link
  /home/user/voxdesk-call-ainul-islam/voxdesk-call/app/db/models.py:2938: DeprecationWarning: datetime.datetime.utcnow() is deprecated and scheduled for removal in a future version. Use timezone-aware objects to represent datetimes in UTC: datetime.datetime.now(datetime.UTC).
    now = datetime.utcnow()

tests/truth/test_part0_authorized_repairs.py: 31 warnings
  /home/user/voxdesk-call-ainul-islam/voxdesk-call/.venv/lib/python3.12/site-packages/sqlalchemy/sql/schema.py:3596: DeprecationWarning: datetime.datetime.utcnow() is deprecated and scheduled for removal in a future version. Use timezone-aware objects to represent datetimes in UTC: datetime.datetime.now(datetime.UTC).
    return util.wrap_callable(lambda ctx: fn(), fn)  # type: ignore

tests/truth/test_part0_authorized_repairs.py::test_legacy_test_creation_is_scoped_and_cannot_issue_fake_session
tests/truth/test_part0_authorized_repairs.py::test_legacy_test_creation_is_scoped_and_cannot_issue_fake_session
tests/truth/test_part0_authorized_repairs.py::test_dnc_and_audit_commit_together
tests/truth/test_part0_authorized_repairs.py::test_failed_audit_cannot_commit_dnc
tests/truth/test_part0_authorized_repairs.py::test_qms_http_unavailable_is_not_empty_success_and_is_tenant_scoped
tests/truth/test_part0_authorized_repairs.py::test_qms_http_unavailable_is_not_empty_success_and_is_tenant_scoped
tests/truth/test_part0_authorized_repairs.py::test_replay_does_not_manufacture_a_signed_recording_link
  /home/user/voxdesk-call-ainul-islam/voxdesk-call/app/db/models.py:2968: DeprecationWarning: datetime.datetime.utcnow() is deprecated and scheduled for removal in a future version. Use timezone-aware objects to represent datetimes in UTC: datetime.datetime.now(datetime.UTC).
    now = datetime.utcnow()

tests/truth/test_part0_authorized_repairs.py::test_legacy_test_creation_is_scoped_and_cannot_issue_fake_session
tests/truth/test_part0_authorized_repairs.py::test_legacy_test_creation_is_scoped_and_cannot_issue_fake_session
tests/truth/test_part0_authorized_repairs.py::test_dnc_and_audit_commit_together
tests/truth/test_part0_authorized_repairs.py::test_failed_audit_cannot_commit_dnc
tests/truth/test_part0_authorized_repairs.py::test_qms_http_unavailable_is_not_empty_success_and_is_tenant_scoped
tests/truth/test_part0_authorized_repairs.py::test_qms_http_unavailable_is_not_empty_success_and_is_tenant_scoped
tests/truth/test_part0_authorized_repairs.py::test_replay_does_not_manufacture_a_signed_recording_link
  /home/user/voxdesk-call-ainul-islam/voxdesk-call/app/db/models.py:3023: DeprecationWarning: datetime.datetime.utcnow() is deprecated and scheduled for removal in a future version. Use timezone-aware objects to represent datetimes in UTC: datetime.datetime.now(datetime.UTC).
    now = datetime.utcnow()

tests/truth/test_part0_authorized_repairs.py::test_replay_does_not_manufacture_a_signed_recording_link
  /home/user/voxdesk-call-ainul-islam/voxdesk-call/tests/conftest.py:569: DeprecationWarning: datetime.datetime.utcnow() is deprecated and scheduled for removal in a future version. Use timezone-aware objects to represent datetimes in UTC: datetime.datetime.now(datetime.UTC).
    "started_at": datetime.utcnow(),

-- Docs: https://docs.pytest.org/en/stable/how-to/capture-warnings.html
41 passed, 59 warnings in 20.48s

````````

## ruff.log

````````text
All checks passed!

````````

## routes.log

````````text
[2m2026-10-07T02:56:24.982940Z[0m [[32m[1minfo     [0m] [1mdashboard.not_built           [0m [36mcanonical[0m=[35mdashboard (Vite)[0m [36mdist_dir[0m=[35m/home/user/voxdesk-call-ainul-islam/voxdesk-call/dashboard/dist[0m [36mshadow_next_present[0m=[35mFalse[0m
routes: 1156

````````

## heads-current.log

````````text
0049_runtime_schema_alignment (head)

````````

## contracts.log

````````text
python scripts/verify_contracts.py
contracts: 5 .proto files
FAIL  contracts                [compile] protoc not found; install protobuf-compiler or pass --protoc / set VOXDESK_PROTOC
contract verification FAILED: 1 problem(s).
make: *** [Makefile:46: contracts-check] Error 1

````````

## contracts-after-install.log

````````text
python scripts/verify_contracts.py
contracts: 5 .proto files
OK: contracts compile; enum vocabulary matches app.db.models; every operational message is tenant-scoped.

````````

## repository.log

````````text
........................................................................ [ 63%]
..........................................                               [100%]
=============================== warnings summary ===============================
tests/webhooks/test_call_event_bridge.py: 8 warnings
tests/webhooks/test_webhook_isolation.py: 16 warnings
tests/webhooks/test_webhook_lifecycle_real.py: 2 warnings
tests/outbox/test_delivery.py: 1 warning
tests/outbox/test_isolation.py: 2 warnings
tests/operations/test_notification_webhook_email.py: 8 warnings
tests/telephony/test_lead_lifecycle_callbacks.py: 8 warnings
  /home/user/voxdesk-call-ainul-islam/voxdesk-call/app/db/models.py:2938: DeprecationWarning: datetime.datetime.utcnow() is deprecated and scheduled for removal in a future version. Use timezone-aware objects to represent datetimes in UTC: datetime.datetime.now(datetime.UTC).
    now = datetime.utcnow()

tests/webhooks/test_call_event_bridge.py: 34 warnings
tests/webhooks/test_webhook_isolation.py: 32 warnings
tests/webhooks/test_webhook_lifecycle_real.py: 17 warnings
tests/outbox/test_delivery.py: 5 warnings
tests/outbox/test_isolation.py: 6 warnings
tests/operations/test_notification_webhook_email.py: 21 warnings
tests/telephony/test_lead_lifecycle_callbacks.py: 60 warnings
  /home/user/voxdesk-call-ainul-islam/voxdesk-call/.venv/lib/python3.12/site-packages/sqlalchemy/sql/schema.py:3596: DeprecationWarning: datetime.datetime.utcnow() is deprecated and scheduled for removal in a future version. Use timezone-aware objects to represent datetimes in UTC: datetime.datetime.now(datetime.UTC).
    return util.wrap_callable(lambda ctx: fn(), fn)  # type: ignore

tests/webhooks/test_call_event_bridge.py: 8 warnings
tests/webhooks/test_webhook_isolation.py: 16 warnings
tests/webhooks/test_webhook_lifecycle_real.py: 2 warnings
tests/outbox/test_delivery.py: 1 warning
tests/outbox/test_isolation.py: 2 warnings
tests/operations/test_notification_webhook_email.py: 8 warnings
tests/telephony/test_lead_lifecycle_callbacks.py: 8 warnings
  /home/user/voxdesk-call-ainul-islam/voxdesk-call/app/db/models.py:2968: DeprecationWarning: datetime.datetime.utcnow() is deprecated and scheduled for removal in a future version. Use timezone-aware objects to represent datetimes in UTC: datetime.datetime.now(datetime.UTC).
    now = datetime.utcnow()

tests/webhooks/test_call_event_bridge.py: 7 warnings
tests/webhooks/test_webhook_lifecycle_real.py: 2 warnings
tests/operations/test_notification_webhook_email.py: 1 warning
tests/telephony/test_lead_lifecycle_callbacks.py: 8 warnings
  /home/user/voxdesk-call-ainul-islam/voxdesk-call/tests/conftest.py:569: DeprecationWarning: datetime.datetime.utcnow() is deprecated and scheduled for removal in a future version. Use timezone-aware objects to represent datetimes in UTC: datetime.datetime.now(datetime.UTC).
    "started_at": datetime.utcnow(),

tests/webhooks/test_call_event_bridge.py: 4 warnings
tests/webhooks/test_webhook_lifecycle_real.py: 1 warning
tests/test_call_state.py: 13 warnings
tests/telephony/test_lead_lifecycle_callbacks.py: 8 warnings
  /home/user/voxdesk-call-ainul-islam/voxdesk-call/app/telephony/call_state.py:261: DeprecationWarning: datetime.datetime.utcnow() is deprecated and scheduled for removal in a future version. Use timezone-aware objects to represent datetimes in UTC: datetime.datetime.now(datetime.UTC).
    call.ended_at = ended_at or datetime.utcnow()

tests/webhooks/test_call_event_bridge.py::test_real_status_route_is_replay_safe
tests/webhooks/test_call_event_bridge.py::test_real_status_route_is_replay_safe
tests/webhooks/test_call_event_bridge.py::test_real_status_route_is_replay_safe
tests/webhooks/test_call_event_bridge.py::test_real_status_route_is_replay_safe
tests/webhooks/test_call_event_bridge.py::test_real_status_route_is_replay_safe
tests/webhooks/test_call_event_bridge.py::test_real_status_route_is_replay_safe
  /home/user/voxdesk-call-ainul-islam/voxdesk-call/.venv/lib/python3.12/site-packages/pydantic/_internal/_config.py:295: PydanticDeprecatedSince20: Support for class-based `config` is deprecated, use ConfigDict instead. Deprecated in Pydantic V2.0 to be removed in V3.0. See Pydantic V2 Migration Guide at https://errors.pydantic.dev/2.10/migration/
    warnings.warn(DEPRECATION_MESSAGE, DeprecationWarning)

tests/operations/test_notification_webhook_email.py::test_notification_replay_keeps_tenant_and_environment
  /home/user/voxdesk-call-ainul-islam/voxdesk-call/app/db/models.py:3023: DeprecationWarning: datetime.datetime.utcnow() is deprecated and scheduled for removal in a future version. Use timezone-aware objects to represent datetimes in UTC: datetime.datetime.now(datetime.UTC).
    now = datetime.utcnow()

tests/test_call_state.py: 27 warnings
  /home/user/voxdesk-call-ainul-islam/voxdesk-call/tests/test_call_state.py:27: DeprecationWarning: datetime.datetime.utcnow() is deprecated and scheduled for removal in a future version. Use timezone-aware objects to represent datetimes in UTC: datetime.datetime.now(datetime.UTC).
    started_at=datetime.utcnow(),

tests/test_call_state.py::test_ended_at_can_be_supplied_explicitly
  /home/user/voxdesk-call-ainul-islam/voxdesk-call/tests/test_call_state.py:132: DeprecationWarning: datetime.datetime.utcnow() is deprecated and scheduled for removal in a future version. Use timezone-aware objects to represent datetimes in UTC: datetime.datetime.now(datetime.UTC).
    when = datetime.utcnow() - timedelta(minutes=5)

tests/telephony/test_lead_lifecycle_callbacks.py: 12 warnings
  /home/user/voxdesk-call-ainul-islam/voxdesk-call/app/leads/models.py:25: DeprecationWarning: datetime.datetime.utcnow() is deprecated and scheduled for removal in a future version. Use timezone-aware objects to represent datetimes in UTC: datetime.datetime.now(datetime.UTC).
    return datetime.utcnow()

-- Docs: https://docs.pytest.org/en/stable/how-to/capture-warnings.html
- generated xml file: /home/user/voxdesk-call-ainul-islam/voxdesk-call/reports/part1/repository.xml -
114 passed, 356 warnings in 29.41s

````````

## truth-repository.log

````````text
python scripts/verify_no_filler.py
[]
python scripts/verify_no_fake_success.py
[]
python scripts/verify_retired_references.py
[]
python scripts/verify_no_null_bytes.py
[]
python scripts/strip_padding_markers.py --check
{}
python -m pytest tests/truth -q
.........................................                                [100%]
=============================== warnings summary ===============================
.venv/lib/python3.12/site-packages/pydantic/_internal/_config.py:295
.venv/lib/python3.12/site-packages/pydantic/_internal/_config.py:295
.venv/lib/python3.12/site-packages/pydantic/_internal/_config.py:295
.venv/lib/python3.12/site-packages/pydantic/_internal/_config.py:295
.venv/lib/python3.12/site-packages/pydantic/_internal/_config.py:295
.venv/lib/python3.12/site-packages/pydantic/_internal/_config.py:295
  /home/user/voxdesk-call-ainul-islam/voxdesk-call/.venv/lib/python3.12/site-packages/pydantic/_internal/_config.py:295: PydanticDeprecatedSince20: Support for class-based `config` is deprecated, use ConfigDict instead. Deprecated in Pydantic V2.0 to be removed in V3.0. See Pydantic V2 Migration Guide at https://errors.pydantic.dev/2.10/migration/
    warnings.warn(DEPRECATION_MESSAGE, DeprecationWarning)

tests/truth/test_part0_authorized_repairs.py::test_legacy_test_creation_is_scoped_and_cannot_issue_fake_session
tests/truth/test_part0_authorized_repairs.py::test_legacy_test_creation_is_scoped_and_cannot_issue_fake_session
tests/truth/test_part0_authorized_repairs.py::test_dnc_and_audit_commit_together
tests/truth/test_part0_authorized_repairs.py::test_failed_audit_cannot_commit_dnc
tests/truth/test_part0_authorized_repairs.py::test_qms_http_unavailable_is_not_empty_success_and_is_tenant_scoped
tests/truth/test_part0_authorized_repairs.py::test_qms_http_unavailable_is_not_empty_success_and_is_tenant_scoped
tests/truth/test_part0_authorized_repairs.py::test_replay_does_not_manufacture_a_signed_recording_link
  /home/user/voxdesk-call-ainul-islam/voxdesk-call/app/db/models.py:2938: DeprecationWarning: datetime.datetime.utcnow() is deprecated and scheduled for removal in a future version. Use timezone-aware objects to represent datetimes in UTC: datetime.datetime.now(datetime.UTC).
    now = datetime.utcnow()

tests/truth/test_part0_authorized_repairs.py: 31 warnings
  /home/user/voxdesk-call-ainul-islam/voxdesk-call/.venv/lib/python3.12/site-packages/sqlalchemy/sql/schema.py:3596: DeprecationWarning: datetime.datetime.utcnow() is deprecated and scheduled for removal in a future version. Use timezone-aware objects to represent datetimes in UTC: datetime.datetime.now(datetime.UTC).
    return util.wrap_callable(lambda ctx: fn(), fn)  # type: ignore

tests/truth/test_part0_authorized_repairs.py::test_legacy_test_creation_is_scoped_and_cannot_issue_fake_session
tests/truth/test_part0_authorized_repairs.py::test_legacy_test_creation_is_scoped_and_cannot_issue_fake_session
tests/truth/test_part0_authorized_repairs.py::test_dnc_and_audit_commit_together
tests/truth/test_part0_authorized_repairs.py::test_failed_audit_cannot_commit_dnc
tests/truth/test_part0_authorized_repairs.py::test_qms_http_unavailable_is_not_empty_success_and_is_tenant_scoped
tests/truth/test_part0_authorized_repairs.py::test_qms_http_unavailable_is_not_empty_success_and_is_tenant_scoped
tests/truth/test_part0_authorized_repairs.py::test_replay_does_not_manufacture_a_signed_recording_link
  /home/user/voxdesk-call-ainul-islam/voxdesk-call/app/db/models.py:2968: DeprecationWarning: datetime.datetime.utcnow() is deprecated and scheduled for removal in a future version. Use timezone-aware objects to represent datetimes in UTC: datetime.datetime.now(datetime.UTC).
    now = datetime.utcnow()

tests/truth/test_part0_authorized_repairs.py::test_legacy_test_creation_is_scoped_and_cannot_issue_fake_session
tests/truth/test_part0_authorized_repairs.py::test_legacy_test_creation_is_scoped_and_cannot_issue_fake_session
tests/truth/test_part0_authorized_repairs.py::test_dnc_and_audit_commit_together
tests/truth/test_part0_authorized_repairs.py::test_failed_audit_cannot_commit_dnc
tests/truth/test_part0_authorized_repairs.py::test_qms_http_unavailable_is_not_empty_success_and_is_tenant_scoped
tests/truth/test_part0_authorized_repairs.py::test_qms_http_unavailable_is_not_empty_success_and_is_tenant_scoped
tests/truth/test_part0_authorized_repairs.py::test_replay_does_not_manufacture_a_signed_recording_link
  /home/user/voxdesk-call-ainul-islam/voxdesk-call/app/db/models.py:3023: DeprecationWarning: datetime.datetime.utcnow() is deprecated and scheduled for removal in a future version. Use timezone-aware objects to represent datetimes in UTC: datetime.datetime.now(datetime.UTC).
    now = datetime.utcnow()

tests/truth/test_part0_authorized_repairs.py::test_replay_does_not_manufacture_a_signed_recording_link
  /home/user/voxdesk-call-ainul-islam/voxdesk-call/tests/conftest.py:569: DeprecationWarning: datetime.datetime.utcnow() is deprecated and scheduled for removal in a future version. Use timezone-aware objects to represent datetimes in UTC: datetime.datetime.now(datetime.UTC).
    "started_at": datetime.utcnow(),

-- Docs: https://docs.pytest.org/en/stable/how-to/capture-warnings.html
41 passed, 59 warnings in 20.65s

````````

## ruff-repository.log

````````text
All checks passed!

````````

## producers.log

````````text
........................................................................ [ 40%]
........................................................................ [ 80%]
....................................                                     [100%]
=============================== warnings summary ===============================
tests/webhooks/test_call_event_bridge.py: 30 warnings
tests/webhooks/test_webhook_isolation.py: 16 warnings
tests/webhooks/test_webhook_lifecycle_real.py: 2 warnings
tests/outbox/test_delivery.py: 1 warning
tests/outbox/test_isolation.py: 2 warnings
tests/operations/test_notification_webhook_email.py: 8 warnings
tests/test_call_callbacks.py: 16 warnings
tests/test_transfer.py: 28 warnings
tests/telephony/test_lead_lifecycle_callbacks.py: 8 warnings
  /home/user/voxdesk-call-ainul-islam/voxdesk-call/app/db/models.py:2938: DeprecationWarning: datetime.datetime.utcnow() is deprecated and scheduled for removal in a future version. Use timezone-aware objects to represent datetimes in UTC: datetime.datetime.now(datetime.UTC).
    now = datetime.utcnow()

tests/webhooks/test_call_event_bridge.py: 87 warnings
tests/webhooks/test_webhook_isolation.py: 32 warnings
tests/webhooks/test_webhook_lifecycle_real.py: 17 warnings
tests/outbox/test_delivery.py: 5 warnings
tests/outbox/test_isolation.py: 6 warnings
tests/operations/test_notification_webhook_email.py: 21 warnings
tests/test_call_callbacks.py: 92 warnings
tests/test_transfer.py: 74 warnings
tests/telephony/test_lead_lifecycle_callbacks.py: 60 warnings
  /home/user/voxdesk-call-ainul-islam/voxdesk-call/.venv/lib/python3.12/site-packages/sqlalchemy/sql/schema.py:3596: DeprecationWarning: datetime.datetime.utcnow() is deprecated and scheduled for removal in a future version. Use timezone-aware objects to represent datetimes in UTC: datetime.datetime.now(datetime.UTC).
    return util.wrap_callable(lambda ctx: fn(), fn)  # type: ignore

tests/webhooks/test_call_event_bridge.py: 30 warnings
tests/webhooks/test_webhook_isolation.py: 16 warnings
tests/webhooks/test_webhook_lifecycle_real.py: 2 warnings
tests/outbox/test_delivery.py: 1 warning
tests/outbox/test_isolation.py: 2 warnings
tests/operations/test_notification_webhook_email.py: 8 warnings
tests/test_call_callbacks.py: 16 warnings
tests/test_transfer.py: 28 warnings
tests/telephony/test_lead_lifecycle_callbacks.py: 8 warnings
  /home/user/voxdesk-call-ainul-islam/voxdesk-call/app/db/models.py:2968: DeprecationWarning: datetime.datetime.utcnow() is deprecated and scheduled for removal in a future version. Use timezone-aware objects to represent datetimes in UTC: datetime.datetime.now(datetime.UTC).
    now = datetime.utcnow()

tests/webhooks/test_call_event_bridge.py: 27 warnings
tests/webhooks/test_webhook_lifecycle_real.py: 2 warnings
tests/operations/test_notification_webhook_email.py: 1 warning
tests/telephony/test_lead_lifecycle_callbacks.py: 8 warnings
  /home/user/voxdesk-call-ainul-islam/voxdesk-call/tests/conftest.py:569: DeprecationWarning: datetime.datetime.utcnow() is deprecated and scheduled for removal in a future version. Use timezone-aware objects to represent datetimes in UTC: datetime.datetime.now(datetime.UTC).
    "started_at": datetime.utcnow(),

tests/webhooks/test_call_event_bridge.py: 4 warnings
tests/webhooks/test_webhook_lifecycle_real.py: 1 warning
tests/test_call_state.py: 13 warnings
tests/test_call_callbacks.py: 11 warnings
tests/telephony/test_lead_lifecycle_callbacks.py: 8 warnings
  /home/user/voxdesk-call-ainul-islam/voxdesk-call/app/telephony/call_state.py:261: DeprecationWarning: datetime.datetime.utcnow() is deprecated and scheduled for removal in a future version. Use timezone-aware objects to represent datetimes in UTC: datetime.datetime.now(datetime.UTC).
    call.ended_at = ended_at or datetime.utcnow()

tests/webhooks/test_call_event_bridge.py::test_real_status_route_is_replay_safe
tests/webhooks/test_call_event_bridge.py::test_real_status_route_is_replay_safe
tests/webhooks/test_call_event_bridge.py::test_real_status_route_is_replay_safe
tests/webhooks/test_call_event_bridge.py::test_real_status_route_is_replay_safe
tests/webhooks/test_call_event_bridge.py::test_real_status_route_is_replay_safe
tests/webhooks/test_call_event_bridge.py::test_real_status_route_is_replay_safe
  /home/user/voxdesk-call-ainul-islam/voxdesk-call/.venv/lib/python3.12/site-packages/pydantic/_internal/_config.py:295: PydanticDeprecatedSince20: Support for class-based `config` is deprecated, use ConfigDict instead. Deprecated in Pydantic V2.0 to be removed in V3.0. See Pydantic V2 Migration Guide at https://errors.pydantic.dev/2.10/migration/
    warnings.warn(DEPRECATION_MESSAGE, DeprecationWarning)

tests/webhooks/test_call_event_bridge.py: 1 warning
tests/test_call_callbacks.py: 4 warnings
tests/test_transfer.py: 7 warnings
  /home/user/voxdesk-call-ainul-islam/voxdesk-call/app/telephony/transfer_service.py:469: DeprecationWarning: datetime.datetime.utcnow() is deprecated and scheduled for removal in a future version. Use timezone-aware objects to represent datetimes in UTC: datetime.datetime.now(datetime.UTC).
    call.transfer_failed_at = datetime.utcnow()

tests/operations/test_notification_webhook_email.py::test_notification_replay_keeps_tenant_and_environment
  /home/user/voxdesk-call-ainul-islam/voxdesk-call/app/db/models.py:3023: DeprecationWarning: datetime.datetime.utcnow() is deprecated and scheduled for removal in a future version. Use timezone-aware objects to represent datetimes in UTC: datetime.datetime.now(datetime.UTC).
    now = datetime.utcnow()

tests/test_call_state.py: 27 warnings
  /home/user/voxdesk-call-ainul-islam/voxdesk-call/tests/test_call_state.py:27: DeprecationWarning: datetime.datetime.utcnow() is deprecated and scheduled for removal in a future version. Use timezone-aware objects to represent datetimes in UTC: datetime.datetime.now(datetime.UTC).
    started_at=datetime.utcnow(),

tests/test_call_state.py::test_ended_at_can_be_supplied_explicitly
  /home/user/voxdesk-call-ainul-islam/voxdesk-call/tests/test_call_state.py:132: DeprecationWarning: datetime.datetime.utcnow() is deprecated and scheduled for removal in a future version. Use timezone-aware objects to represent datetimes in UTC: datetime.datetime.now(datetime.UTC).
    when = datetime.utcnow() - timedelta(minutes=5)

tests/test_call_callbacks.py: 16 warnings
tests/test_transfer.py: 26 warnings
  /home/user/voxdesk-call-ainul-islam/voxdesk-call/tests/test_transfer.py:43: DeprecationWarning: datetime.datetime.utcnow() is deprecated and scheduled for removal in a future version. Use timezone-aware objects to represent datetimes in UTC: datetime.datetime.now(datetime.UTC).
    started_at=datetime.utcnow(),

tests/test_call_callbacks.py: 6 warnings
tests/test_transfer.py: 19 warnings
  /home/user/voxdesk-call-ainul-islam/voxdesk-call/app/telephony/transfer_service.py:288: DeprecationWarning: datetime.datetime.utcnow() is deprecated and scheduled for removal in a future version. Use timezone-aware objects to represent datetimes in UTC: datetime.datetime.now(datetime.UTC).
    now = datetime.utcnow()

tests/test_call_callbacks.py: 6 warnings
tests/test_transfer.py: 15 warnings
  /home/user/voxdesk-call-ainul-islam/voxdesk-call/app/telephony/transfer_service.py:340: DeprecationWarning: datetime.datetime.utcnow() is deprecated and scheduled for removal in a future version. Use timezone-aware objects to represent datetimes in UTC: datetime.datetime.now(datetime.UTC).
    call.transfer_started_at = datetime.utcnow()

tests/test_call_callbacks.py::test_case_a_transfer_then_stream_close_then_completed_then_dial_callback
tests/test_call_callbacks.py::test_case_b_dial_callback_then_completed
tests/test_call_callbacks.py::test_case_d_duplicate_completed_callbacks
tests/test_transfer.py::test_already_connected_call_reports_completed_not_a_new_transfer
tests/test_transfer.py::test_connected_callback_records_the_connection
tests/test_transfer.py::test_duplicate_connected_callback_changes_nothing
tests/test_transfer.py::test_failure_callback_after_connection_is_ignored
tests/test_transfer.py::test_transfer_writes_system_transcript_events
tests/test_transfer.py::test_duplicate_provider_events_do_not_duplicate_system_turns
  /home/user/voxdesk-call-ainul-islam/voxdesk-call/app/telephony/transfer_service.py:408: DeprecationWarning: datetime.datetime.utcnow() is deprecated and scheduled for removal in a future version. Use timezone-aware objects to represent datetimes in UTC: datetime.datetime.now(datetime.UTC).
    call.transfer_completed_at = datetime.utcnow()

tests/test_call_callbacks.py::test_duplicate_callbacks_do_not_regrade_a_lead
  /home/user/voxdesk-call-ainul-islam/voxdesk-call/tests/test_call_callbacks.py:312: DeprecationWarning: datetime.datetime.utcnow() is deprecated and scheduled for removal in a future version. Use timezone-aware objects to represent datetimes in UTC: datetime.datetime.now(datetime.UTC).
    started_at=datetime.utcnow(), lead_id=lead.id, lead_score=80,

tests/test_call_callbacks.py: 1 warning
tests/telephony/test_lead_lifecycle_callbacks.py: 12 warnings
  /home/user/voxdesk-call-ainul-islam/voxdesk-call/app/leads/models.py:25: DeprecationWarning: datetime.datetime.utcnow() is deprecated and scheduled for removal in a future version. Use timezone-aware objects to represent datetimes in UTC: datetime.datetime.now(datetime.UTC).
    return datetime.utcnow()

-- Docs: https://docs.pytest.org/en/stable/how-to/capture-warnings.html
- generated xml file: /home/user/voxdesk-call-ainul-islam/voxdesk-call/reports/part1/producers.xml -
180 passed, 849 warnings in 71.50s (0:01:11)

````````

## truth-producers.log

````````text
python scripts/verify_no_filler.py
[]
python scripts/verify_no_fake_success.py
[]
python scripts/verify_retired_references.py
[]
python scripts/verify_no_null_bytes.py
[]
python scripts/strip_padding_markers.py --check
{}
python -m pytest tests/truth -q
.........................................                                [100%]
=============================== warnings summary ===============================
.venv/lib/python3.12/site-packages/pydantic/_internal/_config.py:295
.venv/lib/python3.12/site-packages/pydantic/_internal/_config.py:295
.venv/lib/python3.12/site-packages/pydantic/_internal/_config.py:295
.venv/lib/python3.12/site-packages/pydantic/_internal/_config.py:295
.venv/lib/python3.12/site-packages/pydantic/_internal/_config.py:295
.venv/lib/python3.12/site-packages/pydantic/_internal/_config.py:295
  /home/user/voxdesk-call-ainul-islam/voxdesk-call/.venv/lib/python3.12/site-packages/pydantic/_internal/_config.py:295: PydanticDeprecatedSince20: Support for class-based `config` is deprecated, use ConfigDict instead. Deprecated in Pydantic V2.0 to be removed in V3.0. See Pydantic V2 Migration Guide at https://errors.pydantic.dev/2.10/migration/
    warnings.warn(DEPRECATION_MESSAGE, DeprecationWarning)

tests/truth/test_part0_authorized_repairs.py::test_legacy_test_creation_is_scoped_and_cannot_issue_fake_session
tests/truth/test_part0_authorized_repairs.py::test_legacy_test_creation_is_scoped_and_cannot_issue_fake_session
tests/truth/test_part0_authorized_repairs.py::test_dnc_and_audit_commit_together
tests/truth/test_part0_authorized_repairs.py::test_failed_audit_cannot_commit_dnc
tests/truth/test_part0_authorized_repairs.py::test_qms_http_unavailable_is_not_empty_success_and_is_tenant_scoped
tests/truth/test_part0_authorized_repairs.py::test_qms_http_unavailable_is_not_empty_success_and_is_tenant_scoped
tests/truth/test_part0_authorized_repairs.py::test_replay_does_not_manufacture_a_signed_recording_link
  /home/user/voxdesk-call-ainul-islam/voxdesk-call/app/db/models.py:2938: DeprecationWarning: datetime.datetime.utcnow() is deprecated and scheduled for removal in a future version. Use timezone-aware objects to represent datetimes in UTC: datetime.datetime.now(datetime.UTC).
    now = datetime.utcnow()

tests/truth/test_part0_authorized_repairs.py: 31 warnings
  /home/user/voxdesk-call-ainul-islam/voxdesk-call/.venv/lib/python3.12/site-packages/sqlalchemy/sql/schema.py:3596: DeprecationWarning: datetime.datetime.utcnow() is deprecated and scheduled for removal in a future version. Use timezone-aware objects to represent datetimes in UTC: datetime.datetime.now(datetime.UTC).
    return util.wrap_callable(lambda ctx: fn(), fn)  # type: ignore

tests/truth/test_part0_authorized_repairs.py::test_legacy_test_creation_is_scoped_and_cannot_issue_fake_session
tests/truth/test_part0_authorized_repairs.py::test_legacy_test_creation_is_scoped_and_cannot_issue_fake_session
tests/truth/test_part0_authorized_repairs.py::test_dnc_and_audit_commit_together
tests/truth/test_part0_authorized_repairs.py::test_failed_audit_cannot_commit_dnc
tests/truth/test_part0_authorized_repairs.py::test_qms_http_unavailable_is_not_empty_success_and_is_tenant_scoped
tests/truth/test_part0_authorized_repairs.py::test_qms_http_unavailable_is_not_empty_success_and_is_tenant_scoped
tests/truth/test_part0_authorized_repairs.py::test_replay_does_not_manufacture_a_signed_recording_link
  /home/user/voxdesk-call-ainul-islam/voxdesk-call/app/db/models.py:2968: DeprecationWarning: datetime.datetime.utcnow() is deprecated and scheduled for removal in a future version. Use timezone-aware objects to represent datetimes in UTC: datetime.datetime.now(datetime.UTC).
    now = datetime.utcnow()

tests/truth/test_part0_authorized_repairs.py::test_legacy_test_creation_is_scoped_and_cannot_issue_fake_session
tests/truth/test_part0_authorized_repairs.py::test_legacy_test_creation_is_scoped_and_cannot_issue_fake_session
tests/truth/test_part0_authorized_repairs.py::test_dnc_and_audit_commit_together
tests/truth/test_part0_authorized_repairs.py::test_failed_audit_cannot_commit_dnc
tests/truth/test_part0_authorized_repairs.py::test_qms_http_unavailable_is_not_empty_success_and_is_tenant_scoped
tests/truth/test_part0_authorized_repairs.py::test_qms_http_unavailable_is_not_empty_success_and_is_tenant_scoped
tests/truth/test_part0_authorized_repairs.py::test_replay_does_not_manufacture_a_signed_recording_link
  /home/user/voxdesk-call-ainul-islam/voxdesk-call/app/db/models.py:3023: DeprecationWarning: datetime.datetime.utcnow() is deprecated and scheduled for removal in a future version. Use timezone-aware objects to represent datetimes in UTC: datetime.datetime.now(datetime.UTC).
    now = datetime.utcnow()

tests/truth/test_part0_authorized_repairs.py::test_replay_does_not_manufacture_a_signed_recording_link
  /home/user/voxdesk-call-ainul-islam/voxdesk-call/tests/conftest.py:569: DeprecationWarning: datetime.datetime.utcnow() is deprecated and scheduled for removal in a future version. Use timezone-aware objects to represent datetimes in UTC: datetime.datetime.now(datetime.UTC).
    "started_at": datetime.utcnow(),

-- Docs: https://docs.pytest.org/en/stable/how-to/capture-warnings.html
41 passed, 59 warnings in 21.55s

````````

## ruff-producers.log

````````text
All checks passed!

````````
