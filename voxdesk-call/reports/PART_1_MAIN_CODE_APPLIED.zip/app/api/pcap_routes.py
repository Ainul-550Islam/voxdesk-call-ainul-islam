# File: app/api/pcap_routes.py — PCAP/debug artifact secure capture metadata + authorization + time-limited download
"""
PCAP/debug artifact API.
Closes gap 14: secure capture metadata + authorization + time-limited download.
"""
from __future__ import annotations

import uuid
from datetime import datetime, timedelta, timezone
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, ConfigDict, Field
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.audit.service import record_enterprise_audit
from app.auth.dependencies import TenantContext, require_permission
from app.auth.permissions import Permission
from app.db.enterprise_models import PcapArtifact
from app.db.models import AuditAction, Call
from app.db.session import get_session
from app.telephony.media_storage import issue, safe_reference, verify

router = APIRouter(prefix="/api/pcap", tags=["pcap"])


class _Strict(BaseModel):
    model_config = ConfigDict(extra="forbid")


class PcapCreateRequest(_Strict):
    call_id: uuid.UUID
    provider: str = Field(default="twilio", max_length=32)
    capture_type: str = Field(default="sip", pattern="^(sip|rtp|webrtc|all)$")
    retention_days: int = Field(default=7, ge=1, le=30)


class PcapOut(_Strict):
    id: str
    tenant_id: str
    call_id: str
    provider: str
    capture_type: str
    size_bytes: int
    has_storage: bool
    retention_deadline: Optional[str] = None
    created_at: Optional[str] = None
    expires_at: Optional[str] = None


class PcapDownloadOut(_Strict):
    id: str
    call_id: str
    download_token: str
    expires_at: str
    url: Optional[str] = None


def _now() -> datetime:
    return datetime.now(timezone.utc)


@router.post("", response_model=PcapOut, status_code=201)
async def create_pcap_request(
    payload: PcapCreateRequest,
    ctx: TenantContext = Depends(require_permission(Permission.GOVERNANCE_WRITE)),
    session: AsyncSession = Depends(get_session),
):
    """POST /api/pcap — Request PCAP capture for a call (secure metadata)."""
    call = await session.get(Call, payload.call_id)
    if call is None or call.tenant_id != ctx.tenant_id:
        raise HTTPException(status_code=404, detail="call not found")

    existing = (
        await session.execute(
            select(PcapArtifact).where(
                PcapArtifact.tenant_id == ctx.tenant_id,
                PcapArtifact.call_id == payload.call_id,
                PcapArtifact.capture_type == payload.capture_type,
            )
        )
    ).scalar_one_or_none()
    if existing:
        d = existing.as_dict()
        return PcapOut(
            id=d["id"],
            tenant_id=d["tenant_id"],
            call_id=d["call_id"],
            provider=d["provider"],
            capture_type=d["capture_type"],
            size_bytes=d["size_bytes"],
            has_storage=d["has_storage"],
            retention_deadline=d["retention_deadline"],
            created_at=d["created_at"],
            expires_at=d["expires_at"],
        )

    artifact = PcapArtifact(
        tenant_id=ctx.tenant_id,
        call_id=payload.call_id,
        provider=payload.provider,
        capture_type=payload.capture_type,
        size_bytes=0,
        storage_key="",
        retention_deadline=_now() + timedelta(days=payload.retention_days),
        created_by=ctx.user_id,
        expires_at=_now() + timedelta(days=payload.retention_days),
    )
    session.add(artifact)
    await session.flush()
    await record_enterprise_audit(
        session,
        ctx.tenant_id,
        ctx.user_id,
        "pcap.requested",
        {"artifact_id": str(artifact.id), "call_id": str(payload.call_id), "capture_type": payload.capture_type},
        resource_type="pcap_artifact",
        resource_id=artifact.id,
    )
    await session.commit()
    await session.refresh(artifact)
    d = artifact.as_dict()
    return PcapOut(
        id=d["id"],
        tenant_id=d["tenant_id"],
        call_id=d["call_id"],
        provider=d["provider"],
        capture_type=d["capture_type"],
        size_bytes=d["size_bytes"],
        has_storage=d["has_storage"],
        retention_deadline=d["retention_deadline"],
        created_at=d["created_at"],
        expires_at=d["expires_at"],
    )


@router.get("", response_model=dict)
async def list_pcaps(
    call_id: Optional[uuid.UUID] = Query(default=None),
    limit: int = Query(50, ge=1, le=200),
    offset: int = Query(0, ge=0),
    ctx: TenantContext = Depends(require_permission(Permission.GOVERNANCE_READ)),
    session: AsyncSession = Depends(get_session),
):
    scope = [PcapArtifact.tenant_id == ctx.tenant_id]
    if call_id:
        scope.append(PcapArtifact.call_id == call_id)
    total = (await session.execute(select(func.count(PcapArtifact.id)).where(*scope))).scalar() or 0
    rows = (
        await session.execute(
            select(PcapArtifact)
            .where(*scope)
            .order_by(PcapArtifact.created_at.desc())
            .offset(offset)
            .limit(limit)
        )
    ).scalars().all()
    return {
        "artifacts": [r.as_dict() for r in rows],
        "total": int(total),
        "limit": limit,
        "offset": offset,
    }


@router.get("/{artifact_id}", response_model=PcapOut)
async def get_pcap(
    artifact_id: uuid.UUID,
    ctx: TenantContext = Depends(require_permission(Permission.GOVERNANCE_READ)),
    session: AsyncSession = Depends(get_session),
):
    row = await session.get(PcapArtifact, artifact_id)
    if row is None or row.tenant_id != ctx.tenant_id:
        raise HTTPException(status_code=404, detail="pcap artifact not found")
    d = row.as_dict()
    return PcapOut(
        id=d["id"],
        tenant_id=d["tenant_id"],
        call_id=d["call_id"],
        provider=d["provider"],
        capture_type=d["capture_type"],
        size_bytes=d["size_bytes"],
        has_storage=d["has_storage"],
        retention_deadline=d["retention_deadline"],
        created_at=d["created_at"],
        expires_at=d["expires_at"],
    )


@router.post("/{artifact_id}/download-token", response_model=PcapDownloadOut)
async def create_download_token(
    artifact_id: uuid.UUID,
    ctx: TenantContext = Depends(require_permission(Permission.GOVERNANCE_EVIDENCE_EXPORT)),
    session: AsyncSession = Depends(get_session),
):
    """POST /api/pcap/{id}/download-token — Time-limited download token with authorization."""
    row = await session.get(PcapArtifact, artifact_id)
    if row is None or row.tenant_id != ctx.tenant_id:
        raise HTTPException(status_code=404, detail="pcap artifact not found")
    if not row.storage_key:
        raise HTTPException(status_code=404, detail="pcap storage not ready")

    now_utc = _now()
    if row.expires_at:
        exp = row.expires_at if row.expires_at.tzinfo else row.expires_at.replace(tzinfo=timezone.utc)
        if exp < now_utc:
            raise HTTPException(status_code=410, detail="artifact expired")

    grant = issue(row.tenant_id, row.id, now=int(now_utc.timestamp()), ttl_seconds=900)
    expires_at = datetime.fromtimestamp(grant.expires_at, tz=timezone.utc)

    await record_enterprise_audit(
        session,
        ctx.tenant_id,
        ctx.user_id,
        AuditAction.RESOURCE_EXPORTED,
        {
            "operation": "pcap_download_token",
            "artifact_id": str(row.id),
            "call_id": str(row.call_id),
        },
        resource_type="pcap_artifact",
        resource_id=row.id,
    )
    await session.commit()

    return PcapDownloadOut(
        id=str(row.id),
        call_id=str(row.call_id),
        download_token=grant.token,
        expires_at=expires_at.isoformat(),
        url=None,
    )


@router.get("/{artifact_id}/download/{token}")
async def download_pcap(
    artifact_id: uuid.UUID,
    token: str,
    ctx: TenantContext = Depends(require_permission(Permission.GOVERNANCE_EVIDENCE_EXPORT)),
    session: AsyncSession = Depends(get_session),
):
    """GET /api/pcap/{id}/download/{token} — Verify token and return storage reference."""
    row = await session.get(PcapArtifact, artifact_id)
    if row is None or row.tenant_id != ctx.tenant_id:
        raise HTTPException(status_code=404, detail="pcap artifact not found")

    verdict = verify(token, tenant_id=row.tenant_id, recording_id=row.id, now=int(_now().timestamp()))
    if not verdict.allowed:
        raise HTTPException(status_code=403, detail=verdict.reason)

    if not row.storage_key:
        raise HTTPException(status_code=404, detail="storage not available")

    ref = safe_reference(row.storage_key)
    return {
        "allowed": True,
        "storage_key": ref,
        "size_bytes": row.size_bytes,
        "checksum": row.checksum,
    }
