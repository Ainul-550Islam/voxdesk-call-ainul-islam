# File: app/api/live_monitoring_routes.py — Live monitoring/takeover listen/barge/whisper/takeover, operator session, human takeover session lifecycle
"""
Live monitoring and human takeover API.
- Live monitoring modes: listen, whisper, barge, takeover
- Operator session lifecycle: join, leave, ownership, audit
- Human takeover with ownership transfer, escalation, durable audit trail
- Distributed rate limiting, durable idempotency, RBAC, tenant isolation
"""
from __future__ import annotations

import uuid
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, Header, HTTPException, Query
from pydantic import BaseModel, ConfigDict, Field
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.audit.service import record_enterprise_audit
from app.auth.dependencies import TenantContext, require_permission
from app.auth.permissions import Permission
from app.core.logging import log
from app.core.rate_limit import enforce_tenant_rate_limit
from app.db.enterprise_models import LiveCallSession
from app.db.models import AuditAction, Call, CallStatus, RequestIdempotencyReceipt, UserRole
from app.db.session import get_session
from app.resilience.idempotency import get_idempotent_resource_id, store_idempotent_resource_id
from app.tenancy.isolation import HierarchyError, to_http

router = APIRouter(prefix="/api/calls", tags=["live-monitoring"])

MAX_WHISPER_LENGTH = 1000
MAX_REASON_LENGTH = 500
MAX_META_SIZE = 5000
MONITOR_MODES = {"listen", "whisper", "barge", "takeover"}
OWNERSHIP_TYPES = {"operator", "shared", "agent"}
SESSION_STATUSES = {"active", "ended", "paused"}
DEFAULT_SESSION_TTL_MINUTES = 60
MAX_CONCURRENT_SESSIONS_PER_CALL = 5
MAX_SESSIONS_PER_SUPERVISOR = 20


class _Strict(BaseModel):
    model_config = ConfigDict(extra="forbid", protected_namespaces=())


class MonitorRequest(_Strict):
    mode: str = Field(
        default="listen",
        pattern="^(listen|whisper|barge|takeover)$",
        description="listen=monitor only, whisper=coach agent, barge=join, takeover=operator owns",
    )
    whisper_text: Optional[str] = Field(default=None, max_length=MAX_WHISPER_LENGTH)
    reason: Optional[str] = Field(default=None, max_length=MAX_REASON_LENGTH)
    idempotency_key: Optional[str] = Field(default=None, min_length=8, max_length=128)
    metadata: Dict[str, Any] = Field(default_factory=dict)
    ttl_minutes: int = Field(default=DEFAULT_SESSION_TTL_MINUTES, ge=5, le=240)


class LiveSessionOut(_Strict):
    id: str
    call_id: str
    supervisor_id: str
    mode: str
    status: str
    created_at: str
    updated_at: Optional[str] = None
    ended_at: Optional[str] = None
    meta: Dict[str, Any]
    duration_seconds: Optional[int] = None


class LiveSessionListOut(_Strict):
    sessions: List[LiveSessionOut]
    total: int
    active: int
    limit: int
    offset: int


class TakeoverRequest(_Strict):
    reason: Optional[str] = Field(default=None, max_length=MAX_REASON_LENGTH)
    ownership: str = Field(default="operator", pattern="^(operator|shared|agent)$")
    idempotency_key: Optional[str] = Field(default=None, min_length=8, max_length=128)
    metadata: Dict[str, Any] = Field(default_factory=dict)
    notify_customer: bool = Field(default=False)


class TakeoverOut(_Strict):
    id: str
    call_id: str
    owner: str
    status: str
    joined_at: str
    left_at: Optional[str] = None
    audit: Dict[str, Any]
    duration_seconds: Optional[int] = None


class WhisperRequest(_Strict):
    text: str = Field(min_length=1, max_length=MAX_WHISPER_LENGTH)
    target: str = Field(default="agent", pattern="^(agent|customer|both)$")
    priority: int = Field(default=0, ge=0, le=10)


class MonitorAnalyticsOut(_Strict):
    call_id: str
    total_sessions: int
    active_sessions: int
    takeover_sessions: int
    average_duration_seconds: Optional[float] = None
    modes: Dict[str, int] = Field(default_factory=dict)


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _now_iso() -> str:
    return _now().isoformat()


def _session_duration(sess: LiveCallSession) -> Optional[int]:
    if sess.created_at and sess.ended_at:
        created = sess.created_at if sess.created_at.tzinfo else sess.created_at.replace(tzinfo=timezone.utc)
        ended = sess.ended_at if sess.ended_at.tzinfo else sess.ended_at.replace(tzinfo=timezone.utc)
        return max(0, int((ended - created).total_seconds()))
    if sess.created_at:
        created = sess.created_at if sess.created_at.tzinfo else sess.created_at.replace(tzinfo=timezone.utc)
        return max(0, int((_now() - created).total_seconds()))
    return None


def _to_session_out(row: LiveCallSession) -> LiveSessionOut:
    return LiveSessionOut(
        id=str(row.id),
        call_id=str(row.call_id),
        supervisor_id=str(row.supervisor_id),
        mode=row.mode,
        status=row.status,
        created_at=row.created_at.isoformat() if row.created_at else _now_iso(),
        updated_at=None,
        ended_at=row.ended_at.isoformat() if row.ended_at else None,
        meta=row.meta,
        duration_seconds=_session_duration(row),
    )


def _to_takeover_out(row: LiveCallSession) -> TakeoverOut:
    return TakeoverOut(
        id=str(row.id),
        call_id=str(row.call_id),
        owner=row.meta.get("ownership", "operator") if isinstance(row.meta, dict) else "operator",
        status=row.status,
        joined_at=row.created_at.isoformat() if row.created_at else _now_iso(),
        left_at=row.ended_at.isoformat() if row.ended_at else None,
        audit=row.meta if isinstance(row.meta, dict) else {},
        duration_seconds=_session_duration(row),
    )


async def _get_call(session: AsyncSession, tenant_id: uuid.UUID, call_id: uuid.UUID) -> Call:
    row = await session.get(Call, call_id)
    if row is None or row.tenant_id != tenant_id:
        raise HTTPException(status_code=404, detail="call not found")
    return row


async def _get_session_row(
    session: AsyncSession, tenant_id: uuid.UUID, call_id: uuid.UUID, session_id: uuid.UUID
) -> LiveCallSession:
    row = await session.get(LiveCallSession, session_id)
    if row is None or row.tenant_id != tenant_id or row.call_id != call_id:
        raise HTTPException(status_code=404, detail="monitoring session not found")
    return row


@router.post("/{call_id}/monitor", response_model=LiveSessionOut, status_code=201)
async def start_monitoring(
    call_id: uuid.UUID,
    payload: MonitorRequest,
    ctx: TenantContext = Depends(require_permission(Permission.SUPERVISOR_WRITE)),
    session: AsyncSession = Depends(get_session),
    x_idempotency_key: Optional[str] = Header(default=None, alias="Idempotency-Key"),
):
    """POST /api/calls/{id}/monitor — Start live monitoring session."""
    try:
        await enforce_tenant_rate_limit(ctx.tenant_id, "monitor_start", 20)
        call = await _get_call(session, ctx.tenant_id, call_id)
        if call.status in (CallStatus.COMPLETED, CallStatus.FAILED):
            raise HTTPException(status_code=409, detail="call not active for monitoring")

        idem_key = payload.idempotency_key or x_idempotency_key
        if idem_key:
            cached_id = await get_idempotent_resource_id(
                session,
                tenant_id=ctx.tenant_id,
                operation="live_monitor.start",
                key=idem_key,
            )
            if cached_id:
                existing_idem = await session.get(LiveCallSession, uuid.UUID(cached_id))
                if (
                    existing_idem is not None
                    and existing_idem.tenant_id == ctx.tenant_id
                    and existing_idem.call_id == call_id
                ):
                    return _to_session_out(existing_idem)

        active_count_q = await session.execute(
            select(func.count(LiveCallSession.id)).where(
                LiveCallSession.tenant_id == ctx.tenant_id,
                LiveCallSession.call_id == call_id,
                LiveCallSession.status == "active",
            )
        )
        active_count = active_count_q.scalar() or 0
        if active_count >= MAX_CONCURRENT_SESSIONS_PER_CALL:
            raise HTTPException(
                status_code=409,
                detail=f"max {MAX_CONCURRENT_SESSIONS_PER_CALL} concurrent monitoring sessions per call",
            )

        sup_count_q = await session.execute(
            select(func.count(LiveCallSession.id)).where(
                LiveCallSession.tenant_id == ctx.tenant_id,
                LiveCallSession.supervisor_id == ctx.user_id,
                LiveCallSession.status == "active",
            )
        )
        sup_count = sup_count_q.scalar() or 0
        if sup_count >= MAX_SESSIONS_PER_SUPERVISOR:
            raise HTTPException(
                status_code=409,
                detail=f"max {MAX_SESSIONS_PER_SUPERVISOR} active sessions per supervisor",
            )

        existing = (
            await session.execute(
                select(LiveCallSession).where(
                    LiveCallSession.tenant_id == ctx.tenant_id,
                    LiveCallSession.call_id == call_id,
                    LiveCallSession.supervisor_id == ctx.user_id,
                    LiveCallSession.status == "active",
                    LiveCallSession.mode == payload.mode,
                )
            )
        ).scalars().first()
        if existing:
            return _to_session_out(existing)

        sess = LiveCallSession(
            tenant_id=ctx.tenant_id,
            call_id=call_id,
            supervisor_id=ctx.user_id,
            mode=payload.mode,
            status="active",
            meta={
                "reason": payload.reason,
                "whisper_text": payload.whisper_text,
                "started_by": str(ctx.user_id),
                "ttl_minutes": payload.ttl_minutes,
                "metadata": payload.metadata,
                "media_connected": False,
                "media_status": "NOT_CONFIGURED",
                "control_plane_only": True,
                "audit": [
                    {
                        "event": "session_started",
                        "by": str(ctx.user_id),
                        "at": _now_iso(),
                        "mode": payload.mode,
                    }
                ],
            },
        )
        session.add(sess)
        await session.flush()

        await record_enterprise_audit(
            session,
            ctx.tenant_id,
            ctx.user_id,
            AuditAction.RESOURCE_EXPORTED,
            {
                "operation": f"live_monitor_{payload.mode}",
                "call_id": str(call_id),
                "session_id": str(sess.id),
            },
            resource_type="live_call_session",
            resource_id=sess.id,
        )

        if idem_key:
            await store_idempotent_resource_id(
                session,
                tenant_id=ctx.tenant_id,
                operation="live_monitor.start",
                key=idem_key,
                resource_type="live_call_session",
                resource_id=sess.id,
                request_data={"call_id": str(call_id), "mode": payload.mode},
            )

        await session.commit()
        await session.refresh(sess)

        log.info(
            "live_monitor.started",
            tenant_id=str(ctx.tenant_id),
            call_id=str(call_id),
            session_id=str(sess.id),
            mode=payload.mode,
            supervisor_id=str(ctx.user_id),
        )
        return _to_session_out(sess)
    except HierarchyError as exc:
        raise to_http(exc) from None


@router.get("/{call_id}/monitor", response_model=LiveSessionListOut)
async def list_monitoring_sessions(
    call_id: uuid.UUID,
    status: Optional[str] = Query(default=None),
    mode: Optional[str] = Query(default=None),
    limit: int = Query(50, ge=1, le=200),
    offset: int = Query(0, ge=0),
    ctx: TenantContext = Depends(require_permission(Permission.SUPERVISOR_READ)),
    session: AsyncSession = Depends(get_session),
):
    """List active and recent monitoring sessions for a call."""
    await _get_call(session, ctx.tenant_id, call_id)
    filters = [LiveCallSession.tenant_id == ctx.tenant_id, LiveCallSession.call_id == call_id]
    if status:
        filters.append(LiveCallSession.status == status)
    if mode:
        filters.append(LiveCallSession.mode == mode)

    total_q = await session.execute(select(func.count(LiveCallSession.id)).where(*filters))
    total = total_q.scalar() or 0

    active_q = await session.execute(
        select(func.count(LiveCallSession.id)).where(*filters, LiveCallSession.status == "active")
    )
    active = active_q.scalar() or 0

    rows = (
        await session.execute(
            select(LiveCallSession)
            .where(*filters)
            .order_by(LiveCallSession.created_at.desc())
            .offset(offset)
            .limit(limit)
        )
    ).scalars().all()

    return LiveSessionListOut(
        sessions=[_to_session_out(r) for r in rows],
        total=int(total),
        active=int(active),
        limit=limit,
        offset=offset,
    )


@router.get("/{call_id}/monitor/{session_id}", response_model=LiveSessionOut)
async def get_monitoring_session(
    call_id: uuid.UUID,
    session_id: uuid.UUID,
    ctx: TenantContext = Depends(require_permission(Permission.SUPERVISOR_READ)),
    session: AsyncSession = Depends(get_session),
):
    row = await _get_session_row(session, ctx.tenant_id, call_id, session_id)
    return _to_session_out(row)


@router.post("/{call_id}/monitor/{session_id}/end", response_model=LiveSessionOut)
async def end_monitoring(
    call_id: uuid.UUID,
    session_id: uuid.UUID,
    ctx: TenantContext = Depends(require_permission(Permission.SUPERVISOR_WRITE)),
    session: AsyncSession = Depends(get_session),
):
    """End monitoring session."""
    await _get_call(session, ctx.tenant_id, call_id)
    row = await _get_session_row(session, ctx.tenant_id, call_id, session_id)
    if row.status != "active":
        raise HTTPException(status_code=409, detail="session not active")
    if row.supervisor_id != ctx.user_id and ctx.role not in {UserRole.OWNER, UserRole.ADMIN}:
        raise HTTPException(status_code=403, detail="only session owner or admin can end")

    row.status = "ended"
    row.ended_at = _now()
    meta = dict(row.meta or {})
    audit = meta.get("audit", [])
    if isinstance(audit, list):
        audit.append({"event": "session_ended", "by": str(ctx.user_id), "at": _now_iso()})
        meta["audit"] = audit
    row.meta = meta

    await record_enterprise_audit(
        session,
        ctx.tenant_id,
        ctx.user_id,
        "live_monitor.ended",
        {"call_id": str(call_id), "session_id": str(session_id)},
        resource_type="live_call_session",
        resource_id=session_id,
    )
    await session.commit()
    await session.refresh(row)
    return _to_session_out(row)


@router.post("/{call_id}/monitor/{session_id}/pause", response_model=LiveSessionOut)
async def pause_monitoring(
    call_id: uuid.UUID,
    session_id: uuid.UUID,
    ctx: TenantContext = Depends(require_permission(Permission.SUPERVISOR_WRITE)),
    session: AsyncSession = Depends(get_session),
):
    """Pause monitoring session."""
    row = await _get_session_row(session, ctx.tenant_id, call_id, session_id)
    if row.status != "active":
        raise HTTPException(status_code=409, detail="session not active")
    row.status = "paused"
    meta = dict(row.meta or {})
    audit = meta.get("audit", [])
    if isinstance(audit, list):
        audit.append({"event": "session_paused", "by": str(ctx.user_id), "at": _now_iso()})
        meta["audit"] = audit
    row.meta = meta
    await record_enterprise_audit(
        session,
        ctx.tenant_id,
        ctx.user_id,
        "live_monitor.paused",
        {"call_id": str(call_id), "session_id": str(session_id)},
        resource_type="live_call_session",
        resource_id=session_id,
    )
    await session.commit()
    await session.refresh(row)
    return _to_session_out(row)


@router.post("/{call_id}/monitor/{session_id}/resume", response_model=LiveSessionOut)
async def resume_monitoring(
    call_id: uuid.UUID,
    session_id: uuid.UUID,
    ctx: TenantContext = Depends(require_permission(Permission.SUPERVISOR_WRITE)),
    session: AsyncSession = Depends(get_session),
):
    """Resume paused monitoring session."""
    row = await _get_session_row(session, ctx.tenant_id, call_id, session_id)
    if row.status != "paused":
        raise HTTPException(status_code=409, detail="session not paused")
    row.status = "active"
    meta = dict(row.meta or {})
    audit = meta.get("audit", [])
    if isinstance(audit, list):
        audit.append({"event": "session_resumed", "by": str(ctx.user_id), "at": _now_iso()})
        meta["audit"] = audit
    row.meta = meta
    await record_enterprise_audit(
        session,
        ctx.tenant_id,
        ctx.user_id,
        "live_monitor.resumed",
        {"call_id": str(call_id), "session_id": str(session_id)},
        resource_type="live_call_session",
        resource_id=session_id,
    )
    await session.commit()
    await session.refresh(row)
    return _to_session_out(row)


@router.post("/{call_id}/monitor/{session_id}/whisper")
async def whisper_to_agent(
    call_id: uuid.UUID,
    session_id: uuid.UUID,
    payload: WhisperRequest,
    ctx: TenantContext = Depends(require_permission(Permission.SUPERVISOR_WRITE)),
    session: AsyncSession = Depends(get_session),
):
    """Whisper coaching to agent during live call."""
    await _get_call(session, ctx.tenant_id, call_id)
    row = await _get_session_row(session, ctx.tenant_id, call_id, session_id)
    if row.status != "active":
        raise HTTPException(status_code=409, detail="session not active")
    if row.mode not in ("whisper", "barge", "takeover"):
        raise HTTPException(status_code=422, detail="session mode does not support whisper")

    meta = dict(row.meta or {})
    whispers = meta.get("whispers", [])
    if not isinstance(whispers, list):
        whispers = []
    whispers.append(
        {
            "text": payload.text,
            "target": payload.target,
            "priority": payload.priority,
            "by": str(ctx.user_id),
            "at": _now_iso(),
        }
    )
    meta["whispers"] = whispers[-20:]
    meta["last_whisper"] = payload.text
    meta["whisper_at"] = _now_iso()
    audit = meta.get("audit", [])
    if isinstance(audit, list):
        audit.append(
            {
                "event": "whisper_sent",
                "by": str(ctx.user_id),
                "at": _now_iso(),
                "text": payload.text[:100],
            }
        )
        meta["audit"] = audit
    row.meta = meta
    await record_enterprise_audit(
        session,
        ctx.tenant_id,
        ctx.user_id,
        "live_monitor.whisper",
        {"call_id": str(call_id), "session_id": str(session_id), "target": payload.target},
        resource_type="live_call_session",
        resource_id=session_id,
    )
    await session.commit()

    return {
        "id": str(row.id),
        "call_id": str(call_id),
        "whisper": payload.text,
        "target": payload.target,
        "status": "recorded_not_delivered",
        "delivery_status": "NOT_CONFIGURED",
        "media_connected": False,
        "at": _now_iso(),
    }


@router.get("/{call_id}/monitor/{session_id}/whispers", response_model=dict)
async def list_whispers(
    call_id: uuid.UUID,
    session_id: uuid.UUID,
    ctx: TenantContext = Depends(require_permission(Permission.SUPERVISOR_READ)),
    session: AsyncSession = Depends(get_session),
):
    row = await _get_session_row(session, ctx.tenant_id, call_id, session_id)
    meta = row.meta if isinstance(row.meta, dict) else {}
    whispers = meta.get("whispers", [])
    return {"session_id": str(session_id), "whispers": whispers, "total": len(whispers)}


@router.post("/{call_id}/takeover", response_model=TakeoverOut, status_code=201)
async def human_takeover(
    call_id: uuid.UUID,
    payload: TakeoverRequest,
    ctx: TenantContext = Depends(require_permission(Permission.SUPERVISOR_WRITE)),
    session: AsyncSession = Depends(get_session),
    x_idempotency_key: Optional[str] = Header(default=None, alias="Idempotency-Key"),
):
    """POST /api/calls/{id}/takeover — Human takeover session."""
    await enforce_tenant_rate_limit(ctx.tenant_id, "takeover", 10)
    call = await _get_call(session, ctx.tenant_id, call_id)
    if call.status in (CallStatus.COMPLETED, CallStatus.FAILED):
        raise HTTPException(status_code=409, detail="call not active for takeover")

    idem_key = payload.idempotency_key or x_idempotency_key
    if idem_key:
        cached_id = await get_idempotent_resource_id(
            session,
            tenant_id=ctx.tenant_id,
            operation="live_monitor.takeover",
            key=idem_key,
        )
        if cached_id:
            existing_idem = await session.get(LiveCallSession, uuid.UUID(cached_id))
            if (
                existing_idem is not None
                and existing_idem.tenant_id == ctx.tenant_id
                and existing_idem.call_id == call_id
            ):
                return _to_takeover_out(existing_idem)

    existing_takeover = (
        await session.execute(
            select(LiveCallSession)
            .where(
                LiveCallSession.tenant_id == ctx.tenant_id,
                LiveCallSession.call_id == call_id,
                LiveCallSession.mode == "takeover",
                LiveCallSession.status == "active",
            )
            .limit(1)
        )
    ).scalar_one_or_none()
    if existing_takeover:
        raise HTTPException(status_code=409, detail="call already has active takeover session")

    sess = LiveCallSession(
        tenant_id=ctx.tenant_id,
        call_id=call_id,
        supervisor_id=ctx.user_id,
        mode="takeover",
        status="active",
        meta={
            "ownership": payload.ownership,
            "reason": payload.reason,
            "joined_by": str(ctx.user_id),
            "notify_customer": payload.notify_customer,
            "metadata": payload.metadata,
            "media_connected": False,
            "media_status": "NOT_CONFIGURED",
            "control_plane_only": True,
            "customer_notified": False,
            "audit": [
                {
                    "event": "takeover_joined",
                    "by": str(ctx.user_id),
                    "at": _now_iso(),
                    "ownership": payload.ownership,
                    "reason": payload.reason,
                }
            ],
        },
    )
    session.add(sess)
    await session.flush()

    if hasattr(call, "escalated"):
        call.escalated = True

    await record_enterprise_audit(
        session,
        ctx.tenant_id,
        ctx.user_id,
        AuditAction.RESOURCE_EXPORTED,
        {
            "operation": "human_takeover",
            "call_id": str(call_id),
            "ownership": payload.ownership,
        },
        resource_type="live_call_session",
        resource_id=sess.id,
    )

    if idem_key:
        await store_idempotent_resource_id(
            session,
            tenant_id=ctx.tenant_id,
            operation="live_monitor.takeover",
            key=idem_key,
            resource_type="live_call_session",
            resource_id=sess.id,
            request_data={"call_id": str(call_id), "ownership": payload.ownership},
        )

    await session.commit()
    await session.refresh(sess)

    log.info(
        "takeover.joined",
        tenant_id=str(ctx.tenant_id),
        call_id=str(call_id),
        session_id=str(sess.id),
        ownership=payload.ownership,
        supervisor_id=str(ctx.user_id),
    )
    return _to_takeover_out(sess)


@router.get("/{call_id}/takeover", response_model=List[TakeoverOut])
async def list_takeovers(
    call_id: uuid.UUID,
    ctx: TenantContext = Depends(require_permission(Permission.SUPERVISOR_READ)),
    session: AsyncSession = Depends(get_session),
):
    await _get_call(session, ctx.tenant_id, call_id)
    rows = (
        await session.execute(
            select(LiveCallSession)
            .where(
                LiveCallSession.tenant_id == ctx.tenant_id,
                LiveCallSession.call_id == call_id,
                LiveCallSession.mode == "takeover",
            )
            .order_by(LiveCallSession.created_at.desc())
        )
    ).scalars().all()
    return [_to_takeover_out(r) for r in rows]


@router.post("/{call_id}/takeover/{session_id}/leave", response_model=TakeoverOut)
async def leave_takeover(
    call_id: uuid.UUID,
    session_id: uuid.UUID,
    ctx: TenantContext = Depends(require_permission(Permission.SUPERVISOR_WRITE)),
    session: AsyncSession = Depends(get_session),
):
    """Operator leave takeover session — ownership returns to agent or shared."""
    await _get_call(session, ctx.tenant_id, call_id)
    row = await _get_session_row(session, ctx.tenant_id, call_id, session_id)
    if row.mode != "takeover":
        raise HTTPException(status_code=422, detail="not a takeover session")
    if row.status != "active":
        raise HTTPException(status_code=409, detail="session not active")

    row.status = "ended"
    row.ended_at = _now()
    meta = dict(row.meta or {})
    meta["left_by"] = str(ctx.user_id)
    meta["left_at"] = row.ended_at.isoformat()
    audit = meta.get("audit", [])
    if isinstance(audit, list):
        audit.append({"event": "takeover_left", "by": str(ctx.user_id), "at": _now_iso()})
        meta["audit"] = audit
    row.meta = meta

    await record_enterprise_audit(
        session,
        ctx.tenant_id,
        ctx.user_id,
        "takeover.left",
        {"call_id": str(call_id), "session_id": str(session_id)},
        resource_type="live_call_session",
        resource_id=session_id,
    )
    await session.commit()
    await session.refresh(row)
    return _to_takeover_out(row)


@router.post("/{call_id}/takeover/{session_id}/transfer-ownership", response_model=TakeoverOut)
async def transfer_ownership(
    call_id: uuid.UUID,
    session_id: uuid.UUID,
    new_owner: str = Query(..., pattern="^(operator|shared|agent)$"),
    new_supervisor_id: Optional[uuid.UUID] = Query(default=None),
    ctx: TenantContext = Depends(require_permission(Permission.SUPERVISOR_WRITE)),
    session: AsyncSession = Depends(get_session),
):
    """POST /api/calls/{id}/takeover/{sid}/transfer-ownership — Transfer ownership."""
    row = await _get_session_row(session, ctx.tenant_id, call_id, session_id)
    if row.mode != "takeover":
        raise HTTPException(status_code=422, detail="not a takeover session")
    if row.status != "active":
        raise HTTPException(status_code=409, detail="session not active")

    meta = dict(row.meta or {})
    old_owner = meta.get("ownership", "operator")
    meta["ownership"] = new_owner
    if new_supervisor_id:
        row.supervisor_id = new_supervisor_id
        meta["transferred_to"] = str(new_supervisor_id)
    audit = meta.get("audit", [])
    if isinstance(audit, list):
        audit.append(
            {
                "event": "ownership_transferred",
                "from": old_owner,
                "to": new_owner,
                "by": str(ctx.user_id),
                "at": _now_iso(),
            }
        )
        meta["audit"] = audit
    row.meta = meta

    await record_enterprise_audit(
        session,
        ctx.tenant_id,
        ctx.user_id,
        "takeover.ownership_transferred",
        {
            "call_id": str(call_id),
            "session_id": str(session_id),
            "from_owner": old_owner,
            "to_owner": new_owner,
        },
        resource_type="live_call_session",
        resource_id=session_id,
    )
    await session.commit()
    await session.refresh(row)
    return _to_takeover_out(row)


@router.get("/{call_id}/takeover/{session_id}/audit", response_model=dict)
async def takeover_audit(
    call_id: uuid.UUID,
    session_id: uuid.UUID,
    ctx: TenantContext = Depends(require_permission(Permission.SUPERVISOR_READ)),
    session: AsyncSession = Depends(get_session),
):
    row = await _get_session_row(session, ctx.tenant_id, call_id, session_id)
    meta = row.meta if isinstance(row.meta, dict) else {}
    audit = meta.get("audit", [])
    return {
        "session_id": str(session_id),
        "call_id": str(call_id),
        "audit": audit,
        "total_events": len(audit) if isinstance(audit, list) else 0,
    }


@router.get("/{call_id}/monitor/analytics", response_model=MonitorAnalyticsOut)
async def monitor_analytics(
    call_id: uuid.UUID,
    ctx: TenantContext = Depends(require_permission(Permission.SUPERVISOR_READ)),
    session: AsyncSession = Depends(get_session),
):
    await _get_call(session, ctx.tenant_id, call_id)
    total_q = await session.execute(
        select(func.count(LiveCallSession.id)).where(
            LiveCallSession.tenant_id == ctx.tenant_id, LiveCallSession.call_id == call_id
        )
    )
    total = total_q.scalar() or 0

    active_q = await session.execute(
        select(func.count(LiveCallSession.id)).where(
            LiveCallSession.tenant_id == ctx.tenant_id,
            LiveCallSession.call_id == call_id,
            LiveCallSession.status == "active",
        )
    )
    active = active_q.scalar() or 0

    takeover_q = await session.execute(
        select(func.count(LiveCallSession.id)).where(
            LiveCallSession.tenant_id == ctx.tenant_id,
            LiveCallSession.call_id == call_id,
            LiveCallSession.mode == "takeover",
        )
    )
    takeover = takeover_q.scalar() or 0

    modes_q = await session.execute(
        select(LiveCallSession.mode, func.count(LiveCallSession.id))
        .where(LiveCallSession.tenant_id == ctx.tenant_id, LiveCallSession.call_id == call_id)
        .group_by(LiveCallSession.mode)
    )
    modes = {mode: int(cnt) for mode, cnt in modes_q.all()}

    avg_duration = None
    rows = (
        await session.execute(
            select(LiveCallSession).where(
                LiveCallSession.tenant_id == ctx.tenant_id,
                LiveCallSession.call_id == call_id,
                LiveCallSession.ended_at.isnot(None),
            )
        )
    ).scalars().all()
    durations = [d for d in (_session_duration(r) for r in rows) if d is not None]
    if durations:
        avg_duration = sum(durations) / len(durations)

    return MonitorAnalyticsOut(
        call_id=str(call_id),
        total_sessions=int(total),
        active_sessions=int(active),
        takeover_sessions=int(takeover),
        average_duration_seconds=avg_duration,
        modes=modes,
    )


@router.get("/monitor/health", response_model=dict)
async def monitor_health(
    ctx: TenantContext = Depends(require_permission(Permission.SUPERVISOR_READ)),
    session: AsyncSession = Depends(get_session),
):
    total_q = await session.execute(
        select(func.count(LiveCallSession.id)).where(LiveCallSession.tenant_id == ctx.tenant_id)
    )
    total = total_q.scalar() or 0
    active_q = await session.execute(
        select(func.count(LiveCallSession.id)).where(
            LiveCallSession.tenant_id == ctx.tenant_id, LiveCallSession.status == "active"
        )
    )
    active = active_q.scalar() or 0
    idem_q = await session.execute(
        select(func.count(RequestIdempotencyReceipt.id)).where(
            RequestIdempotencyReceipt.tenant_id == ctx.tenant_id,
            RequestIdempotencyReceipt.operation.like("live_monitor.%"),
        )
    )
    idem_total = idem_q.scalar() or 0
    return {
        "tenant_id": str(ctx.tenant_id),
        "total_sessions": int(total),
        "active_sessions": int(active),
        "status": "healthy",
        "idempotency_entries": int(idem_total),
        "idempotency_scope": "durable_database",
        "idempotency_authoritative": True,
        "at": _now_iso(),
    }


@router.get("/monitor/config", response_model=dict)
async def monitor_config(
    ctx: TenantContext = Depends(require_permission(Permission.TENANT_READ)),
):
    return {
        "modes": sorted(MONITOR_MODES),
        "ownership_types": sorted(OWNERSHIP_TYPES),
        "max_concurrent_per_call": MAX_CONCURRENT_SESSIONS_PER_CALL,
        "max_per_supervisor": MAX_SESSIONS_PER_SUPERVISOR,
        "default_ttl_minutes": DEFAULT_SESSION_TTL_MINUTES,
        "max_whisper_length": MAX_WHISPER_LENGTH,
        "at": _now_iso(),
    }


@router.get("/monitoring/idempotency/stats")
async def idempotency_stats(
    ctx: TenantContext = Depends(require_permission(Permission.TENANT_READ)),
    session: AsyncSession = Depends(get_session),
):
    rows = (
        await session.execute(
            select(RequestIdempotencyReceipt.status, func.count(RequestIdempotencyReceipt.id))
            .where(
                RequestIdempotencyReceipt.tenant_id == ctx.tenant_id,
                RequestIdempotencyReceipt.operation.like("live_monitor.%"),
            )
            .group_by(RequestIdempotencyReceipt.status)
        )
    ).all()
    counts = {str(status): int(count) for status, count in rows}
    total = sum(counts.values())
    return {
        "scope": "durable_database",
        "authoritative": True,
        "total": total,
        "active": counts.get("succeeded", 0) + counts.get("in_progress", 0),
        "at": _now_iso(),
    }
