# File: app/api/multichannel_routes.py — Multichannel normalization voice+SMS+chat/WhatsApp unified conversation/action contract, message provider lifecycle
"""
Multichannel API normalization + message provider lifecycle.
"""
from __future__ import annotations

import uuid
from datetime import datetime, timezone
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, ConfigDict, Field
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.audit.service import record_enterprise_audit
from app.auth.dependencies import TenantContext, require_permission
from app.auth.permissions import Permission
from app.db.enterprise_models import MessageChannel
from app.db.session import get_session

router = APIRouter(prefix="/api/channels", tags=["multichannel"])


class _Strict(BaseModel):
    model_config = ConfigDict(extra="forbid")


class ChannelCreate(_Strict):
    channel_type: str = Field(pattern="^(voice|sms|whatsapp|chat|email)$")
    provider: str = Field(min_length=1, max_length=32, description="twilio, telnyx, vonage, custom")
    config: dict = Field(
        default_factory=dict,
        description="Provider config: api_key_ref, webhook_url, etc. No secrets in plain",
    )
    is_active: bool = True


class ChannelUpdate(_Strict):
    config: Optional[dict] = None
    is_active: Optional[bool] = None


class ChannelOut(_Strict):
    id: str
    tenant_id: str
    channel_type: str
    provider: str
    is_active: bool
    config: dict
    health_status: str
    last_health_check_at: Optional[str] = None
    created_at: Optional[str] = None
    updated_at: Optional[str] = None


class UnifiedConversationRequest(_Strict):
    channel_type: str = Field(pattern="^(voice|sms|whatsapp|chat|email)$")
    to: str = Field(min_length=3, max_length=100)
    message: str = Field(min_length=1, max_length=4000)
    agent_id: Optional[str] = Field(default=None, max_length=80)
    custom_fields: dict = Field(default_factory=dict)


class UnifiedConversationOut(_Strict):
    id: str
    channel_type: str
    provider: str
    to: str
    status: str
    message_id: Optional[str] = None
    created_at: str


class HealthCheckOut(_Strict):
    channel_id: str
    health_status: str
    can_send: bool
    can_receive: bool
    last_check_at: str
    details: dict


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _to_out(row: MessageChannel) -> ChannelOut:
    d = row.as_dict()
    return ChannelOut(
        id=d["id"],
        tenant_id=d["tenant_id"],
        channel_type=d["channel_type"],
        provider=d["provider"],
        is_active=d["is_active"],
        config=d["config"],
        health_status=d["health_status"],
        last_health_check_at=d["last_health_check_at"],
        created_at=d["created_at"],
        updated_at=d["updated_at"],
    )


@router.post("", response_model=ChannelOut, status_code=201)
async def register_channel(
    payload: ChannelCreate,
    ctx: TenantContext = Depends(require_permission(Permission.INTEGRATION_WRITE)),
    session: AsyncSession = Depends(get_session),
):
    """POST /api/channels — Channel registration."""
    existing = (
        await session.execute(
            select(MessageChannel).where(
                MessageChannel.tenant_id == ctx.tenant_id,
                MessageChannel.channel_type == payload.channel_type,
                MessageChannel.provider == payload.provider,
            )
        )
    ).scalar_one_or_none()
    if existing:
        raise HTTPException(status_code=409, detail="channel already registered for this provider+type")

    ch = MessageChannel(
        tenant_id=ctx.tenant_id,
        channel_type=payload.channel_type,
        provider=payload.provider,
        is_active=payload.is_active,
        config=payload.config,
        health_status="unknown",
    )
    session.add(ch)
    await session.flush()
    await record_enterprise_audit(
        session,
        ctx.tenant_id,
        ctx.user_id,
        "channel.registered",
        {"channel_id": str(ch.id), "channel_type": payload.channel_type, "provider": payload.provider},
        resource_type="message_channel",
        resource_id=ch.id,
    )
    await session.commit()
    await session.refresh(ch)
    return _to_out(ch)


@router.get("", response_model=dict)
async def list_channels(
    channel_type: Optional[str] = Query(default=None),
    is_active: Optional[bool] = Query(default=None),
    limit: int = Query(50, ge=1, le=200),
    offset: int = Query(0, ge=0),
    ctx: TenantContext = Depends(require_permission(Permission.INTEGRATION_READ)),
    session: AsyncSession = Depends(get_session),
):
    scope = [MessageChannel.tenant_id == ctx.tenant_id]
    if channel_type:
        scope.append(MessageChannel.channel_type == channel_type)
    if is_active is not None:
        scope.append(MessageChannel.is_active == is_active)
    total = (await session.execute(select(func.count(MessageChannel.id)).where(*scope))).scalar() or 0
    rows = (
        await session.execute(
            select(MessageChannel)
            .where(*scope)
            .order_by(MessageChannel.created_at.desc())
            .offset(offset)
            .limit(limit)
        )
    ).scalars().all()
    return {
        "channels": [r.as_dict() for r in rows],
        "total": int(total),
        "limit": limit,
        "offset": offset,
    }


@router.get("/{channel_id}", response_model=ChannelOut)
async def get_channel(
    channel_id: uuid.UUID,
    ctx: TenantContext = Depends(require_permission(Permission.INTEGRATION_READ)),
    session: AsyncSession = Depends(get_session),
):
    row = await session.get(MessageChannel, channel_id)
    if row is None or row.tenant_id != ctx.tenant_id:
        raise HTTPException(status_code=404, detail="channel not found")
    return _to_out(row)


@router.patch("/{channel_id}", response_model=ChannelOut)
async def update_channel(
    channel_id: uuid.UUID,
    payload: ChannelUpdate,
    ctx: TenantContext = Depends(require_permission(Permission.INTEGRATION_WRITE)),
    session: AsyncSession = Depends(get_session),
):
    row = await session.get(MessageChannel, channel_id)
    if row is None or row.tenant_id != ctx.tenant_id:
        raise HTTPException(status_code=404, detail="channel not found")
    if payload.config is not None:
        row.config = payload.config
    if payload.is_active is not None:
        row.is_active = payload.is_active
    row.updated_at = _now()
    await record_enterprise_audit(
        session,
        ctx.tenant_id,
        ctx.user_id,
        "channel.updated",
        {"channel_id": str(row.id), "is_active": row.is_active},
        resource_type="message_channel",
        resource_id=row.id,
    )
    await session.commit()
    await session.refresh(row)
    return _to_out(row)


@router.delete("/{channel_id}")
async def delete_channel(
    channel_id: uuid.UUID,
    ctx: TenantContext = Depends(require_permission(Permission.INTEGRATION_WRITE)),
    session: AsyncSession = Depends(get_session),
):
    row = await session.get(MessageChannel, channel_id)
    if row is None or row.tenant_id != ctx.tenant_id:
        raise HTTPException(status_code=404, detail="channel not found")
    await session.delete(row)
    await record_enterprise_audit(
        session,
        ctx.tenant_id,
        ctx.user_id,
        "channel.deleted",
        {"channel_id": str(channel_id)},
        resource_type="message_channel",
        resource_id=channel_id,
    )
    await session.commit()
    return {"id": str(channel_id), "deleted": True}


@router.post("/{channel_id}/health-check", response_model=HealthCheckOut)
async def check_channel_health(
    channel_id: uuid.UUID,
    ctx: TenantContext = Depends(require_permission(Permission.INTEGRATION_READ)),
    session: AsyncSession = Depends(get_session),
):
    """Fail closed until this channel has a provider-backed health adapter."""
    row = await session.get(MessageChannel, channel_id)
    if row is None or row.tenant_id != ctx.tenant_id:
        raise HTTPException(status_code=404, detail="channel not found")
    raise HTTPException(
        status_code=501,
        detail={
            "code": "channel_health_check_not_implemented",
            "message": "No provider-backed health check is available; channel connectivity was not tested.",
        },
    )


@router.post("/send", response_model=UnifiedConversationOut, status_code=201)
async def send_unified_message(
    payload: UnifiedConversationRequest,
    ctx: TenantContext = Depends(require_permission(Permission.INTEGRATION_SYNC)),
    session: AsyncSession = Depends(get_session),
):
    """Reject sends until a configured provider adapter and durable receipt path exist."""
    channel = (
        await session.execute(
            select(MessageChannel).where(
                MessageChannel.tenant_id == ctx.tenant_id,
                MessageChannel.channel_type == payload.channel_type,
                MessageChannel.is_active.is_(True),
            )
        )
    ).scalars().first()

    if channel is None:
        raise HTTPException(
            status_code=404,
            detail={
                "code": "channel_not_configured",
                "message": f"No active {payload.channel_type} channel is configured for this workspace.",
            },
        )

    raise HTTPException(
        status_code=501,
        detail={
            "code": "channel_send_not_implemented",
            "message": "A provider-backed send adapter and persisted delivery receipt are not configured; no message or call was created.",
        },
    )


@router.get("/{channel_id}/receipts", response_model=dict)
async def get_receipts(
    channel_id: uuid.UUID,
    limit: int = Query(20, ge=1, le=100),
    offset: int = Query(0, ge=0),
    ctx: TenantContext = Depends(require_permission(Permission.INTEGRATION_READ)),
    session: AsyncSession = Depends(get_session),
):
    """Fail closed until delivery receipts are stored and queryable."""
    del limit, offset
    row = await session.get(MessageChannel, channel_id)
    if row is None or row.tenant_id != ctx.tenant_id:
        raise HTTPException(status_code=404, detail="channel not found")
    raise HTTPException(
        status_code=501,
        detail={
            "code": "channel_receipts_not_implemented",
            "message": "No persisted delivery-receipt store is configured; no empty receipt list is substituted.",
        },
    )
