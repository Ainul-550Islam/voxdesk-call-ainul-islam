# File: app/api/workflow_event_routes.py — Missing APIs: workflow call-event triggers, call-context fetch, outcome write-back post-call result → CRM/helpdesk/task/calendar
"""
Workflow event triggers API.
Closes gaps:
25. Workflow call-event triggers — before-call / after-call / transfer / completion event triggers
26. Workflow call-context API — fetch CRM/customer/ticket/booking context before call
27. Workflow outcome write-back API — post-call result → CRM/helpdesk/task/calendar
"""
from __future__ import annotations

import uuid
from datetime import datetime, timezone
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query, Header
from pydantic import BaseModel, ConfigDict, Field
from sqlalchemy import select, func, or_
from sqlalchemy.ext.asyncio import AsyncSession

from app.auth.dependencies import TenantContext, require_permission
from app.auth.permissions import Permission
from app.db.models import Call, Workflow, WorkflowVersion, Environment
from app.db.session import get_session
from app.db.enterprise_models import WorkflowTrigger

from app.services import post_call_workflow as runtime
from app.audit.service import record_event
from app.core.rate_limit import rate_limit
from app.resilience.idempotency import claim_request, complete_request, IdempotencyError
from app.environments.context_resolution import resolve_environment
from app.environments.membership import resolve as resolve_membership
from app.auth.rbac import has_permission
from app.tenancy.isolation import HierarchyError, to_http


async def _environment(session, ctx, write=False, permission=None):
    try:
        env = await resolve_environment(session, user=ctx.user, tenant=ctx.tenant, environment_id=ctx.environment_id)
        if env is None:
            raise HTTPException(409, detail={"code": "NOT_CONFIGURED"})
        decision = await resolve_membership(session, ctx.user, env, ctx.tenant)
        if not decision.allowed or env.status != "active":
            raise HTTPException(404, detail="environment not found")
        if not has_permission(decision.role, permission or (Permission.TENANT_UPDATE if write else Permission.TENANT_READ)):
            raise HTTPException(403, detail="environment permission denied")
        return env
    except HierarchyError as exc:
        raise to_http(exc) from None


async def _binding(session, ctx, config, event_type, workflow_id, enabled):
    if runtime.BINDING not in config:
        return None
    env = await _environment(session, ctx, True)
    if config[runtime.BINDING] != str(env.id):
        raise HTTPException(404, detail="environment not found")
    if set(config) != {runtime.BINDING} or event_type not in runtime.EVENTS:
        raise HTTPException(501, detail={"code": "UNSUPPORTED_CAPABILITY", "capability": "post_call_trigger_config"})
    await session.scalar(select(Environment).where(Environment.id == env.id, Environment.tenant_id == ctx.tenant_id).with_for_update())
    if enabled:
        workflow = await session.scalar(select(Workflow).where(Workflow.id == uuid.UUID(workflow_id), Workflow.tenant_id == ctx.tenant_id))
        version = None if workflow is None else await session.scalar(select(WorkflowVersion).where(
            WorkflowVersion.id == workflow.published_version_id, WorkflowVersion.workflow_id == workflow.id,
            WorkflowVersion.tenant_id == ctx.tenant_id, WorkflowVersion.status == "published"))
        if workflow is None or workflow.status != "active" or version is None:
            raise HTTPException(409, detail={"code": "NOT_CONFIGURED", "capability": "published_workflow"})
        try:
            runtime.definition(version.graph_config, ctx.tenant_id)
        except (ValueError, TypeError, KeyError):
            raise HTTPException(501, detail={"code": "UNSUPPORTED_CAPABILITY", "capability": "workflow_graph"}) from None
    try:
        if not await rate_limit(f"workflow:configuration:{ctx.tenant_id}:{env.id}", 20, 60):
            raise HTTPException(429, detail="Configuration rate exceeded", headers={"Retry-After": "60"})
    except RuntimeError:
        raise HTTPException(501, detail={"code": "NOT_CONFIGURED", "capability": "redis_rate_limit"}) from None
    return env


async def _owned_trigger(session, ctx, trigger_id, write=False):
    row = await session.scalar(select(WorkflowTrigger).where(WorkflowTrigger.id == trigger_id,
        WorkflowTrigger.tenant_id == ctx.tenant_id).with_for_update())
    if row is None:
        raise HTTPException(404, detail="trigger not found")
    if runtime.BINDING in row.config:
        env = await _environment(session, ctx, write)
        if row.config[runtime.BINDING] != str(env.id):
            raise HTTPException(404, detail="trigger not found")
    return row


async def _audit(session, ctx, row, event, env):
    await record_event(session, tenant_id=ctx.tenant_id, environment_id=env.id if env else None,
        actor_user_id=ctx.user_id, event_type=event, resource_type="workflow_trigger", resource_id=row.id)


router = APIRouter(prefix="/api/workflows", tags=["workflow-events"])

class _Strict(BaseModel):
    model_config = ConfigDict(extra="forbid")

class TriggerCreate(_Strict):
    workflow_id: str = Field(min_length=1, max_length=80)
    event_type: str = Field(pattern="^(before_call|after_call|on_transfer|on_completion|on_failure|on_booking)$")
    config: dict = Field(default_factory=dict)
    is_enabled: bool = True

class TriggerUpdate(_Strict):
    event_type: Optional[str] = Field(default=None, pattern="^(before_call|after_call|on_transfer|on_completion|on_failure|on_booking)$")
    config: Optional[dict] = None
    is_enabled: Optional[bool] = None

class TriggerOut(_Strict):
    id: str
    tenant_id: str
    workflow_id: str
    event_type: str
    is_enabled: bool
    config: dict
    created_at: Optional[str] = None
    updated_at: Optional[str] = None

class CallContextOut(_Strict):
    call_id: str
    crm: dict
    customer: dict
    tickets: list[dict]
    bookings: list[dict]
    custom: dict

class OutcomeWritebackRequest(_Strict):
    target: str = Field(pattern="^(crm|helpdesk|task|calendar|webhook)$")
    entity_type: Optional[str] = Field(default=None, max_length=32)
    payload: dict = Field(default_factory=dict)
    idempotency_key: Optional[str] = Field(default=None, min_length=8, max_length=128)

class OutcomeWritebackOut(_Strict):
    id: str
    call_id: str
    target: str
    status: str
    created_at: str

def _now() -> datetime:
    return datetime.now(timezone.utc)

def _to_out(row: WorkflowTrigger) -> TriggerOut:
    d = row.as_dict()
    return TriggerOut(
        id=d["id"],
        tenant_id=d["tenant_id"],
        workflow_id=d["workflow_id"],
        event_type=d["event_type"],
        is_enabled=d["is_enabled"],
        config=d["config"],
        created_at=d["created_at"],
        updated_at=d["updated_at"],
    )

@router.post("/triggers", response_model=TriggerOut, status_code=201)
async def create_trigger(
    payload: TriggerCreate,
    ctx: TenantContext = Depends(require_permission(Permission.TENANT_UPDATE)),
    session: AsyncSession = Depends(get_session),
    idempotency_key: Optional[str] = Header(None, alias="Idempotency-Key", min_length=8, max_length=128),
):
    """Create a trigger; automatic post-call binding requires an Idempotency-Key."""
    # Resolve the authoritative tenant-owned workflow before storing a trigger.
    # Malformed, missing and foreign identifiers share the same 404 response.
    try:
        workflow_id = uuid.UUID(payload.workflow_id)
    except ValueError:
        raise HTTPException(status_code=404, detail="workflow not found") from None
    workflow = await session.scalar(
        select(Workflow).where(Workflow.id == workflow_id, Workflow.tenant_id == ctx.tenant_id)
    )
    if workflow is None:
        raise HTTPException(status_code=404, detail="workflow not found")

    env = await _binding(session, ctx, payload.config, payload.event_type, str(workflow.id), payload.is_enabled)
    claim = None
    if env:
        if not idempotency_key:
            raise HTTPException(422, detail="Idempotency-Key is required")
        try:
            claim = await claim_request(session, tenant_id=ctx.tenant_id, environment_id=env.id,
                operation="workflow.trigger.create", key=idempotency_key, request_data=payload.model_dump(mode="json"))
        except IdempotencyError as exc:
            raise HTTPException(409, detail={"code": exc.code}) from None
        if claim.replayed:
            return _to_out(await _owned_trigger(session, ctx, uuid.UUID(claim.receipt.resource_id), True))
        count = await session.scalar(select(func.count(WorkflowTrigger.id)).where(WorkflowTrigger.tenant_id == ctx.tenant_id,
            WorkflowTrigger.config[runtime.BINDING].as_string() == str(env.id)))
        if count >= runtime.MAX_TRIGGERS:
            raise HTTPException(409, detail="Post-call trigger limit reached; remove unused bindings")

    trigger = WorkflowTrigger(
        tenant_id=ctx.tenant_id,
        workflow_id=str(workflow.id),
        event_type=payload.event_type,
        is_enabled=payload.is_enabled,
        config=payload.config,
    )
    session.add(trigger)
    await session.flush()
    await _audit(session, ctx, trigger, "workflow.trigger_created", env)
    if claim:
        await complete_request(session, claim.receipt, resource_type="workflow_trigger", resource_id=trigger.id)
    await session.commit()
    await session.refresh(trigger)
    return _to_out(trigger)

@router.get("/triggers", response_model=dict)
async def list_triggers(
    workflow_id: Optional[str] = Query(default=None),
    event_type: Optional[str] = Query(default=None),
    is_enabled: Optional[bool] = Query(default=None),
    limit: int = Query(50, ge=1, le=200),
    offset: int = Query(0, ge=0),
    ctx: TenantContext = Depends(require_permission(Permission.TENANT_READ)),
    session: AsyncSession = Depends(get_session),
):
    env = await _environment(session, ctx)
    scope = [WorkflowTrigger.tenant_id == ctx.tenant_id, or_(WorkflowTrigger.config[runtime.BINDING].as_string().is_(None),
        WorkflowTrigger.config[runtime.BINDING].as_string() == str(env.id))]
    if workflow_id:
        scope.append(WorkflowTrigger.workflow_id == workflow_id)
    if event_type:
        scope.append(WorkflowTrigger.event_type == event_type)
    if is_enabled is not None:
        scope.append(WorkflowTrigger.is_enabled == is_enabled)
    total = (await session.execute(select(func.count(WorkflowTrigger.id)).where(*scope))).scalar() or 0
    rows = (
        await session.execute(
            select(WorkflowTrigger).where(*scope).order_by(WorkflowTrigger.created_at.desc()).offset(offset).limit(limit)
        )
    ).scalars().all()
    return {"triggers": [r.as_dict() for r in rows], "total": int(total), "limit": limit, "offset": offset}

@router.get("/triggers/{trigger_id}", response_model=TriggerOut)
async def get_trigger(
    trigger_id: uuid.UUID,
    ctx: TenantContext = Depends(require_permission(Permission.TENANT_READ)),
    session: AsyncSession = Depends(get_session),
):
    row = await _owned_trigger(session, ctx, trigger_id)
    return _to_out(row)

@router.patch("/triggers/{trigger_id}", response_model=TriggerOut)
async def update_trigger(
    trigger_id: uuid.UUID,
    payload: TriggerUpdate,
    ctx: TenantContext = Depends(require_permission(Permission.TENANT_UPDATE)),
    session: AsyncSession = Depends(get_session),
):
    row = await _owned_trigger(session, ctx, trigger_id, True)
    old_config, old_event = row.config, row.event_type
    env = None
    if payload.event_type is not None:
        row.event_type = payload.event_type
    if payload.config is not None:
        row.config = payload.config
    if payload.is_enabled is not None:
        row.is_enabled = payload.is_enabled
    new_env = await _binding(session, ctx, row.config, row.event_type, row.workflow_id, row.is_enabled)
    if new_env is None and runtime.BINDING in old_config:
        env = await _binding(session, ctx, old_config, old_event, row.workflow_id, False)
    if new_env:
        count = await session.scalar(select(func.count(WorkflowTrigger.id)).where(WorkflowTrigger.tenant_id == ctx.tenant_id,
            WorkflowTrigger.config[runtime.BINDING].as_string() == str(new_env.id)))
        if count > runtime.MAX_TRIGGERS:
            raise HTTPException(409, detail="Post-call trigger limit reached")
    await _audit(session, ctx, row, "workflow.trigger_updated", new_env or env)
    row.updated_at = _now()
    await session.commit()
    await session.refresh(row)
    return _to_out(row)

@router.delete("/triggers/{trigger_id}")
async def delete_trigger(
    trigger_id: uuid.UUID,
    ctx: TenantContext = Depends(require_permission(Permission.TENANT_UPDATE)),
    session: AsyncSession = Depends(get_session),
):
    row = await _owned_trigger(session, ctx, trigger_id, True)
    env = await _binding(session, ctx, row.config, row.event_type, row.workflow_id, False)
    await _audit(session, ctx, row, "workflow.trigger_deleted", env)
    await session.delete(row)
    await session.commit()
    return {"id": str(trigger_id), "deleted": True}

@router.get("/calls/{call_id}/context", response_model=CallContextOut)
async def get_call_context(
    call_id: uuid.UUID,
    ctx: TenantContext = Depends(require_permission(Permission.CALL_READ)),
    session: AsyncSession = Depends(get_session),
):
    """
    GET /api/workflows/calls/{id}/context — Fetch CRM/customer/ticket/booking context before call.
    Aggregates from CRM adapters, calendar, etc.
    """
    call = await session.get(Call, call_id)
    if call is None or call.tenant_id != ctx.tenant_id:
        raise HTTPException(status_code=404, detail="call not found")
    from app.db.models import Appointment, Lead

    crm = {}
    customer = {}
    if call.lead_id:
        lead = await session.get(Lead, call.lead_id)
        if lead is not None and lead.tenant_id == ctx.tenant_id:
            crm = {"lead": {"id": str(lead.id), "name": lead.name, "phone": lead.phone,
                            "email": lead.email, "company": lead.company, "score": lead.score}}
            customer = {"name": lead.name, "phone": lead.phone, "email": lead.email}
    appointments = (await session.scalars(select(Appointment).where(
        Appointment.tenant_id == ctx.tenant_id, Appointment.call_id == call_id
    ))).all()
    bookings = [{"id": str(a.id), "starts_at": a.starts_at.isoformat() if a.starts_at else None,
                 "status": a.status.value} for a in appointments]
    return CallContextOut(call_id=str(call.id), crm=crm, customer=customer, tickets=[],
                          bookings=bookings, custom=getattr(call, "custom_fields", {}) or {})

@router.post("/calls/{call_id}/outcome-writeback", response_model=OutcomeWritebackOut, status_code=201)
async def outcome_writeback(
    call_id: uuid.UUID,
    payload: OutcomeWritebackRequest,
    ctx: TenantContext = Depends(require_permission(Permission.INTEGRATION_SYNC)),
    session: AsyncSession = Depends(get_session),
):
    """
    POST /api/workflows/calls/{id}/outcome-writeback — Post-call result → CRM/helpdesk/task/calendar.
    Idempotent via idempotency_key if provided.
    """
    call = await session.get(Call, call_id)
    if call is None or call.tenant_id != ctx.tenant_id:
        raise HTTPException(status_code=404, detail="call not found")

    raise HTTPException(status_code=501, detail="WORKFLOW_WRITEBACK_RUNTIME_NOT_IMPLEMENTED")


@router.get("/calls/{call_id}/executions", response_model=dict)
async def post_call_executions(
    call_id: uuid.UUID,
    limit: int = Query(50, ge=1, le=200),
    offset: int = Query(0, ge=0),
    ctx: TenantContext = Depends(require_permission(Permission.CALL_READ)),
    session: AsyncSession = Depends(get_session),
):
    """Scoped workflow outcomes, separate from durable job acknowledgements."""
    from app.db.models import DurableJob, WorkflowExecution
    from app.jobs.types import JobType
    env = await _environment(session, ctx, permission=Permission.CALL_READ)
    call = await session.scalar(select(Call).where(Call.id == call_id, Call.tenant_id == ctx.tenant_id,
        Call.environment_id == env.id))
    if call is None:
        raise HTTPException(404, detail="call not found")
    scope = (DurableJob.tenant_id == ctx.tenant_id, DurableJob.environment_id == env.id,
        DurableJob.job_type == JobType.WORKFLOW_EXECUTION, DurableJob.payload["call_id"].as_string() == str(call_id))
    total = await session.scalar(select(func.count(DurableJob.id)).where(*scope))
    jobs = list((await session.scalars(select(DurableJob).where(*scope).order_by(DurableJob.created_at, DurableJob.id)
        .limit(limit).offset(offset))).all())
    items = []
    for job in jobs:
        execution = await session.scalar(select(WorkflowExecution).where(
            WorkflowExecution.id == uuid.uuid5(job.id, "post-call-workflow:v1"), WorkflowExecution.tenant_id == ctx.tenant_id))
        if execution and (execution.input_payload.get("environment_id") != str(env.id)
                          or execution.input_payload.get("call_id") != str(call.id)):
            raise HTTPException(409, detail="Workflow execution scope inconsistent")
        items.append({"job_id": str(job.id), "job_status": job.status, "job_error": job.last_error_category,
            "version_id": job.payload.get("version_id"),
            "execution": None if execution is None else {"id": str(execution.id), "status": execution.status,
                "output": execution.output_metadata, "attempts": execution.attempt_count}})
    return {"items": items, "total": total, "limit": limit, "offset": offset}
