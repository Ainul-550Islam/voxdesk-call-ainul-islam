"""
Normalized events and idempotency.

The central rule of this step: **a business fact is recorded once, delivery is
attempted many times.** The old code conflated the two — `call.crm_synced` was
set before the POST, so a crash in between lost the event permanently while
still claiming it was sent.

Here, `emit()` writes a `CrmEvent` and a `CrmSync` row per enabled
integration, inside the caller's transaction. Nothing is sent. A worker picks
the syncs up afterwards. If the process dies immediately after the commit, the
event survives and is delivered late; if it dies before, the business fact was
never committed either, so there is nothing to lose.

**Idempotency keys are derived, not generated.** A random uuid per emit would
make every duplicate call a new event, which is exactly the failure mode
requirement 12 lists: duplicate webhooks, worker restarts, and API timeouts
after the provider already accepted. The key is a pure function of the
business fact, so the same fact computes the same key forever, and the unique
constraint on `(tenant_id, idempotency_key)` turns a duplicate emit into a
no-op at the database level rather than a race in Python.
"""
from __future__ import annotations

import uuid
from typing import Any

from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.logging import log
from app.db.models import (
    CrmEntityType,
    CrmEvent,
    CrmEventType,
    CrmIntegration,
    CrmSync,
    CrmSyncStatus,
)

#: Bumped when the shape of `CrmEvent.payload` changes incompatibly, so an
#: adapter can tell an old queued row from a new one after a deploy.
PAYLOAD_VERSION = 1

#: Which entity each event type is about. Derived rather than passed in, so a
#: caller cannot file a `lead.created` against a call id.
_ENTITY_FOR_EVENT: dict[CrmEventType, CrmEntityType] = {
    CrmEventType.CALL_COMPLETED: CrmEntityType.CALL,
    CrmEventType.CALL_MISSED: CrmEntityType.CALL,
    CrmEventType.TRANSFER_COMPLETED: CrmEntityType.CALL,
    CrmEventType.LEAD_CREATED: CrmEntityType.LEAD,
    CrmEventType.LEAD_UPDATED: CrmEntityType.LEAD,
    CrmEventType.APPOINTMENT_BOOKED: CrmEntityType.APPOINTMENT,
    CrmEventType.APPOINTMENT_CANCELLED: CrmEntityType.APPOINTMENT,
}


def entity_type_for(event_type: CrmEventType) -> CrmEntityType:
    return _ENTITY_FOR_EVENT[event_type]


def idempotency_key(
    event_type: CrmEventType, entity_id: uuid.UUID | str, *, discriminator: str = ""
) -> str:
    """
    The stable identity of one business fact.

    `"{event}:{entity}"` and nothing else — deliberately not hashed, not
    timestamped, not random. Two properties follow, and both are load-bearing:

    * **Deterministic.** The same call completing twice (a retried Twilio
      webhook) computes the same key, so the second emit collides and is
      dropped.
    * **Legible.** `call.completed:3f2a...` in a log or a support query says
      what it is. A sha256 would need a lookup to mean anything.

    `discriminator` exists for facts that genuinely can recur for one entity:
    an appointment rescheduled twice is two real events on the same row, so
    the timestamp of the change distinguishes them.
    """
    base = f"{event_type.value}:{entity_id}"
    return f"{base}:{discriminator}" if discriminator else base


async def emit(
    session: AsyncSession,
    *,
    tenant_id: uuid.UUID,
    event_type: CrmEventType,
    entity_id: uuid.UUID,
    payload: dict[str, Any],
    discriminator: str = "",
    integration_ids: list[uuid.UUID] | None = None,
) -> CrmEvent | None:
    """
    Record a business event and queue it for every enabled integration.

    Returns the event, or `None` when this exact fact was already recorded.
    `None` is a success: it means idempotency did its job.

    Does **not** commit. The caller owns the transaction, which is the point —
    the event and the thing that caused it land together or not at all.
    """
    key = idempotency_key(event_type, entity_id, discriminator=discriminator)

    existing = (
        await session.execute(
            select(CrmEvent).where(
                CrmEvent.tenant_id == tenant_id,
                CrmEvent.idempotency_key == key,
            )
        )
    ).scalar_one_or_none()
    if existing is not None:
        log.info(
            "crm.event_duplicate", tenant_id=str(tenant_id),
            event_type=event_type.value, idempotency_key=key,
        )
        return None

    event = CrmEvent(
        tenant_id=tenant_id,
        event_type=event_type,
        entity_type=entity_type_for(event_type),
        entity_id=entity_id,
        idempotency_key=key,
        payload=payload,
        payload_version=PAYLOAD_VERSION,
    )
    # Keep duplicate arbitration inside the caller's transaction, including
    # SQLite's legacy SELECT-without-BEGIN mode used by local tests.
    connection = await session.connection()
    if connection.dialect.name == "sqlite":
        raw = await connection.get_raw_connection()
        if not raw.driver_connection.in_transaction:
            await connection.exec_driver_sql("BEGIN")
    try:
        async with session.begin_nested():
            session.add(event)
            await session.flush()
    except IntegrityError:
        duplicate = await session.scalar(select(CrmEvent.id).where(
            CrmEvent.tenant_id == tenant_id, CrmEvent.idempotency_key == key))
        if duplicate is None:
            raise
        return None

    integrations = await _subscribed_integrations(session, tenant_id, event_type)
    if integration_ids is not None:
        wanted = set(integration_ids)
        integrations = [row for row in integrations if row.id in wanted]
        if {row.id for row in integrations} != wanted:
            raise ValueError("CRM integration scope or subscription changed")
    for integration in integrations:
        session.add(
            CrmSync(
                tenant_id=tenant_id,
                event_id=event.id,
                integration_id=integration.id,
                provider=integration.provider,
                entity_type=event.entity_type,
                entity_id=entity_id,
                status=CrmSyncStatus.PENDING,
            )
        )

    log.info(
        "crm.event_emitted", tenant_id=str(tenant_id), event_type=event_type.value,
        entity_id=str(entity_id), idempotency_key=key, queued=len(integrations),
    )
    return event


async def _subscribed_integrations(
    session: AsyncSession, tenant_id: uuid.UUID, event_type: CrmEventType
) -> list[CrmIntegration]:
    """
    Enabled integrations for this tenant that want this event.

    The `tenant_id` predicate is the isolation boundary. An empty
    `subscribed_events` means "everything", because the alternative — a tenant
    connecting a CRM and receiving nothing until they also tick seven boxes —
    is a support ticket rather than a feature.
    """
    rows = (
        (
            await session.execute(
                select(CrmIntegration).where(
                    CrmIntegration.tenant_id == tenant_id,
                    CrmIntegration.is_enabled.is_(True),
                )
            )
        )
        .scalars()
        .all()
    )
    return [
        integration for integration in rows
        if not integration.subscribed_events
        or event_type.value in integration.subscribed_events
    ]


# ------------------------------------------------------------- payloads ---

def call_payload(call: Any, tenant: Any, *, include_transcript_reference: bool = True) -> dict:
    """
    Safe metadata for a call event (requirement 18).

    Note the shape of the transcript field: a **reference**, never the
    transcript. The brief is explicit that full transcripts must not be
    blindly sent to every provider, and a call transcript is the most
    sensitive thing this product holds — a caller reciting a card number, a
    diagnosis, an address. Providers that should receive the text get it via
    the per-integration `share_transcripts` flag, applied in `service.py`
    where the integration is in scope. This function never has it.
    """
    payload = {
        "call_id": str(call.id),
        "call_sid": call.call_sid,
        "direction": getattr(call.direction, "value", str(call.direction)),
        "status": getattr(call.status, "value", str(call.status)),
        "from_number": call.from_number,
        "to_number": call.to_number,
        "duration_seconds": round(call.duration_seconds or 0.0, 1),
        "intent": call.intent,
        "summary": call.summary or "",
        "booked": bool(call.booked),
        "transferred": bool(call.escalated),
        "lead_score": call.lead_score,
        "recording_url": call.recording_url,
        "business": tenant.name if tenant else "",
    }
    if include_transcript_reference:
        payload["transcript_reference"] = f"voxdesk:call:{call.id}:turns"
    return payload


def lead_payload(lead: Any) -> dict:
    return {
        "lead_id": str(lead.id),
        "name": lead.name or "",
        "phone": lead.phone,
        "email": lead.email,
        "company": lead.company,
        "status": getattr(lead.status, "value", str(lead.status)),
        "score": lead.score,
        "notes": lead.notes or "",
        "campaign_id": str(lead.campaign_id) if lead.campaign_id else None,
        "custom_fields": dict(lead.custom_fields or {}),
    }


def appointment_payload(appointment: Any) -> dict:
    return {
        "appointment_id": str(appointment.id),
        "call_id": str(appointment.call_id) if appointment.call_id else None,
        "customer_name": appointment.customer_name,
        "customer_phone": appointment.customer_phone,
        "reason": appointment.reason or "",
        "starts_at": appointment.starts_at.isoformat() if appointment.starts_at else None,
        "ends_at": appointment.ends_at.isoformat() if appointment.ends_at else None,
    }

async def admit_post_call(session, call, tenant, analysis):
    """Opt-in admission into the existing CRM delivery queue, never delivery proof.

    Tenant-wide legacy connections must explicitly bind an environment using
    config.post_call_analysis_environment_id before receiving analyzed data.
    The caller holds the scoped Call lock and owns the surrounding savepoint.
    """
    from app.telephony.call_state import is_terminal
    from app.audit.service import record_event
    if call.tenant_id != tenant.id or not call.environment_id or not is_terminal(call.status):
        raise ValueError("Invalid terminal CRM call scope")
    event_type = CrmEventType.CALL_COMPLETED if str(getattr(call.status, "value", call.status)) == "completed" else CrmEventType.CALL_MISSED
    candidates = await _subscribed_integrations(session, tenant.id, event_type)
    selected = [row.id for row in candidates if (row.config or {}).get("post_call_analysis_environment_id") == str(call.environment_id)]
    if not selected:
        return {"event_id": None, "sync_ids": [], "delivery": "not_requested"}
    payload = call_payload(call, tenant, include_transcript_reference=False)
    payload.update({"post_call_analysis_version": 1, "environment_id": str(call.environment_id), "analysis": analysis})
    async with session.begin_nested():
        event = await emit(session, tenant_id=tenant.id, event_type=event_type, entity_id=call.id,
            payload=payload, discriminator="post-analysis:v1", integration_ids=selected)
        if event is None:
            event = await session.scalar(select(CrmEvent).where(CrmEvent.tenant_id == tenant.id,
                CrmEvent.idempotency_key == idempotency_key(event_type, call.id, discriminator="post-analysis:v1")))
            if event is None or event.payload.get("environment_id") != str(call.environment_id):
                raise ValueError("CRM event scope mismatch")
        await session.flush()
        syncs = list((await session.scalars(select(CrmSync).where(CrmSync.tenant_id == tenant.id,
            CrmSync.event_id == event.id))).all())
        await record_event(session, tenant_id=tenant.id, environment_id=call.environment_id,
            actor_type="system", event_type="crm.analysis_admitted", resource_type="crm_event", resource_id=event.id,
            detail={"call_id": str(call.id), "sync_ids": [str(row.id) for row in syncs]})
    return {"event_id": str(event.id), "sync_ids": [str(row.id) for row in syncs], "delivery": "admitted"}
