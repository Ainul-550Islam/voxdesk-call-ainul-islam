/**
 * dashboard/src/config/useCaseRoutes.ts
 * Route constants, breadcrumbs, search hints, pagination constants.
 */
export const USE_CASE_PAGE_SIZE = 12;
export const USE_CASE_MAX_PAGE_SIZE = 50;
export const USE_CASE_SEARCH_DEBOUNCE_MS = 300;
export const USE_CASE_MAX_SEARCH_LENGTH = 200;
export const USE_CASE_MAX_SLUG_LENGTH = 200;

export const USE_CASE_ROUTES = {
  LIST: '/use-cases',
  DETAIL: '/use-cases/:slug',
  SOLUTIONS_LIST: '/solutions/use-cases',
  SOLUTIONS_DETAIL: '/solutions/use-cases/:slug',
} as const;

export const SEARCH_HINTS = [
  'appointment',
  'receptionist',
  'support',
  'lead qualification',
  'dental',
  'real estate',
  'healthcare',
  'sales',
  'call center',
  'scheduling',
];

export const CATEGORY_ORDER = ['all', 'receptionists', 'call-centers', 'industry', 'assistants', 'sales'] as const;

export function getSearchHint(): string {
  return SEARCH_HINTS[Math.floor(Math.random() * SEARCH_HINTS.length)];
}

export function getBreadcrumbsForList() {
  return [
    { label: 'Home', href: '/' },
    { label: 'Use Cases', current: true },
  ];
}

export function getBreadcrumbsForDetail(slug: string, title: string, category: string, categoryTitle: string) {
  return [
    { label: 'Home', href: '/' },
    { label: 'Use Cases', href: '/use-cases' },
    { label: categoryTitle || category, href: `/use-cases?category=${category}` },
    { label: title, current: true },
  ];
}

export const USE_CASE_ROUTES_VERSION = '1.0.0';
