"""Authorized durable redrive: ledger and outbox intent change together."""
from __future__ import annotations

import uuid
from datetime import datetime, timezone

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.auth.permissions import Permission
from app.auth.rbac import has_permission
from app.db.models import UserRole, WebhookDelivery
from app.outbox.models import OutboxEvent
from app.resources.exceptions import ResourceUnauthorized
from app.tenancy.isolation import BoundaryDenied, Conflict
from app.webhooks.repository import get_subscription

_MAX_REPLAY = 3


def operator_may_replay(role: UserRole | None) -> bool:
    return role is not None and has_permission(role, Permission.CAMPAIGN_RUN)


async def replay_delivery(
    session: AsyncSession, *, tenant_id: uuid.UUID, delivery_id: uuid.UUID,
    subscription_id: uuid.UUID, role: UserRole | None,
) -> WebhookDelivery:
    if not operator_may_replay(role):
        raise ResourceUnauthorized()
    subscription = await get_subscription(session, tenant_id=tenant_id, subscription_id=subscription_id)
    row = (await session.execute(select(WebhookDelivery).where(
        WebhookDelivery.id == delivery_id, WebhookDelivery.tenant_id == tenant_id,
        WebhookDelivery.subscription_id == subscription_id,
    ))).scalar_one_or_none()
    if subscription is None or row is None:
        raise BoundaryDenied()
    if not subscription.enabled:
        raise Conflict("Webhook subscription is disabled")
    if row.legacy_envelope or row.last_error_category == "legacy_unverified":
        raise Conflict("UNSUPPORTED_CAPABILITY: quarantined legacy delivery requires operator review")
    try:
        event_id = uuid.UUID(row.event_id)
    except ValueError:
        raise Conflict("UNSUPPORTED_CAPABILITY: delivery has no durable outbox event") from None
    # Same lock order as the worker: event first, then delivery.
    event = (await session.execute(select(OutboxEvent).where(
        OutboxEvent.id == event_id, OutboxEvent.tenant_id == tenant_id,
        OutboxEvent.environment_id == row.environment_id,
    ).with_for_update().execution_options(populate_existing=True))).scalar_one_or_none()
    if event is None:
        raise BoundaryDenied()
    row = (await session.execute(select(WebhookDelivery).where(
        WebhookDelivery.id == delivery_id, WebhookDelivery.tenant_id == tenant_id,
        WebhookDelivery.subscription_id == subscription_id,
    ).with_for_update().execution_options(populate_existing=True))).scalar_one()
    if row.status not in {"dead_letter", "failed", "permanent_failure"}:
        raise Conflict("Delivery is already queued or acknowledged")
    if row.replay_count >= _MAX_REPLAY:
        raise Conflict("Replay budget exhausted")
    budget = int((subscription.delivery_options or {}).get("max_attempts", 8))
    row.replay_count += 1
    row.attempt_limit = row.attempt + budget
    row.status = "queued"
    row.next_attempt_at = datetime.now(timezone.utc)
    row.completed_at = None
    event.status = "pending"
    event.available_at = row.next_attempt_at
    event.max_attempts = max(event.max_attempts, event.attempt_count + budget)
    event.delivered_at = None
    event.last_error = ""
    event.last_error_category = ""
    await session.flush()
    return row
