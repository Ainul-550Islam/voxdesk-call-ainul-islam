"""Alembic environment. Reads the URL from app settings, not from alembic.ini."""
import asyncio
from logging.config import fileConfig

from alembic import context
from sqlalchemy.ext.asyncio import async_engine_from_config
from sqlalchemy import pool

from app.core.config import settings
from app.db.models import Base
from app.db.migration_compatibility import normalize_legacy_revision_aliases
import app.governance  # noqa: F401 - registers additive governance models
import app.qa.outcomes  # noqa: F401 - registers durable call-outcome metadata
import app.deployment.models  # noqa: F401 - registers runtime deployment observation metadata
import app.db.enterprise_models  # noqa: F401 - registers P0/P1 missing API tables (batch_calls, ab_experiments, retention, webhooks, salesforce, kb collections, simulation, tool registry, workflow triggers, multichannel, call policies, DNC)
import app.telephony.number_trust  # noqa: F401 - registers number_trust_profiles table

config = context.config
config.set_main_option("sqlalchemy.url", settings.database_url)

if config.config_file_name is not None:
    fileConfig(config.config_file_name)

target_metadata = Base.metadata


def run_migrations_offline() -> None:
    context.configure(
        url=settings.database_url,
        target_metadata=target_metadata,
        literal_binds=True,
        dialect_opts={"paramstyle": "named"},
        compare_type=True,
    )
    with context.begin_transaction():
        context.run_migrations()


def do_run_migrations(connection) -> None:
    # Normalize only known historical overlength revision markers before
    # Alembic reads alembic_version. This is metadata-only compatibility; it
    # does not touch application rows or migration schema.
    normalize_legacy_revision_aliases(connection)
    context.configure(
        connection=connection, target_metadata=target_metadata, compare_type=True
    )
    with context.begin_transaction():
        context.run_migrations()


async def run_async_migrations() -> None:
    connectable = async_engine_from_config(
        config.get_section(config.config_ini_section, {}),
        prefix="sqlalchemy.",
        poolclass=pool.NullPool,
    )
    async with connectable.connect() as connection:
        await connection.run_sync(do_run_migrations)
    await connectable.dispose()


def run_migrations_online() -> None:
    asyncio.run(run_async_migrations())


if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
