"""Add inbound/outbound agent binding columns on phone_numbers and calls.

Revision ID: 0059_number_agent_binding
Revises: 0058_call_latency_stats
Create Date: 2026-10-08
"""

from __future__ import annotations

import sqlalchemy as sa
from alembic import op

revision = "0059_number_agent_binding"
down_revision = "0058_call_latency_stats"
branch_labels = None
depends_on = None


def _has_table(bind, table_name: str) -> bool:
    inspector = sa.inspect(bind)
    return table_name in inspector.get_table_names()


def _has_column(bind, table_name: str, column_name: str) -> bool:
    inspector = sa.inspect(bind)
    if table_name not in inspector.get_table_names():
        return False
    return any(col["name"] == column_name for col in inspector.get_columns(table_name))


def _has_index(bind, table_name: str, index_name: str) -> bool:
    inspector = sa.inspect(bind)
    if table_name not in inspector.get_table_names():
        return False
    return any(ix["name"] == index_name for ix in inspector.get_indexes(table_name))


def upgrade() -> None:
    bind = op.get_bind()

    if _has_table(bind, "phone_numbers"):
        if not _has_column(bind, "phone_numbers", "inbound_agent_id"):
            op.add_column(
                "phone_numbers",
                sa.Column("inbound_agent_id", sa.Uuid(), nullable=True),
            )
        if not _has_column(bind, "phone_numbers", "inbound_agent_version"):
            op.add_column(
                "phone_numbers",
                sa.Column("inbound_agent_version", sa.Integer(), nullable=True),
            )
        if not _has_column(bind, "phone_numbers", "outbound_agent_id"):
            op.add_column(
                "phone_numbers",
                sa.Column("outbound_agent_id", sa.Uuid(), nullable=True),
            )
        if not _has_index(bind, "phone_numbers", "ix_phone_numbers_inbound_agent_id"):
            op.create_index(
                "ix_phone_numbers_inbound_agent_id",
                "phone_numbers",
                ["inbound_agent_id"],
            )
        if not _has_index(bind, "phone_numbers", "ix_phone_numbers_outbound_agent_id"):
            op.create_index(
                "ix_phone_numbers_outbound_agent_id",
                "phone_numbers",
                ["outbound_agent_id"],
            )

    if _has_table(bind, "telephony_phone_numbers"):
        if not _has_column(bind, "telephony_phone_numbers", "inbound_agent_version"):
            op.add_column(
                "telephony_phone_numbers",
                sa.Column("inbound_agent_version", sa.Integer(), nullable=True),
            )

    if _has_table(bind, "calls"):
        if not _has_column(bind, "calls", "agent_id"):
            op.add_column(
                "calls",
                sa.Column("agent_id", sa.Uuid(), nullable=True),
            )
        if not _has_column(bind, "calls", "agent_version_id"):
            op.add_column(
                "calls",
                sa.Column("agent_version_id", sa.Uuid(), nullable=True),
            )
        if not _has_index(bind, "calls", "ix_calls_agent_id"):
            op.create_index("ix_calls_agent_id", "calls", ["agent_id"])
        if not _has_index(bind, "calls", "ix_calls_agent_version_id"):
            op.create_index("ix_calls_agent_version_id", "calls", ["agent_version_id"])


def downgrade() -> None:
    bind = op.get_bind()

    if _has_table(bind, "calls"):
        if _has_index(bind, "calls", "ix_calls_agent_version_id"):
            op.drop_index("ix_calls_agent_version_id", table_name="calls")
        if _has_index(bind, "calls", "ix_calls_agent_id"):
            op.drop_index("ix_calls_agent_id", table_name="calls")
        if _has_column(bind, "calls", "agent_version_id"):
            op.drop_column("calls", "agent_version_id")
        if _has_column(bind, "calls", "agent_id"):
            op.drop_column("calls", "agent_id")

    if _has_table(bind, "telephony_phone_numbers"):
        if _has_column(bind, "telephony_phone_numbers", "inbound_agent_version"):
            op.drop_column("telephony_phone_numbers", "inbound_agent_version")

    if _has_table(bind, "phone_numbers"):
        if _has_index(bind, "phone_numbers", "ix_phone_numbers_outbound_agent_id"):
            op.drop_index("ix_phone_numbers_outbound_agent_id", table_name="phone_numbers")
        if _has_index(bind, "phone_numbers", "ix_phone_numbers_inbound_agent_id"):
            op.drop_index("ix_phone_numbers_inbound_agent_id", table_name="phone_numbers")
        if _has_column(bind, "phone_numbers", "outbound_agent_id"):
            op.drop_column("phone_numbers", "outbound_agent_id")
        if _has_column(bind, "phone_numbers", "inbound_agent_version"):
            op.drop_column("phone_numbers", "inbound_agent_version")
        if _has_column(bind, "phone_numbers", "inbound_agent_id"):
            op.drop_column("phone_numbers", "inbound_agent_id")
