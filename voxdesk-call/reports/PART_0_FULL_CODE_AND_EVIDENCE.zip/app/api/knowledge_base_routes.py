# File: app/api/knowledge_base_routes.py — Missing API: reusable KB entity layer collection CRUD + source management + agent binding + sync status
"""
Reusable Knowledge Base entity layer.
Closes gap 20: documents/URL/search/reindex exists but KB collection CRUD + source management + agent binding + sync status missing.
"""
from __future__ import annotations

import uuid
from datetime import datetime, timezone
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, ConfigDict, Field
from sqlalchemy import select, func
from sqlalchemy.ext.asyncio import AsyncSession

from app.auth.dependencies import TenantContext, require_permission
from app.auth.permissions import Permission
from app.db.session import get_session
from app.db.enterprise_models import KnowledgeCollection, KnowledgeCollectionSource

router = APIRouter(prefix="/api/kb", tags=["knowledge-base-collections"])

class _Strict(BaseModel):
    model_config = ConfigDict(extra="forbid")

class CollectionCreate(_Strict):
    name: str = Field(min_length=1, max_length=200)
    description: str = Field(default="", max_length=2000)
    agent_ids: list[str] = Field(default_factory=list, max_length=100)
    meta: dict = Field(default_factory=dict)

class CollectionUpdate(_Strict):
    name: Optional[str] = Field(default=None, min_length=1, max_length=200)
    description: Optional[str] = None
    agent_ids: Optional[list[str]] = None
    is_active: Optional[bool] = None
    meta: Optional[dict] = None

class CollectionOut(_Strict):
    id: str
    tenant_id: str
    name: str
    description: str
    agent_ids: list[str]
    is_active: bool
    sync_status: str
    last_sync_at: Optional[str] = None
    created_at: Optional[str] = None
    updated_at: Optional[str] = None
    meta: dict

class SourceCreate(_Strict):
    source_type: str = Field(pattern="^(document|url|api|connector|s3|gdrive|notion)$")
    source_id: str = Field(min_length=1, max_length=200)
    uri: str = Field(default="", max_length=500)

class SourceOut(_Strict):
    id: str
    collection_id: str
    tenant_id: str
    source_type: str
    source_id: str
    uri: str
    sync_status: str
    last_sync_at: Optional[str] = None
    error: str
    created_at: Optional[str] = None

class AgentBindingRequest(_Strict):
    agent_ids: list[str] = Field(min_length=1, max_length=100)

def _now() -> datetime:
    return datetime.now(timezone.utc)

def _coll_out(row: KnowledgeCollection) -> CollectionOut:
    d = row.as_dict()
    return CollectionOut(
        id=d["id"],
        tenant_id=d["tenant_id"],
        name=d["name"],
        description=d["description"],
        agent_ids=d["agent_ids"],
        is_active=d["is_active"],
        sync_status=d["sync_status"],
        last_sync_at=d["last_sync_at"],
        created_at=d["created_at"],
        updated_at=d["updated_at"],
        meta=d["meta"],
    )

@router.post("/collections", response_model=CollectionOut, status_code=201)
async def create_collection(
    payload: CollectionCreate,
    ctx: TenantContext = Depends(require_permission(Permission.KNOWLEDGE_WRITE)),
    session: AsyncSession = Depends(get_session),
):
    """POST /api/kb/collections — Create KB collection."""
    coll = KnowledgeCollection(
        tenant_id=ctx.tenant_id,
        name=payload.name,
        description=payload.description,
        agent_ids=payload.agent_ids,
        is_active=True,
        sync_status="idle",
        created_by=ctx.user_id,
        meta=payload.meta,
    )
    session.add(coll)
    await session.commit()
    await session.refresh(coll)
    return _coll_out(coll)

@router.get("/collections", response_model=dict)
async def list_collections(
    is_active: Optional[bool] = Query(default=None),
    agent_id: Optional[str] = Query(default=None),
    limit: int = Query(50, ge=1, le=200),
    offset: int = Query(0, ge=0),
    ctx: TenantContext = Depends(require_permission(Permission.KNOWLEDGE_READ)),
    session: AsyncSession = Depends(get_session),
):
    scope = [KnowledgeCollection.tenant_id == ctx.tenant_id]
    if is_active is not None:
        scope.append(KnowledgeCollection.is_active == is_active)
    total = (await session.execute(select(func.count(KnowledgeCollection.id)).where(*scope))).scalar() or 0
    rows = (
        await session.execute(
            select(KnowledgeCollection).where(*scope).order_by(KnowledgeCollection.created_at.desc()).offset(offset).limit(limit)
        )
    ).scalars().all()

    if agent_id:
        rows = [r for r in rows if agent_id in (r.agent_ids or [])]
        total = len(rows)

    return {"collections": [r.as_dict() for r in rows], "total": int(total), "limit": limit, "offset": offset}

@router.get("/collections/{collection_id}", response_model=CollectionOut)
async def get_collection(
    collection_id: uuid.UUID,
    ctx: TenantContext = Depends(require_permission(Permission.KNOWLEDGE_READ)),
    session: AsyncSession = Depends(get_session),
):
    row = await session.get(KnowledgeCollection, collection_id)
    if row is None or row.tenant_id != ctx.tenant_id:
        raise HTTPException(status_code=404, detail="collection not found")
    return _coll_out(row)

@router.patch("/collections/{collection_id}", response_model=CollectionOut)
async def update_collection(
    collection_id: uuid.UUID,
    payload: CollectionUpdate,
    ctx: TenantContext = Depends(require_permission(Permission.KNOWLEDGE_WRITE)),
    session: AsyncSession = Depends(get_session),
):
    row = await session.get(KnowledgeCollection, collection_id)
    if row is None or row.tenant_id != ctx.tenant_id:
        raise HTTPException(status_code=404, detail="collection not found")
    if payload.name is not None:
        row.name = payload.name
    if payload.description is not None:
        row.description = payload.description
    if payload.agent_ids is not None:
        row.agent_ids = payload.agent_ids
    if payload.is_active is not None:
        row.is_active = payload.is_active
    if payload.meta is not None:
        row.meta = payload.meta
    row.updated_at = _now()
    await session.commit()
    await session.refresh(row)
    return _coll_out(row)

@router.delete("/collections/{collection_id}")
async def delete_collection(
    collection_id: uuid.UUID,
    ctx: TenantContext = Depends(require_permission(Permission.KNOWLEDGE_DELETE)),
    session: AsyncSession = Depends(get_session),
):
    row = await session.get(KnowledgeCollection, collection_id)
    if row is None or row.tenant_id != ctx.tenant_id:
        raise HTTPException(status_code=404, detail="collection not found")
    await session.delete(row)
    await session.commit()
    return {"id": str(collection_id), "deleted": True}

@router.post("/collections/{collection_id}/sources", response_model=SourceOut, status_code=201)
async def add_source(
    collection_id: uuid.UUID,
    payload: SourceCreate,
    ctx: TenantContext = Depends(require_permission(Permission.KNOWLEDGE_WRITE)),
    session: AsyncSession = Depends(get_session),
):
    """POST /api/kb/collections/{id}/sources — Source management."""
    coll = await session.get(KnowledgeCollection, collection_id)
    if coll is None or coll.tenant_id != ctx.tenant_id:
        raise HTTPException(status_code=404, detail="collection not found")

    src = KnowledgeCollectionSource(
        collection_id=collection_id,
        tenant_id=ctx.tenant_id,
        source_type=payload.source_type,
        source_id=payload.source_id,
        uri=payload.uri,
        sync_status="pending",
    )
    session.add(src)
    coll.sync_status = "syncing"
    coll.updated_at = _now()
    await session.commit()
    await session.refresh(src)
    d = src.as_dict()
    return SourceOut(
        id=d["id"],
        collection_id=d["collection_id"],
        tenant_id=d["tenant_id"],
        source_type=d["source_type"],
        source_id=d["source_id"],
        uri=d["uri"],
        sync_status=d["sync_status"],
        last_sync_at=d["last_sync_at"],
        error=d["error"],
        created_at=d["created_at"],
    )

@router.get("/collections/{collection_id}/sources", response_model=dict)
async def list_sources(
    collection_id: uuid.UUID,
    limit: int = Query(50, ge=1, le=200),
    offset: int = Query(0, ge=0),
    ctx: TenantContext = Depends(require_permission(Permission.KNOWLEDGE_READ)),
    session: AsyncSession = Depends(get_session),
):
    coll = await session.get(KnowledgeCollection, collection_id)
    if coll is None or coll.tenant_id != ctx.tenant_id:
        raise HTTPException(status_code=404, detail="collection not found")
    total = (
        await session.execute(
            select(func.count(KnowledgeCollectionSource.id)).where(KnowledgeCollectionSource.collection_id == collection_id)
        )
    ).scalar() or 0
    rows = (
        await session.execute(
            select(KnowledgeCollectionSource)
            .where(KnowledgeCollectionSource.collection_id == collection_id)
            .order_by(KnowledgeCollectionSource.created_at.desc())
            .offset(offset)
            .limit(limit)
        )
    ).scalars().all()
    return {"sources": [r.as_dict() for r in rows], "total": int(total), "limit": limit, "offset": offset}

@router.delete("/collections/{collection_id}/sources/{source_id}")
async def delete_source(
    collection_id: uuid.UUID,
    source_id: uuid.UUID,
    ctx: TenantContext = Depends(require_permission(Permission.KNOWLEDGE_WRITE)),
    session: AsyncSession = Depends(get_session),
):
    src = await session.get(KnowledgeCollectionSource, source_id)
    if src is None or src.collection_id != collection_id or src.tenant_id != ctx.tenant_id:
        raise HTTPException(status_code=404, detail="source not found")
    await session.delete(src)
    await session.commit()
    return {"id": str(source_id), "deleted": True}

@router.post("/collections/{collection_id}/bind", response_model=CollectionOut)
async def bind_agents(
    collection_id: uuid.UUID,
    payload: AgentBindingRequest,
    ctx: TenantContext = Depends(require_permission(Permission.KNOWLEDGE_WRITE)),
    session: AsyncSession = Depends(get_session),
):
    """POST /api/kb/collections/{id}/bind — Agent binding."""
    coll = await session.get(KnowledgeCollection, collection_id)
    if coll is None or coll.tenant_id != ctx.tenant_id:
        raise HTTPException(status_code=404, detail="collection not found")

    # Merge agent_ids
    existing = set(coll.agent_ids or [])
    for aid in payload.agent_ids:
        existing.add(aid)
    coll.agent_ids = sorted(list(existing))
    coll.updated_at = _now()
    await session.commit()
    await session.refresh(coll)
    return _coll_out(coll)

@router.post("/collections/{collection_id}/unbind", response_model=CollectionOut)
async def unbind_agents(
    collection_id: uuid.UUID,
    payload: AgentBindingRequest,
    ctx: TenantContext = Depends(require_permission(Permission.KNOWLEDGE_WRITE)),
    session: AsyncSession = Depends(get_session),
):
    coll = await session.get(KnowledgeCollection, collection_id)
    if coll is None or coll.tenant_id != ctx.tenant_id:
        raise HTTPException(status_code=404, detail="collection not found")
    existing = set(coll.agent_ids or [])
    for aid in payload.agent_ids:
        existing.discard(aid)
    coll.agent_ids = sorted(list(existing))
    coll.updated_at = _now()
    await session.commit()
    await session.refresh(coll)
    return _coll_out(coll)

@router.get("/collections/{collection_id}/sync-status", response_model=dict)
async def get_sync_status(
    collection_id: uuid.UUID,
    ctx: TenantContext = Depends(require_permission(Permission.KNOWLEDGE_READ)),
    session: AsyncSession = Depends(get_session),
):
    """GET /api/kb/collections/{id}/sync-status — Sync status."""
    coll = await session.get(KnowledgeCollection, collection_id)
    if coll is None or coll.tenant_id != ctx.tenant_id:
        raise HTTPException(status_code=404, detail="collection not found")

    sources = (
        await session.execute(
            select(KnowledgeCollectionSource).where(KnowledgeCollectionSource.collection_id == collection_id)
        )
    ).scalars().all()

    status_counts = {}
    for s in sources:
        status_counts[s.sync_status] = status_counts.get(s.sync_status, 0) + 1

    return {
        "collection_id": str(coll.id),
        "sync_status": coll.sync_status,
        "last_sync_at": coll.last_sync_at.isoformat() if coll.last_sync_at else None,
        "sources_total": len(sources),
        "status_counts": status_counts,
        "sources": [s.as_dict() for s in sources],
    }

@router.post("/collections/{collection_id}/reindex", response_model=dict)
async def reindex_collection(
    collection_id: uuid.UUID,
    ctx: TenantContext = Depends(require_permission(Permission.KNOWLEDGE_WRITE)),
    session: AsyncSession = Depends(get_session),
):
    """POST /api/kb/collections/{id}/reindex — Trigger reindex."""
    coll = await session.get(KnowledgeCollection, collection_id)
    if coll is None or coll.tenant_id != ctx.tenant_id:
        raise HTTPException(status_code=404, detail="collection not found")

    coll.sync_status = "syncing"
    coll.updated_at = _now()

    # Mark all sources as pending
    sources = (
        await session.execute(
            select(KnowledgeCollectionSource).where(KnowledgeCollectionSource.collection_id == collection_id)
        )
    ).scalars().all()
    for s in sources:
        s.sync_status = "pending"

    await session.commit()
    return {"collection_id": str(coll.id), "status": "syncing", "sources_queued": len(sources)}
