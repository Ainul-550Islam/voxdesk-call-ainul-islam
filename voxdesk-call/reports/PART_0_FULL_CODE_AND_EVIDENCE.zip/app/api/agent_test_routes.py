"""Legacy agent-test contract; unimplemented transport fails closed.

Use the existing persisted simulation API for supported simulation runs.
No token, WebSocket URL, transcript, latency or process-local session is invented.
"""
from __future__ import annotations

import uuid
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from app.auth.dependencies import Permission, TenantContext, require_permission
from app.db.models import Agent
from app.db.session import get_session

router = APIRouter(prefix="/api/v1", tags=["agent-test"])


class TestSessionCreateIn(BaseModel):
    mode: str = Field(default="simulation", pattern="^(simulation|live_webrtc|phone_loopback)$")
    initial_prompt_override: Optional[str] = Field(default=None, max_length=2000)
    mock_caller_persona: Optional[str] = Field(default="curious_customer", max_length=80)
    timeout_sec: int = Field(default=120, ge=10, le=600)

class TestSessionOut(BaseModel):
    session_id: str
    agent_id: str
    tenant_id: str
    mode: str
    status: str
    ws_url: Optional[str]
    token: str
    expires_at: str
    created_at: str

class TestEventIn(BaseModel):
    event: str = Field(..., pattern="^(start|stop|interrupt|text|audio)$")
    data: Optional[dict] = Field(default_factory=dict)
    timestamp: Optional[str] = None

class TestEventOut(BaseModel):
    session_id: str
    event: str
    new_state: str
    at: str

class TestTranscriptOut(BaseModel):
    role: str
    text: str
    timestamp: str
    latency_ms: Optional[int]
    tool_calls: List[dict]

class TestSessionStateOut(BaseModel):
    session_id: str
    state: str
    transcript: List[TestTranscriptOut]
    latency_ms: int
    error: Optional[str]


@router.post("/agents/{agent_id}/test", response_model=TestSessionOut, status_code=status.HTTP_201_CREATED)
async def create_agent_test_session(
    agent_id: str,
    payload: TestSessionCreateIn,
    ctx: TenantContext = Depends(require_permission(Permission.TENANT_UPDATE)),
    session: AsyncSession = Depends(get_session),
) -> TestSessionOut:
    try:
        agent_uuid = uuid.UUID(agent_id)
    except ValueError:
        raise HTTPException(status_code=404, detail="Agent not found") from None
    agent = await session.scalar(select(Agent).where(
        Agent.id == agent_uuid, Agent.tenant_id == ctx.tenant_id, Agent.deleted_at.is_(None),
    ))
    if agent is None:
        raise HTTPException(status_code=404, detail="Agent not found")
    raise HTTPException(status_code=501, detail={
        "code": "UNSUPPORTED_CAPABILITY", "state": "UNSUPPORTED_CAPABILITY",
        "message": "Legacy agent-test transport is not implemented. Use the persisted simulation API.",
    })


@router.post("/agent-tests/{session_id}/events", response_model=TestEventOut)
async def send_agent_test_event(
    session_id: str,
    payload: TestEventIn,
    ctx: TenantContext = Depends(require_permission(Permission.TENANT_UPDATE)),
) -> TestEventOut:
    raise HTTPException(status_code=404, detail="Test session not found")


@router.get("/agent-tests/{session_id}", response_model=TestSessionStateOut)
async def get_agent_test_session(
    session_id: str,
    ctx: TenantContext = Depends(require_permission(Permission.TENANT_READ)),
) -> TestSessionStateOut:
    raise HTTPException(status_code=404, detail="Test session not found")


@router.get("/agent-tests/{session_id}/health", response_model=dict)
async def health_check(
    session_id: str,
    ctx: TenantContext = Depends(require_permission(Permission.TENANT_READ)),
) -> dict:
    raise HTTPException(status_code=404, detail="Test session not found")
