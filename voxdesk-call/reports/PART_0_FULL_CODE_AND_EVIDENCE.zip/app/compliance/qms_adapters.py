"""QMS adapter contracts and explicit unavailable states.

Vendor transport is not implemented. Credentials alone never establish health,
documents, findings, traceability, or an assembled audit package.
"""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from typing import Any, Protocol, NoReturn

from app.core.errors import AppError
from app.core.tracing import span


@dataclass(frozen=True)
class QMSContext:
    tenant_id: uuid.UUID
    organization_id: uuid.UUID
    environment_id: uuid.UUID
    provider: str
    config: dict[str, Any]
    credentials: dict[str, Any]


@dataclass(frozen=True)
class QMSHealthResult:
    connected: bool
    provider: str
    latency_ms: float
    safe_message: str
    details: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class QMSDocument:
    external_id: str
    title: str
    status: str
    revision: str | None
    owner: str | None
    effective_date: str | None
    approval_state: str | None
    last_reviewed_at: str | None
    url: str | None
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class QMSFinding:
    external_id: str
    control_key: str
    result: str
    gaps: dict[str, Any]
    evidence_refs: list[str]
    traceability: dict[str, Any]


class QMSAdapter(Protocol):
    provider: str

    async def health_check(self) -> QMSHealthResult: ...
    async def list_documents(self, query: str | None = None) -> list[QMSDocument]: ...
    async def get_document(self, external_id: str) -> QMSDocument: ...
    async def create_finding(self, finding: QMSFinding) -> dict[str, Any]: ...
    async def get_traceability(self, subject_type: str, subject_id: str) -> dict[str, Any]: ...
    async def assemble_audit_package(self, framework_id: str) -> dict[str, Any]: ...


class QMSCapabilityUnavailable(AppError):
    status_code = 501
    code = "UNSUPPORTED_CAPABILITY"


class _BaseQMSAdapter:
    provider = ""
    credential_keys: tuple[str, ...] = ()

    def __init__(self, context: QMSContext):
        self.context = context
        self.provider = type(self).provider or context.provider

    async def health_check(self) -> QMSHealthResult:
        missing = [key for key in self.credential_keys
                   if not (self.context.credentials.get(key) or self.context.config.get(key))]
        state = "NOT_CONFIGURED" if missing else "UNSUPPORTED_CAPABILITY"
        return QMSHealthResult(
            connected=False, provider=self.provider, latency_ms=0,
            safe_message="QMS network operations are not implemented; credentials do not establish connectivity.",
            details={"state": state, "verified": False, "request_attempted": False,
                     "missing_fields": missing},
        )

    async def _unavailable(self, operation: str) -> NoReturn:
        health = await self.health_check()
        state = health.details["state"]
        raise QMSCapabilityUnavailable(
            health.safe_message, code=state,
            detail={"state": state, "provider": self.provider, "operation": operation},
        )

    async def list_documents(self, query: str | None = None) -> list[QMSDocument]:
        await self._unavailable("list_documents")

    async def get_document(self, external_id: str) -> QMSDocument:
        await self._unavailable("get_document")

    async def create_finding(self, finding: QMSFinding) -> dict[str, Any]:
        await self._unavailable("create_finding")

    async def get_traceability(self, subject_type: str, subject_id: str) -> dict[str, Any]:
        await self._unavailable("get_traceability")

    async def assemble_audit_package(self, framework_id: str) -> dict[str, Any]:
        await self._unavailable("assemble_audit_package")


class VeevaVaultAdapter(_BaseQMSAdapter):
    provider = "veeva_vault"
    credential_keys = ("instance_url", "username", "password")


class MasterControlAdapter(_BaseQMSAdapter):
    provider = "mastercontrol"
    credential_keys = ("base_url", "api_key")


class ETQAdapter(_BaseQMSAdapter):
    provider = "etq"
    credential_keys = ("base_url", "username", "password")


# Registry for QMS adapters

_QMS_REGISTRY: dict[str, type[_BaseQMSAdapter]] = {
    "veeva_vault": VeevaVaultAdapter,
    "veeva": VeevaVaultAdapter,
    "mastercontrol": MasterControlAdapter,
    "master_control": MasterControlAdapter,
    "etq": ETQAdapter,
    "etq_reliance": ETQAdapter,
}


def get_qms_adapter(context: QMSContext) -> QMSAdapter:
    adapter_cls = _QMS_REGISTRY.get(context.provider.lower())
    if not adapter_cls:
        raise ValueError(f"QMS provider not registered: {context.provider}. Available: {', '.join(_QMS_REGISTRY)}")
    return adapter_cls(context)  # type: ignore


def list_qms_providers() -> list[str]:
    return list(_QMS_REGISTRY.keys())


async def health_check_all(context: QMSContext) -> list[QMSHealthResult]:
    results = []
    for provider in _QMS_REGISTRY:
        ctx = QMSContext(
            tenant_id=context.tenant_id,
            organization_id=context.organization_id,
            environment_id=context.environment_id,
            provider=provider,
            config=context.config,
            credentials=context.credentials,
        )
        adapter = get_qms_adapter(ctx)
        with span("voxdesk.qms.health", provider=provider, tenant_id=str(context.tenant_id)):
            result = await adapter.health_check()
            results.append(result)
    return results
