"""Package complete PART 0 sources and actual evidence without claiming G0 passes."""
from pathlib import Path
import hashlib
import json
import re
import zipfile

ROOT = Path(__file__).resolve().parents[2]
R = ROOT / 'reports/part0'
report = ROOT / 'reports/PART_0_REPORT.md'
manifest = json.loads((R / 'changed-files.json').read_text())
files = sorted(set(manifest['complete_files'] + ['reports/part0/build_report.py', 'reports/STEP0_BASELINE.md']))
text = '''# PART 0 — Liability Removal & Truth Reset

Date: 2026-10-07 (Asia/Dhaka)

## Executive result

**G0 BLOCKED. PART 1 has not started.** The scoped deletion, media-secret repair, evidence generation and permanent guards have been implemented. The guards deliberately remain red on unresolved findings rather than hiding them in broader allowlists or deleting real code.

| Measurement | Current evidence |
|---|---|
| Audited clone modules removed | 95; full-file AST inspection, prefix and reference audit recorded |
| Filler directories removed | 3; complete removed-source backup retained under docs/archive |
| Registered routes before / after | 1,669 / 1,210 |
| Removed OpenAPI paths | 459; all belong to the 95 audited modules |
| Protected real routers | retell_parity_routes.py and conductor_routes.py unchanged, SHA-256 verified |
| Padding grep after cleanup | 0 matches across app/services |
| Additional non-executable padding/banner lines stripped | 5,562 across 20 files, after clone-directory deletions |
| Current full pytest collection | 4,217 unique collected tests; not a full execution claim |
| Truth suite | 24 executed: 22 passed, 2 failed, 0 skipped |
| Truth + neighboring telephony/security/contracts | 84 executed: 82 passed, 2 failed, 0 skipped |
| Global Ruff / compileall | PASS / PASS |
| Alembic | One existing head: 0049_runtime_schema_alignment; no migration added or edited |
| Protobuf contract verification | PASS; 5 contracts compile and pass vocabulary/tenant checks |
| Both Compose configuration checks | PASS with temporary validation-only environment inputs; no deployment performed |
| make verify-truth | FAIL because the strict filler gate detects unresolved findings |
| Raw forbidden-directory reference grep | NOT EMPTY: negative guard definitions and historical evidence remain |
| Strict OpenAPI removals-only condition | NOT MET: 11 obsolete description removals and one pre-existing unordered default |

The historical 7.7K expected route drop is not this workspace's starting behavior. Earlier code quarantined numbered placeholder endpoints at runtime but left clone health/stats/config/search/export handlers mounted. Removing their source eliminates the remaining 459 paths. No retained real router was deleted to satisfy a count.

## Baseline and safety decision

The original uploaded banner check failed for eight files. After the user's explicit PART 0 START instruction, the replacement safety audit read and parsed all 95 candidate files and recorded their complete hashes, function shapes, called functions, router prefixes, source/test/frontend references and active routes. There are no exact-prefix collisions with real routers and no external module-name references outside main registration. Candidate calls are limited to the generated template helpers, framework dependencies, logging, UUID/time generation and COUNT(NOW()) rather than tenant-resource persistence.

The protected real modules existed as untracked prior work; that explains the original git ls-files discrepancy. They remain byte-identical to the pre-edit workspace. No applied migration was reset to the upload's obsolete 0045 reference. Python 3.12.15 and the pinned dependency set were restored before capturing the actual application and collection baseline.

`reports/STEP0_BASELINE.md` preserves the first blocked environment probe. The successful current before/after execution is separately recorded under reports/part0; initial missing-dependency errors are not presented as successful baseline measurements.

## Task register

- **P0-01:** Removed the three audited filler trees and their Compose services. Canonical services under services/ remain. Fixed the existing LiveKit environment YAML mapping so both Compose files parse. The missing-file audit remains read-only and excludes generated caches/historical archive trees; it never creates stubs.
- **P0-02:** Deleted all 95 audited clone modules and their imports/registrations. Kept both protected routers and every other real router. The original quarantine helper is retained rather than changing unrelated runtime behavior.
- **P0-03:** Added an idempotent padding/banner cleanup tool and removed non-executable padding. Source parses afterward. Five line-count marketing phrases embedded in UI content remain flagged: changing UI copy is beyond the narrowly specified comment cleanup. Two real files also trigger the requested numerical repetition heuristic; they were not deleted or silently allowlisted.
- **P0-04:** Added filler, fake-success and null-byte guards, tests, make target and required CI job. The facade register has ten currently detected known-facade paths, not stale entries copied blindly from the upload. Shrink history is compared with the base revision, including the case where the allowlist was deleted. Broad filler exemptions fail. Rust, Go and C++ CI tests must report a positive executed count; canonical Rust media-engine testing was added, and the existing gateway job retained.
- **P0-05:** Removed the fixed media-signing secret from both issuance and verification. The real Settings field is jwt_secret, not the upload's nonexistent jwt_secret_key. Missing/blank configuration raises the existing typed telephony configuration exception with HTTP 501; call/tenant/key bindings are tested. Production validation rejects the default identity secrets. No mock media-runtime behavior was expanded or relabeled as live.
- **P0-06:** Archived the named misleading documents with historical/inaccurate banners, retaining the null-byte incident record. Replaced README claims with measured statistics. Seeded all 41 requested feature rows conservatively; no LIVE feature is claimed without exact passing evidence. JUnit skips, failures, missing cases, ambiguous retries and collection errors cannot establish LIVE.
- **P0-07:** Added text/binary attributes, preserved intentional empty package initializers, tested null/accidental-empty detection, documented one-task-per-commit policy and supplied complete sources/evidence. No null-byte finding remains.

Task commits use the explicit Arena Agent identity, not an invented user identity. Only explicit task paths are committed. Existing edits in files touched by this part are preserved, and the unrelated staged ab_testing_routes.py changes remain staged. The pre-existing index patch is retained for audit. No remote push was performed.

## Residual blockers — do not start PART 1

### Fake-success guard: nine out-of-allowlist production files

Eight audit helpers swallow broad exceptions:

1. app/api/agent_test_routes.py
2. app/api/call_search_export_routes.py
3. app/api/knowledge_base_routes.py
4. app/api/pcap_routes.py
5. app/api/phone_number_lifecycle_routes.py
6. app/api/recording_management_routes.py
7. app/api/tool_registry_routes.py
8. app/api/workflow_event_routes.py

The ninth finding is a fake-success phrase in app/compliance/qms_adapters.py. The exact line locations and reasons are in fake-success.log. These are not in the approved facade seed, so adding exemptions would weaken the requested guard. Changing their business behavior is outside the supplied PART 0 tree. Several were touched only for authorized comment/padding cleanup; their behavior was deliberately not changed under that authorization.

### Filler guard: seven findings

- app/api/conductor_routes.py: normalized distinct-line ratio approximately 0.3428. The prompt explicitly protects this real router.
- app/leads/models.py: ratio approximately 0.3432; a real model file, not a generated clone.
- Five line-count marketing phrases in dashboard-next/app/dashboard/connection-demo/page.tsx and dashboard-next/app/dashboard/page.tsx.

The 0.35 threshold and 200-line minimum have not been reduced. No generated-code exception was invented for the real router/models. A reviewed policy for demonstrable heuristic false positives and authorization to remove the UI copy are required to resolve these findings safely.

### Exact acceptance-command caveats

The mandated raw reference grep also matches the guard that must prohibit the deleted directory names, historical audit evidence, and local cache copies. Those matches are reported, not erased to manufacture empty output. Active Compose/import registrations no longer reference the removed engines. The check needs an agreed operational-reference scope rather than deleting forensic records or prohibitions themselves.

OpenAPI has 459 removed paths and no newly added paths. Eleven retained path descriptions lost the removed line-count banners. A remaining export field default has an existing unordered-set serialization difference between Python processes. The complete raw before/after schema and diff are supplied; the literal removals-only requirement is not reported as passing. No handler, response schema or permission was changed to hide this discrepancy.

## Validation boundaries

These results are for PART 0. The entire 4,217-node backend suite was collected, not rerun in full; 84 relevant current tests were executed. The older FINAL_TEST_RESULTS.json and PROMPT8B reports remain historical evidence for their prior tree, not current all-green proof. Prior Python typecheck and live-provider blockers are not claimed fixed. No provider call, audio performance benchmark, production deployment or production-ready claim is made.

The new CI configuration was parsed locally; the whole hosted Rust/Go/C++/frontend CI matrix was not rerun locally in this pass. Comment-only changes to real services preserve their executable code. Real contracts, route imports, secret tests, telephony/security neighbors and Compose syntax were actually exercised.

## Required next authorization within PART 0

To make G0 green without breaking the scope guard, authorize narrowly scoped remediation of the nine new guard findings, removal of the five UI marketing phrases, and a reviewed treatment of the two proven real-code repetition findings. Resolve the literal reference and description-diff acceptance conflicts explicitly. PART 1 remains blocked until G0 is genuinely green.

## Complete current file contents

All changed/created source, configuration, tests and documentation are reproduced below, first through last line. Binary backup data is supplied losslessly in the companion archive rather than represented as text. Complete command logs, JUnit, source hashes, deletion audit and raw schemas are included in PART_0_FULL_CODE_AND_EVIDENCE.zip. The report is not recursively embedded inside itself.

'''
for relative in files:
    p = ROOT / relative
    if p.suffix == '.zip':
        text += f'### Binary file: {relative}\n\nSHA-256: `{hashlib.sha256(p.read_bytes()).hexdigest()}`. Complete bytes included in the evidence archive.\n\n'
        continue
    body = p.read_text()
    fence = '`' * max(4, max((len(m.group()) + 1 for m in re.finditer(r'`+', body)), default=4))
    text += f'### File: {relative}\n\nSHA-256: `{hashlib.sha256(p.read_bytes()).hexdigest()}`\n\n{fence}\n{body}' + ('' if body.endswith('\n') else '\n') + fence + '\n\n'
text += '## Actual command output\n\n'
for p in sorted(R.glob('*.log')):
    body = p.read_text()
    text += f'### {p.name}\n\n````text\n{body}\n````\n\n'
text += '## Deleted files\n\n' + '\n'.join(f'- `{p}`' for p in manifest['deleted_files']) + '\n'
report.write_text(text)
archive_path = ROOT / 'reports/PART_0_FULL_CODE_AND_EVIDENCE.zip'
entries = set(files + ['reports/PART_0_REPORT.md'])
entries.update(str(p.relative_to(ROOT)) for p in R.rglob('*') if p.is_file() and '__pycache__' not in p.parts)
with zipfile.ZipFile(archive_path, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for relative in sorted(entries):
        archive.write(ROOT / relative, relative)
with zipfile.ZipFile(archive_path) as archive:
    assert archive.testzip() is None
    for relative in files:
        assert archive.read(relative) == (ROOT / relative).read_bytes()
print(json.dumps({'report_bytes': report.stat().st_size, 'archive_bytes': archive_path.stat().st_size, 'complete_files': len(files), 'archive_entries': len(entries)}, indent=2))
