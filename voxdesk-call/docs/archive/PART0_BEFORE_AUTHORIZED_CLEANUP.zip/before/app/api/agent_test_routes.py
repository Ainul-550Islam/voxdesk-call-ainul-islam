"""Agent Test Session API routes (`/api/v1/agents/{agent_id}/test`, `/api/v1/agent-tests/{session_id}`)."""
from __future__ import annotations

import time
import uuid
from datetime import datetime, timezone
from typing import Dict, List, Optional

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, Field

from app.auth.dependencies import Permission, TenantContext, require_permission
from app.core.logging import log
from app.services.simulation_service import _execute_turn_against_pinned_config

router = APIRouter(prefix="/api/v1", tags=["agent-test"])

_test_sessions: Dict[str, dict] = {}
SESSION_TTL = 600


def _now() -> float:
    return time.time()


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _audit(event: str, **kw) -> None:
    try:
        log.info(event, **kw)
    except Exception:
        pass


class TestSessionCreateIn(BaseModel):
    mode: str = Field(default="simulation", pattern="^(simulation|live_webrtc|phone_loopback)$")
    initial_prompt_override: Optional[str] = Field(default=None, max_length=2000)
    mock_caller_persona: Optional[str] = Field(default="curious_customer", max_length=80)
    timeout_sec: int = Field(default=120, ge=10, le=600)


class TestSessionOut(BaseModel):
    session_id: str
    agent_id: str
    tenant_id: str
    mode: str
    status: str
    ws_url: Optional[str]
    token: str
    expires_at: str
    created_at: str


class TestEventIn(BaseModel):
    event: str = Field(..., pattern="^(start|stop|interrupt|text|audio)$")
    data: Optional[dict] = Field(default_factory=dict)
    timestamp: Optional[str] = None


class TestEventOut(BaseModel):
    session_id: str
    event: str
    new_state: str
    at: str


class TestTranscriptOut(BaseModel):
    role: str
    text: str
    timestamp: str
    latency_ms: Optional[int]
    tool_calls: List[dict]


class TestSessionStateOut(BaseModel):
    session_id: str
    state: str
    transcript: List[TestTranscriptOut]
    latency_ms: int
    error: Optional[str]


@router.post("/agents/{agent_id}/test", response_model=TestSessionOut, status_code=status.HTTP_201_CREATED)
async def create_agent_test_session(
    agent_id: str,
    payload: TestSessionCreateIn,
    ctx: TenantContext = Depends(require_permission(Permission.TENANT_UPDATE)),
) -> TestSessionOut:
    session_id = f"test-{uuid.uuid4().hex[:16]}"
    token = f"tok-{uuid.uuid4().hex[:24]}"
    now_ts = _now()
    expires = now_ts + min(payload.timeout_sec, SESSION_TTL)
    expires_iso = datetime.fromtimestamp(expires, tz=timezone.utc).isoformat()
    sess = {
        "session_id": session_id,
        "agent_id": agent_id,
        "tenant_id": str(ctx.tenant_id),
        "mode": payload.mode,
        "status": "IDLE",
        "token": token,
        "expires_at": expires,
        "created_at": _now_iso(),
        "transcript": [],
        "events": [],
        "prompt_override": payload.initial_prompt_override,
    }
    _test_sessions[session_id] = sess
    _audit(
        "agent.test.created",
        tenant_id=str(ctx.tenant_id),
        agent_id=agent_id,
        session_id=session_id,
        mode=payload.mode,
    )
    return TestSessionOut(
        session_id=session_id,
        agent_id=agent_id,
        tenant_id=str(ctx.tenant_id),
        mode=payload.mode,
        status="IDLE",
        ws_url=f"/ws/agent-test/{session_id}",
        token=token,
        expires_at=expires_iso,
        created_at=sess["created_at"],
    )


@router.post("/agent-tests/{session_id}/events", response_model=TestEventOut)
async def send_agent_test_event(
    session_id: str,
    payload: TestEventIn,
    ctx: TenantContext = Depends(require_permission(Permission.TENANT_UPDATE)),
) -> TestEventOut:
    sess = _test_sessions.get(session_id)
    if not sess:
        raise HTTPException(status_code=404, detail="Test session not found or expired")
    if _now() > sess["expires_at"]:
        _test_sessions.pop(session_id, None)
        raise HTTPException(status_code=404, detail="Test session expired")
    if str(ctx.tenant_id) != sess["tenant_id"]:
        raise HTTPException(status_code=403, detail="Forbidden")

    current = sess["status"]
    mapping = {
        "start": "LISTENING",
        "stop": "ENDED",
        "interrupt": "INTERRUPTED",
        "text": "THINKING",
        "audio": "LISTENING",
    }
    new_state = mapping.get(payload.event, current)
    if payload.event == "text":
        text = str((payload.data or {}).get("text") or "").strip()
        sess["transcript"].append(
            {
                "role": "user",
                "text": text,
                "timestamp": _now_iso(),
                "latency_ms": None,
                "tool_calls": [],
            }
        )
        turn_out = await _execute_turn_against_pinned_config(
            pinned_config={
                "system_prompt": sess.get("prompt_override") or "You are a helpful AI assistant."
            },
            agent_name=sess["agent_id"],
            provider="openai",
            model="gpt-4o-mini",
            turn_index=len(sess["transcript"]),
            user_text=text,
            conversation_history=[],
            dynamic_variables={},
            runtime_variables={},
            allow_mock_fallback=True,
        )
        sess["transcript"].append(
            {
                "role": "agent",
                "text": turn_out["reply"],
                "timestamp": _now_iso(),
                "latency_ms": turn_out["latency_ms"],
                "tool_calls": turn_out["tool_calls"],
            }
        )
        new_state = "SPEAKING"

    sess["status"] = new_state
    sess["events"].append(
        {"event": payload.event, "timestamp": payload.timestamp, "new_state": new_state}
    )
    _audit(
        "agent.test.event",
        tenant_id=str(ctx.tenant_id),
        session_id=session_id,
        event=payload.event,
        new_state=new_state,
    )
    return TestEventOut(
        session_id=session_id,
        event=payload.event,
        new_state=new_state,
        at=_now_iso(),
    )


@router.get("/agent-tests/{session_id}", response_model=TestSessionStateOut)
async def get_agent_test_session(
    session_id: str,
    ctx: TenantContext = Depends(require_permission(Permission.TENANT_READ)),
) -> TestSessionStateOut:
    sess = _test_sessions.get(session_id)
    if not sess:
        raise HTTPException(status_code=404, detail="Test session not found or expired")
    if _now() > sess["expires_at"]:
        _test_sessions.pop(session_id, None)
        raise HTTPException(status_code=404, detail="Test session expired")
    if str(ctx.tenant_id) != sess["tenant_id"]:
        raise HTTPException(status_code=403, detail="Forbidden")
    return TestSessionStateOut(
        session_id=session_id,
        state=sess["status"],
        transcript=[TestTranscriptOut(**t) for t in sess["transcript"][-20:]],
        latency_ms=120,
        error=None if sess["status"] != "ERROR" else "Test error",
    )


@router.get("/agent-tests/{session_id}/health", response_model=dict)
async def health_check() -> dict:
    return {"status": "healthy", "service": "agent-test", "at": _now_iso()}
